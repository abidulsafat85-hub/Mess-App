# Aura — Personal Student Productivity & Self-Management

A modern, calm, and student-focused productivity application designed to eliminate cognitive overload and answer:

> **"What do I need to do today? What should I study? What should I focus on next?"**

---

## 🌟 Key Features

1. **Today Dashboard (The Command Center)**
   - Smart contextual greeting & daily motivation.
   - **Today's Progress**: Task completion percentage & progress bar.
   - **Focus Next Card**: Instant highlight of the highest-priority pending task with one-click Pomodoro launch.
   - **Today's Habits**: Rapid one-tap habit tracking with streak counters.
   - **Study Today**: Real-time study hours vs. your daily target.
   - **Up Next**: Upcoming assignment deadlines.

2. **Todoist-Style Task Management**
   - Natural language input: e.g. *"Review Database slides tomorrow at 3 PM #Study !urgent"*.
   - Priority levels: Urgent, High, Medium, Low.
   - Categories: Study, Coding, Personal, Health, Finance, Other.
   - Subtasks checklist with completion tracking.
   - Views: Today, Upcoming, Overdue, Completed, All Tasks.
   - Filtering & Sorting by due date, priority, or title.

3. **Distraction-Free Focus / Pomodoro Mode**
   - Sleek circular timer with work/break cycles.
   - Presets: 25/5 (Classic Pomodoro), 50/10 (Deep Work), 90/15 (Ultradian Cycle).
   - Links directly to your active task and enrolled subject.
   - **Automatic Logging**: Completed focus sessions automatically record to study analytics!
   - Confetti bursts and Web Audio chimes upon completion.

4. **Study Dashboard & Subject Tracking**
   - Subject cards with weekly study goals and progress.
   - Manual session logger with topic, duration, date, and notes.
   - Weekly study hours distribution bar chart.

5. **Habit Tracker**
   - Daily, weekday, or weekend frequencies.
   - 7-day interactive matrix (M T W T F S S) with one-click toggles.
   - Streak counters 🔥 and personal best records 🏆.

6. **Long-Term Goals & Milestones**
   - Visual progress bars that automatically update as milestones are completed.
   - Target deadlines with countdowns.

7. **Lightweight Notes & Study Sheets**
   - Categories: Study, Ideas, Important, Personal.
   - Pinning, tag filtering, and embedded checklist items.

8. **Productivity Analytics & Insights**
   - Date range selector (7 days, 30 days, 90 days).
   - Interactive charts: Study hours trend (Area chart), tasks completed (Bar chart), and subject allocation (Donut chart).
   - Automated performance summaries and best study day insights.

9. **AI Study Assistant**
   - **Study Plan Generator**: Breaks hours and topics into structured phases.
   - **[Add All to Tasks]**: Directly converts AI-generated plans into actionable scheduled tasks!
   - **Concept Explainer**: Plain-English analogies and mental models.
   - **Task Breakdown**: Deconstructs daunting assignments into bite-sized subtasks.
   - **Interactive Quiz Generator**: Test active recall with multiple-choice questions, instant grading, and explanations.

10. **Daily Reflection & End-of-Day Review**
    - 1-5 star productivity feeling rating, celebration of wins, and daily reflection.

11. **Global Search & Keyboard Shortcuts**
    - `⌘K` or `Ctrl+K`: Global search across tasks, notes, goals, habits, and subjects.
    - `N`: Quick Add Task.
    - `F`: Launch Focus Mode.
    - `C`: Open Calendar.
    - `S`: Open Search.
    - `Esc`: Close any open modal.

12. **Theme Customization & Local Persistence**
    - Full Dark Mode, Light Mode, and System Theme support.
    - Accent colors: Indigo, Blue, Emerald, Violet, Rose, Amber.
    - Complete JSON backup export and import.
    - Reset to sample data or clear data with safe confirmation dialogs.

---

## 🛠️ Tech Stack

- **Framework**: React 19 + TypeScript + Vite
- **Styling**: Tailwind CSS v4
- **Icons**: Lucide React
- **Animations**: Framer Motion
- **State Management**: Zustand
- **Charts**: Recharts
- **Dates**: date-fns
- **Effects**: canvas-confetti & Web Audio API synthesis

---

## 🚀 Getting Started

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```
