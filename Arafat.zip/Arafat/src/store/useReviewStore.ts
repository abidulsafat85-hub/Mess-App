import { create } from 'zustand'
import { DailyReview } from '@/types'
import { reviewService } from '@/services/reviewService'
import { getTodayDateString } from '@/utils/date'
import { triggerConfetti, soundEffects } from '@/utils/effects'

interface ReviewState {
  reviews: DailyReview[]
  isLoading: boolean

  loadReviews: () => Promise<void>
  submitReview: (data: Omit<DailyReview, 'id' | 'createdAt'>) => Promise<DailyReview>
  getTodayReview: () => DailyReview | null
}

export const useReviewStore = create<ReviewState>((set, get) => ({
  reviews: [],
  isLoading: true,

  loadReviews: async () => {
    set({ isLoading: true })
    const list = await reviewService.getReviews()
    set({ reviews: list, isLoading: false })
  },

  submitReview: async (data) => {
    const review = await reviewService.submitDailyReview(data)
    const existing = get().reviews.filter((r) => r.date !== data.date)
    set({ reviews: [review, ...existing] })
    soundEffects.playComplete()
    triggerConfetti()
    return review
  },

  getTodayReview: () => {
    const today = getTodayDateString()
    return get().reviews.find((r) => r.date === today) || null
  },
}))
