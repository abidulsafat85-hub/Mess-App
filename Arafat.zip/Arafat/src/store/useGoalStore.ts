import { create } from 'zustand'
import { Goal } from '@/types'
import { goalService } from '@/services/goalService'
import { triggerConfetti, soundEffects } from '@/utils/effects'

interface GoalState {
  goals: Goal[]
  isLoading: boolean

  loadGoals: () => Promise<void>
  addGoal: (data: Omit<Goal, 'id' | 'progress' | 'createdAt'>) => Promise<Goal>
  updateGoal: (id: string, updates: Partial<Goal>) => Promise<Goal>
  deleteGoal: (id: string) => Promise<void>
  toggleMilestone: (goalId: string, milestoneId: string) => Promise<void>
  addMilestone: (goalId: string, title: string) => Promise<void>
}

export const useGoalStore = create<GoalState>((set, get) => ({
  goals: [],
  isLoading: true,

  loadGoals: async () => {
    set({ isLoading: true })
    const list = await goalService.getGoals()
    set({ goals: list, isLoading: false })
  },

  addGoal: async (data) => {
    const newGoal = await goalService.createGoal(data)
    set((state) => ({ goals: [newGoal, ...state.goals] }))
    soundEffects.playTick()
    return newGoal
  },

  updateGoal: async (id, updates) => {
    const updated = await goalService.updateGoal(id, updates)
    set((state) => ({
      goals: state.goals.map((g) => (g.id === id ? updated : g)),
    }))
    return updated
  },

  deleteGoal: async (id) => {
    await goalService.deleteGoal(id)
    set((state) => ({
      goals: state.goals.filter((g) => g.id !== id),
    }))
  },

  toggleMilestone: async (goalId, milestoneId) => {
    const updated = await goalService.toggleMilestone(goalId, milestoneId)
    set((state) => ({
      goals: state.goals.map((g) => (g.id === goalId ? updated : g)),
    }))
    soundEffects.playComplete()
    if (updated.progress === 100) {
      triggerConfetti()
    }
  },

  addMilestone: async (goalId, title) => {
    const updated = await goalService.addMilestone(goalId, title)
    set((state) => ({
      goals: state.goals.map((g) => (g.id === goalId ? updated : g)),
    }))
    soundEffects.playTick()
  },
}))
