import { create } from 'zustand'
import { StudySubject, StudySession } from '@/types'
import { studyService } from '@/services/studyService'
import { getTodayDateString } from '@/utils/date'
import { subDays, parseISO, isAfter } from 'date-fns'
import { triggerConfetti, soundEffects } from '@/utils/effects'

interface StudyState {
  subjects: StudySubject[]
  sessions: StudySession[]
  isLoading: boolean

  loadStudyData: () => Promise<void>
  addSubject: (data: Omit<StudySubject, 'id' | 'createdAt'>) => Promise<StudySubject>
  updateSubject: (id: string, updates: Partial<StudySubject>) => Promise<StudySubject>
  deleteSubject: (id: string) => Promise<void>

  addSession: (data: Omit<StudySession, 'id' | 'createdAt'>) => Promise<StudySession>
  deleteSession: (id: string) => Promise<void>

  getTodayMinutes: () => number
  getWeeklyMinutes: () => number
  getSubjectBreakdown: () => { subject: StudySubject; minutes: number; percentage: number }[]
}

export const useStudyStore = create<StudyState>((set, get) => ({
  subjects: [],
  sessions: [],
  isLoading: true,

  loadStudyData: async () => {
    set({ isLoading: true })
    const [subjects, sessions] = await Promise.all([
      studyService.getSubjects(),
      studyService.getSessions(),
    ])
    set({ subjects, sessions, isLoading: false })
  },

  addSubject: async (data) => {
    const newSubj = await studyService.createSubject(data)
    set((state) => ({ subjects: [...state.subjects, newSubj] }))
    soundEffects.playTick()
    return newSubj
  },

  updateSubject: async (id, updates) => {
    const updated = await studyService.updateSubject(id, updates)
    set((state) => ({
      subjects: state.subjects.map((s) => (s.id === id ? updated : s)),
    }))
    return updated
  },

  deleteSubject: async (id) => {
    await studyService.deleteSubject(id)
    set((state) => ({
      subjects: state.subjects.filter((s) => s.id !== id),
    }))
  },

  addSession: async (data) => {
    const newSess = await studyService.createSession(data)
    set((state) => ({ sessions: [newSess, ...state.sessions] }))
    soundEffects.playComplete()
    triggerConfetti()
    return newSess
  },

  deleteSession: async (id) => {
    await studyService.deleteSession(id)
    set((state) => ({
      sessions: state.sessions.filter((s) => s.id !== id),
    }))
  },

  getTodayMinutes: () => {
    const today = getTodayDateString()
    return get()
      .sessions.filter((s) => s.date === today)
      .reduce((acc, s) => acc + s.durationMinutes, 0)
  },

  getWeeklyMinutes: () => {
    const weekAgo = subDays(new Date(), 7)
    return get()
      .sessions.filter((s) => {
        try {
          return isAfter(parseISO(s.date), weekAgo)
        } catch {
          return false
        }
      })
      .reduce((acc, s) => acc + s.durationMinutes, 0)
  },

  getSubjectBreakdown: () => {
    const { subjects, sessions } = get()
    const weekAgo = subDays(new Date(), 7)
    const recent = sessions.filter((s) => {
      try {
        return isAfter(parseISO(s.date), weekAgo)
      } catch {
        return false
      }
    })

    const totalRecentMins = recent.reduce((acc, s) => acc + s.durationMinutes, 0) || 1

    return subjects.map((subject) => {
      const minutes = recent
        .filter((s) => s.subjectId === subject.id)
        .reduce((acc, s) => acc + s.durationMinutes, 0)
      const percentage = Math.round((minutes / totalRecentMins) * 100)
      return { subject, minutes, percentage }
    })
  },
}))
