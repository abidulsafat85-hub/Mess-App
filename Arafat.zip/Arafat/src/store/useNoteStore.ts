import { create } from 'zustand'
import { Note, NoteCategory } from '@/types'
import { noteService } from '@/services/noteService'
import { soundEffects } from '@/utils/effects'

interface NoteState {
  notes: Note[]
  isLoading: boolean
  categoryFilter: NoteCategory | 'all'
  searchQuery: string

  loadNotes: () => Promise<void>
  addNote: (data: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Note>
  updateNote: (id: string, updates: Partial<Note>) => Promise<Note>
  deleteNote: (id: string) => Promise<void>
  togglePin: (id: string) => Promise<void>

  setCategoryFilter: (cat: NoteCategory | 'all') => void
  setSearchQuery: (query: string) => void
  getFilteredNotes: () => Note[]
}

export const useNoteStore = create<NoteState>((set, get) => ({
  notes: [],
  isLoading: true,
  categoryFilter: 'all',
  searchQuery: '',

  loadNotes: async () => {
    set({ isLoading: true })
    const list = await noteService.getNotes()
    set({ notes: list, isLoading: false })
  },

  addNote: async (data) => {
    const newNote = await noteService.createNote(data)
    set((state) => ({ notes: [newNote, ...state.notes] }))
    soundEffects.playTick()
    return newNote
  },

  updateNote: async (id, updates) => {
    const updated = await noteService.updateNote(id, updates)
    set((state) => ({
      notes: state.notes.map((n) => (n.id === id ? updated : n)),
    }))
    return updated
  },

  deleteNote: async (id) => {
    await noteService.deleteNote(id)
    set((state) => ({
      notes: state.notes.filter((n) => n.id !== id),
    }))
  },

  togglePin: async (id) => {
    const updated = await noteService.togglePin(id)
    set((state) => ({
      notes: state.notes.map((n) => (n.id === id ? updated : n)),
    }))
    soundEffects.playTick()
  },

  setCategoryFilter: (categoryFilter) => set({ categoryFilter }),
  setSearchQuery: (searchQuery) => set({ searchQuery }),

  getFilteredNotes: () => {
    const { notes, categoryFilter, searchQuery } = get()
    return notes
      .filter((note) => {
        if (categoryFilter !== 'all' && note.category !== categoryFilter) return false
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase()
          const matchTitle = note.title.toLowerCase().includes(q)
          const matchContent = note.content.toLowerCase().includes(q)
          const matchTags = note.tags.some((t) => t.toLowerCase().includes(q))
          if (!matchTitle && !matchContent && !matchTags) return false
        }
        return true
      })
      .sort((a, b) => {
        // Pinned notes come first
        if (a.pinned && !b.pinned) return -1
        if (!a.pinned && b.pinned) return 1
        return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
      })
  },
}))
