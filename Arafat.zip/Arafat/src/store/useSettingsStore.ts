import { create } from 'zustand'
import { UserSettings, AccentColor, ThemeMode } from '@/types'
import { storageService } from '@/services/storage'
import { sampleSettings } from '@/data/sampleData'

const KEY = storageService.getKeys().SETTINGS

interface SettingsState {
  settings: UserSettings
  updateSettings: (partial: Partial<UserSettings>) => void
  setTheme: (theme: ThemeMode) => void
  setAccentColor: (accent: AccentColor) => void
  setOnboarded: (onboarded: boolean) => void
}

function applyThemeToDOM(theme: ThemeMode, accent: AccentColor) {
  const root = document.documentElement
  root.setAttribute('data-accent', accent)

  let isDark = false
  if (theme === 'dark') {
    isDark = true
  } else if (theme === 'system') {
    isDark = window.matchMedia('(prefers-color-scheme: dark)').matches
  }

  if (isDark) {
    root.classList.add('dark')
  } else {
    root.classList.remove('dark')
  }
}

const initialSettings = storageService.getItem<UserSettings>(KEY, sampleSettings)
applyThemeToDOM(initialSettings.theme, initialSettings.accentColor)

export const useSettingsStore = create<SettingsState>((set, get) => ({
  settings: initialSettings,

  updateSettings: (partial) => {
    const updated = { ...get().settings, ...partial }
    storageService.setItem(KEY, updated)
    applyThemeToDOM(updated.theme, updated.accentColor)
    set({ settings: updated })
  },

  setTheme: (theme) => {
    get().updateSettings({ theme })
  },

  setAccentColor: (accentColor) => {
    get().updateSettings({ accentColor })
  },

  setOnboarded: (onboarded) => {
    get().updateSettings({ onboarded })
  },
}))
