import { create } from 'zustand'
import { NavigationTab } from '@/types'

export type QuickAddType = 'task' | 'session' | 'habit' | 'goal' | 'note'

interface ToastInfo {
  id: number
  message: string
  type: 'success' | 'info' | 'error'
}

interface UIState {
  activeTab: NavigationTab
  isSidebarCollapsed: boolean
  isQuickAddOpen: boolean
  quickAddType: QuickAddType
  isSearchOpen: boolean
  isDailyReviewOpen: boolean
  isTaskModalOpen: boolean
  editingTaskId: string | null
  isFocusModalOpen: boolean
  toasts: ToastInfo[]

  setActiveTab: (tab: NavigationTab) => void
  toggleSidebar: () => void
  setSidebarCollapsed: (collapsed: boolean) => void

  openQuickAdd: (type?: QuickAddType) => void
  closeQuickAdd: () => void

  setSearchOpen: (open: boolean) => void
  setDailyReviewOpen: (open: boolean) => void

  openTaskModal: (taskId?: string | null) => void
  closeTaskModal: () => void

  setFocusModalOpen: (open: boolean) => void

  showToast: (message: string, type?: 'success' | 'info' | 'error') => void
  removeToast: (id: number) => void
}

let toastCounter = 0

export const useUIStore = create<UIState>((set, get) => ({
  activeTab: 'today',
  isSidebarCollapsed: false,
  isQuickAddOpen: false,
  quickAddType: 'task',
  isSearchOpen: false,
  isDailyReviewOpen: false,
  isTaskModalOpen: false,
  editingTaskId: null,
  isFocusModalOpen: false,
  toasts: [],

  setActiveTab: (tab) => set({ activeTab: tab }),
  toggleSidebar: () => set((state) => ({ isSidebarCollapsed: !state.isSidebarCollapsed })),
  setSidebarCollapsed: (isSidebarCollapsed) => set({ isSidebarCollapsed }),

  openQuickAdd: (type = 'task') => set({ isQuickAddOpen: true, quickAddType: type }),
  closeQuickAdd: () => set({ isQuickAddOpen: false }),

  setSearchOpen: (isSearchOpen) => set({ isSearchOpen }),
  setDailyReviewOpen: (isDailyReviewOpen) => set({ isDailyReviewOpen }),

  openTaskModal: (taskId = null) => set({ isTaskModalOpen: true, editingTaskId: taskId }),
  closeTaskModal: () => set({ isTaskModalOpen: false, editingTaskId: null }),

  setFocusModalOpen: (isFocusModalOpen) => set({ isFocusModalOpen }),

  showToast: (message, type = 'success') => {
    const id = ++toastCounter
    const newToast = { id, message, type }
    set((state) => ({ toasts: [...state.toasts, newToast] }))

    setTimeout(() => {
      get().removeToast(id)
    }, 3200)
  },

  removeToast: (id) => {
    set((state) => ({
      toasts: state.toasts.filter((t) => t.id !== id),
    }))
  },
}))
