import { create } from 'zustand'
import { soundEffects, triggerConfetti } from '@/utils/effects'
import { getTodayDateString } from '@/utils/date'
import { studyService } from '@/services/studyService'
import { taskService } from '@/services/taskService'

export type FocusMode = 'work' | 'break' | 'long-break'
export type FocusStatus = 'idle' | 'running' | 'paused'

interface FocusState {
  mode: FocusMode
  status: FocusStatus
  workMinutes: number
  breakMinutes: number
  longBreakMinutes: number
  secondsRemaining: number
  selectedTaskId: string | null
  selectedSubjectId: string | null
  completedRounds: number
  ambientSound: 'none' | 'whitenoise' | 'rain' | 'waves'
  isAmbientPlaying: boolean

  setPreset: (work: number, breakMins: number) => void
  setSelectedTask: (taskId: string | null) => void
  setSelectedSubject: (subjectId: string | null) => void
  setAmbientSound: (sound: 'none' | 'whitenoise' | 'rain' | 'waves') => void

  startTimer: () => void
  pauseTimer: () => void
  resumeTimer: () => void
  resetTimer: () => void
  finishSession: (early?: boolean) => Promise<void>
  skipBreak: () => void
  tick: () => void
}

export const useFocusStore = create<FocusState>((set, get) => ({
  mode: 'work',
  status: 'idle',
  workMinutes: 25,
  breakMinutes: 5,
  longBreakMinutes: 15,
  secondsRemaining: 25 * 60,
  selectedTaskId: null,
  selectedSubjectId: null,
  completedRounds: 0,
  ambientSound: 'none',
  isAmbientPlaying: false,

  setPreset: (work, breakMins) => {
    set({
      workMinutes: work,
      breakMinutes: breakMins,
      secondsRemaining: work * 60,
      mode: 'work',
      status: 'idle',
    })
  },

  setSelectedTask: (selectedTaskId) => set({ selectedTaskId }),
  setSelectedSubject: (selectedSubjectId) => set({ selectedSubjectId }),
  setAmbientSound: (ambientSound) => set({ ambientSound }),

  startTimer: () => {
    soundEffects.playTick()
    set({ status: 'running' })
  },

  pauseTimer: () => {
    soundEffects.playTick()
    set({ status: 'paused' })
  },

  resumeTimer: () => {
    soundEffects.playTick()
    set({ status: 'running' })
  },

  resetTimer: () => {
    const { mode, workMinutes, breakMinutes, longBreakMinutes } = get()
    let mins = workMinutes
    if (mode === 'break') mins = breakMinutes
    if (mode === 'long-break') mins = longBreakMinutes

    set({
      status: 'idle',
      secondsRemaining: mins * 60,
    })
  },

  finishSession: async (early = false) => {
    const { mode, workMinutes, secondsRemaining, selectedTaskId, selectedSubjectId, completedRounds, breakMinutes, longBreakMinutes } = get()

    if (mode === 'work') {
      const minutesSpent = early
        ? Math.max(1, Math.round((workMinutes * 60 - secondsRemaining) / 60))
        : workMinutes

      // Automatically add study session to stats!
      const subjects = await studyService.getSubjects()
      const subjectId = selectedSubjectId || (subjects.length > 0 ? subjects[0].id : 'subj-1')

      let topicName = 'Focused Work Session'
      if (selectedTaskId) {
        const tasks = await taskService.getTasks()
        const task = tasks.find((t) => t.id === selectedTaskId)
        if (task) topicName = task.title
      }

      await studyService.createSession({
        subjectId,
        topic: topicName,
        durationMinutes: minutesSpent,
        date: getTodayDateString(),
        taskId: selectedTaskId || undefined,
        notes: `Pomodoro focus session (${minutesSpent} mins)`,
      })

      const newRounds = completedRounds + 1
      soundEffects.playBell()
      triggerConfetti()

      // Switch to break
      const isLongBreak = newRounds % 4 === 0
      const nextMode: FocusMode = isLongBreak ? 'long-break' : 'break'
      const nextMins = isLongBreak ? longBreakMinutes : breakMinutes

      set({
        completedRounds: newRounds,
        mode: nextMode,
        status: 'idle',
        secondsRemaining: nextMins * 60,
      })
    } else {
      // Finished break, switch to work
      set({
        mode: 'work',
        status: 'idle',
        secondsRemaining: workMinutes * 60,
      })
    }
  },

  skipBreak: () => {
    const { workMinutes } = get()
    set({
      mode: 'work',
      status: 'idle',
      secondsRemaining: workMinutes * 60,
    })
  },

  tick: () => {
    const { secondsRemaining, status } = get()
    if (status !== 'running') return

    if (secondsRemaining <= 1) {
      get().finishSession(false)
    } else {
      set({ secondsRemaining: secondsRemaining - 1 })
    }
  },
}))
