import { create } from 'zustand'
import { Habit } from '@/types'
import { habitService } from '@/services/habitService'
import { getTodayDateString } from '@/utils/date'
import { triggerConfetti, soundEffects } from '@/utils/effects'

interface HabitState {
  habits: Habit[]
  isLoading: boolean

  loadHabits: () => Promise<void>
  addHabit: (data: Omit<Habit, 'id' | 'streak' | 'longestStreak' | 'logs' | 'createdAt'>) => Promise<Habit>
  updateHabit: (id: string, updates: Partial<Habit>) => Promise<Habit>
  deleteHabit: (id: string) => Promise<void>
  toggleHabitDate: (id: string, dateString: string) => Promise<void>
  getTodayHabitsProgress: () => { completed: number; total: number; percentage: number }
}

export const useHabitStore = create<HabitState>((set, get) => ({
  habits: [],
  isLoading: true,

  loadHabits: async () => {
    set({ isLoading: true })
    const list = await habitService.getHabits()
    set({ habits: list, isLoading: false })
  },

  addHabit: async (data) => {
    const newHabit = await habitService.createHabit(data)
    set((state) => ({ habits: [newHabit, ...state.habits] }))
    soundEffects.playTick()
    return newHabit
  },

  updateHabit: async (id, updates) => {
    const updated = await habitService.updateHabit(id, updates)
    set((state) => ({
      habits: state.habits.map((h) => (h.id === id ? updated : h)),
    }))
    return updated
  },

  deleteHabit: async (id) => {
    await habitService.deleteHabit(id)
    set((state) => ({
      habits: state.habits.filter((h) => h.id !== id),
    }))
  },

  toggleHabitDate: async (id, dateString) => {
    const habit = get().habits.find((h) => h.id === id)
    if (!habit) return

    const wasLogged = !!habit.logs[dateString]
    const updated = await habitService.toggleDate(id, dateString)

    set((state) => ({
      habits: state.habits.map((h) => (h.id === id ? updated : h)),
    }))

    if (!wasLogged) {
      soundEffects.playComplete()
      triggerConfetti()
    } else {
      soundEffects.playTick()
    }
  },

  getTodayHabitsProgress: () => {
    const today = getTodayDateString()
    const list = get().habits
    if (list.length === 0) return { completed: 0, total: 0, percentage: 0 }

    const completed = list.filter((h) => !!h.logs[today]).length
    return {
      completed,
      total: list.length,
      percentage: Math.round((completed / list.length) * 100),
    }
  },
}))
