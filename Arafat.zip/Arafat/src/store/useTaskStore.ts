import { create } from 'zustand'
import { Task, TaskFilterView, TaskSortOption, Priority, TaskCategory } from '@/types'
import { taskService } from '@/services/taskService'
import { triggerConfetti, soundEffects } from '@/utils/effects'
import { isTaskOverdue, isTaskToday, isTaskUpcoming } from '@/utils/date'

interface TaskState {
  tasks: Task[]
  isLoading: boolean
  filter: TaskFilterView
  categoryFilter: string
  priorityFilter: string
  sortBy: TaskSortOption
  searchQuery: string

  loadTasks: () => Promise<void>
  addTask: (data: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Task>
  addBatchTasks: (dataList: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>[]) => Promise<void>
  updateTask: (id: string, updates: Partial<Task>) => Promise<Task>
  deleteTask: (id: string) => Promise<void>
  toggleTask: (id: string) => Promise<void>
  toggleSubtask: (taskId: string, subtaskId: string) => Promise<void>
  addSubtask: (taskId: string, title: string) => Promise<void>
  removeSubtask: (taskId: string, subtaskId: string) => Promise<void>

  setFilter: (filter: TaskFilterView) => void
  setCategoryFilter: (cat: string) => void
  setPriorityFilter: (prio: string) => void
  setSortBy: (sort: TaskSortOption) => void
  setSearchQuery: (query: string) => void

  getFilteredTasks: () => Task[]
  getTodayTasks: () => Task[]
  getFocusNextTask: () => Task | null
}

export const useTaskStore = create<TaskState>((set, get) => ({
  tasks: [],
  isLoading: true,
  filter: 'today',
  categoryFilter: 'all',
  priorityFilter: 'all',
  sortBy: 'dueDate',
  searchQuery: '',

  loadTasks: async () => {
    set({ isLoading: true })
    const list = await taskService.getTasks()
    set({ tasks: list, isLoading: false })
  },

  addTask: async (data) => {
    const newTask = await taskService.createTask(data)
    set((state) => ({ tasks: [newTask, ...state.tasks] }))
    soundEffects.playTick()
    return newTask
  },

  addBatchTasks: async (dataList) => {
    const created: Task[] = []
    for (const item of dataList) {
      const task = await taskService.createTask(item)
      created.push(task)
    }
    set((state) => ({ tasks: [...created, ...state.tasks] }))
    triggerConfetti()
  },

  updateTask: async (id, updates) => {
    const updated = await taskService.updateTask(id, updates)
    set((state) => ({
      tasks: state.tasks.map((t) => (t.id === id ? updated : t)),
    }))
    return updated
  },

  deleteTask: async (id) => {
    await taskService.deleteTask(id)
    set((state) => ({
      tasks: state.tasks.filter((t) => t.id !== id),
    }))
  },

  toggleTask: async (id) => {
    const existing = get().tasks.find((t) => t.id === id)
    if (!existing) return

    const wasCompleted = existing.completed
    const updated = await taskService.toggleComplete(id)

    set((state) => ({
      tasks: state.tasks.map((t) => (t.id === id ? updated : t)),
    }))

    if (!wasCompleted) {
      soundEffects.playComplete()
      triggerConfetti()
    } else {
      soundEffects.playTick()
    }
  },

  toggleSubtask: async (taskId, subtaskId) => {
    const updated = await taskService.toggleSubtask(taskId, subtaskId)
    set((state) => ({
      tasks: state.tasks.map((t) => (t.id === taskId ? updated : t)),
    }))
    soundEffects.playTick()
  },

  addSubtask: async (taskId, title) => {
    const task = get().tasks.find((t) => t.id === taskId)
    if (!task) return

    const newSubtask = {
      id: 'sub_' + Math.random().toString(36).substring(2, 9),
      title,
      completed: false,
    }
    const updated = await taskService.updateTask(taskId, {
      subtasks: [...task.subtasks, newSubtask],
    })
    set((state) => ({
      tasks: state.tasks.map((t) => (t.id === taskId ? updated : t)),
    }))
  },

  removeSubtask: async (taskId, subtaskId) => {
    const task = get().tasks.find((t) => t.id === taskId)
    if (!task) return

    const updated = await taskService.updateTask(taskId, {
      subtasks: task.subtasks.filter((st) => st.id !== subtaskId),
    })
    set((state) => ({
      tasks: state.tasks.map((t) => (t.id === taskId ? updated : t)),
    }))
  },

  setFilter: (filter) => set({ filter }),
  setCategoryFilter: (categoryFilter) => set({ categoryFilter }),
  setPriorityFilter: (priorityFilter) => set({ priorityFilter }),
  setSortBy: (sortBy) => set({ sortBy }),
  setSearchQuery: (searchQuery) => set({ searchQuery }),

  getTodayTasks: () => {
    return get().tasks.filter((t) => isTaskToday(t.dueDate))
  },

  getFocusNextTask: () => {
    const uncompleted = get().tasks.filter((t) => !t.completed && (isTaskToday(t.dueDate) || isTaskOverdue(t.dueDate, false)))
    if (uncompleted.length === 0) return null

    // Sort by priority (urgent > high > medium > low)
    const prioScore: Record<Priority, number> = {
      urgent: 4,
      high: 3,
      medium: 2,
      low: 1,
    }
    return [...uncompleted].sort((a, b) => prioScore[b.priority] - prioScore[a.priority])[0]
  },

  getFilteredTasks: () => {
    const { tasks, filter, categoryFilter, priorityFilter, sortBy, searchQuery } = get()

    let result = tasks.filter((task) => {
      // 1. View filter
      if (filter === 'today') {
        if (!isTaskToday(task.dueDate)) return false
      } else if (filter === 'upcoming') {
        if (!isTaskUpcoming(task.dueDate) || task.completed) return false
      } else if (filter === 'overdue') {
        if (!isTaskOverdue(task.dueDate, task.completed)) return false
      } else if (filter === 'completed') {
        if (!task.completed) return false
      }

      // 2. Category filter
      if (categoryFilter !== 'all' && task.category !== categoryFilter) {
        return false
      }

      // 3. Priority filter
      if (priorityFilter !== 'all' && task.priority !== priorityFilter) {
        return false
      }

      // 4. Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase()
        const matchTitle = task.title.toLowerCase().includes(q)
        const matchDesc = task.description?.toLowerCase().includes(q)
        const matchTags = task.tags.some((tag) => tag.toLowerCase().includes(q))
        if (!matchTitle && !matchDesc && !matchTags) return false
      }

      return true
    })

    // Sorting
    result.sort((a, b) => {
      if (sortBy === 'priority') {
        const prioScore: Record<Priority, number> = { urgent: 4, high: 3, medium: 2, low: 1 }
        return prioScore[b.priority] - prioScore[a.priority]
      }
      if (sortBy === 'title') {
        return a.title.localeCompare(b.title)
      }
      if (sortBy === 'createdAt') {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      }
      // default: dueDate
      return a.dueDate.localeCompare(b.dueDate)
    })

    return result
  },
}))
