export interface AppExportData {
  version: string
  exportedAt: string
  settings: unknown
  tasks: unknown
  habits: unknown
  goals: unknown
  subjects: unknown
  sessions: unknown
  notes: unknown
  reviews: unknown
}

const STORAGE_KEYS = {
  SETTINGS: 'aura_settings_v1',
  TASKS: 'aura_tasks_v1',
  HABITS: 'aura_habits_v1',
  GOALS: 'aura_goals_v1',
  SUBJECTS: 'aura_subjects_v1',
  SESSIONS: 'aura_sessions_v1',
  NOTES: 'aura_notes_v1',
  REVIEWS: 'aura_reviews_v1',
  NOTIFICATIONS: 'aura_notifications_v1',
}

class StorageService {
  getItem<T>(key: string, defaultValue: T): T {
    try {
      const raw = localStorage.getItem(key)
      if (raw === null) return defaultValue
      return JSON.parse(raw) as T
    } catch (e) {
      console.warn(`Error reading localStorage key "${key}":`, e)
      return defaultValue
    }
  }

  setItem<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value))
    } catch (e) {
      console.error(`Error saving localStorage key "${key}":`, e)
    }
  }

  removeItem(key: string): void {
    try {
      localStorage.removeItem(key)
    } catch (e) {
      console.error(`Error removing localStorage key "${key}":`, e)
    }
  }

  exportAllData(): string {
    const exportData: AppExportData = {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      settings: this.getItem(STORAGE_KEYS.SETTINGS, null),
      tasks: this.getItem(STORAGE_KEYS.TASKS, []),
      habits: this.getItem(STORAGE_KEYS.HABITS, []),
      goals: this.getItem(STORAGE_KEYS.GOALS, []),
      subjects: this.getItem(STORAGE_KEYS.SUBJECTS, []),
      sessions: this.getItem(STORAGE_KEYS.SESSIONS, []),
      notes: this.getItem(STORAGE_KEYS.NOTES, []),
      reviews: this.getItem(STORAGE_KEYS.REVIEWS, []),
    }
    return JSON.stringify(exportData, null, 2)
  }

  importAllData(jsonString: string): boolean {
    try {
      const parsed = JSON.parse(jsonString) as AppExportData
      if (!parsed || typeof parsed !== 'object') return false

      if (parsed.settings) this.setItem(STORAGE_KEYS.SETTINGS, parsed.settings)
      if (Array.isArray(parsed.tasks)) this.setItem(STORAGE_KEYS.TASKS, parsed.tasks)
      if (Array.isArray(parsed.habits)) this.setItem(STORAGE_KEYS.HABITS, parsed.habits)
      if (Array.isArray(parsed.goals)) this.setItem(STORAGE_KEYS.GOALS, parsed.goals)
      if (Array.isArray(parsed.subjects)) this.setItem(STORAGE_KEYS.SUBJECTS, parsed.subjects)
      if (Array.isArray(parsed.sessions)) this.setItem(STORAGE_KEYS.SESSIONS, parsed.sessions)
      if (Array.isArray(parsed.notes)) this.setItem(STORAGE_KEYS.NOTES, parsed.notes)
      if (Array.isArray(parsed.reviews)) this.setItem(STORAGE_KEYS.REVIEWS, parsed.reviews)

      return true
    } catch (e) {
      console.error('Failed to import backup data:', e)
      return false
    }
  }

  clearAllData(): void {
    Object.values(STORAGE_KEYS).forEach((key) => {
      localStorage.removeItem(key)
    })
  }

  getKeys() {
    return STORAGE_KEYS
  }
}

export const storageService = new StorageService()
