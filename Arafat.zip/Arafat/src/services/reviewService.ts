import { DailyReview } from '@/types'
import { storageService } from './storage'
import { sampleReviews } from '@/data/sampleData'
import { getTodayDateString } from '@/utils/date'

const KEY = storageService.getKeys().REVIEWS

export const reviewService = {
  async getReviews(): Promise<DailyReview[]> {
    return storageService.getItem<DailyReview[]>(KEY, sampleReviews)
  },

  async saveReviews(reviews: DailyReview[]): Promise<void> {
    storageService.setItem(KEY, reviews)
  },

  async submitDailyReview(
    data: Omit<DailyReview, 'id' | 'createdAt'>
  ): Promise<DailyReview> {
    const reviews = await this.getReviews()
    const today = getTodayDateString()
    const existingIndex = reviews.findIndex((r) => r.date === data.date)

    const review: DailyReview = {
      ...data,
      id: 'rev_' + Math.random().toString(36).substring(2, 9),
      createdAt: today,
    }

    let updated: DailyReview[]
    if (existingIndex !== -1) {
      updated = [...reviews]
      updated[existingIndex] = review
    } else {
      updated = [review, ...reviews]
    }

    await this.saveReviews(updated)
    return review
  },

  async getReviewForDate(dateString: string): Promise<DailyReview | null> {
    const reviews = await this.getReviews()
    return reviews.find((r) => r.date === dateString) || null
  },
}
