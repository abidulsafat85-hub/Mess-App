import { Habit } from '@/types'
import { storageService } from './storage'
import { sampleHabits } from '@/data/sampleData'
import { getTodayDateString } from '@/utils/date'
import { subDays, format } from 'date-fns'

const KEY = storageService.getKeys().HABITS

function recalculateStreak(logs: Record<string, boolean>): { streak: number; longestStreak: number } {
  const today = new Date()
  let currentStreak = 0
  let checkDate = today

  // Check if today is completed
  const todayStr = format(today, 'yyyy-MM-dd')
  const yestStr = format(subDays(today, 1), 'yyyy-MM-dd')

  if (!logs[todayStr] && !logs[yestStr]) {
    currentStreak = 0
  } else {
    // If not completed today yet, check starting from yesterday
    if (!logs[todayStr]) {
      checkDate = subDays(today, 1)
    }

    while (true) {
      const dateStr = format(checkDate, 'yyyy-MM-dd')
      if (logs[dateStr]) {
        currentStreak++
        checkDate = subDays(checkDate, 1)
      } else {
        break
      }
    }
  }

  // Count max consecutive in entire logs
  const sortedDates = Object.keys(logs)
    .filter((d) => logs[d])
    .sort()

  let maxStreak = currentStreak
  let tempStreak = 0
  let prevDate: Date | null = null

  for (const dateStr of sortedDates) {
    const curDate = new Date(dateStr)
    if (prevDate) {
      const diffDays = Math.round((curDate.getTime() - prevDate.getTime()) / (1000 * 3600 * 24))
      if (diffDays === 1) {
        tempStreak++
      } else if (diffDays > 1) {
        tempStreak = 1
      }
    } else {
      tempStreak = 1
    }
    prevDate = curDate
    if (tempStreak > maxStreak) {
      maxStreak = tempStreak
    }
  }

  return { streak: currentStreak, longestStreak: Math.max(currentStreak, maxStreak) }
}

export const habitService = {
  async getHabits(): Promise<Habit[]> {
    return storageService.getItem<Habit[]>(KEY, sampleHabits)
  },

  async saveHabits(habits: Habit[]): Promise<void> {
    storageService.setItem(KEY, habits)
  },

  async createHabit(
    data: Omit<Habit, 'id' | 'streak' | 'longestStreak' | 'logs' | 'createdAt'>
  ): Promise<Habit> {
    const habits = await this.getHabits()
    const newHabit: Habit = {
      ...data,
      id: 'habit_' + Math.random().toString(36).substring(2, 9),
      streak: 0,
      longestStreak: 0,
      logs: {},
      createdAt: getTodayDateString(),
    }
    const updated = [newHabit, ...habits]
    await this.saveHabits(updated)
    return newHabit
  },

  async updateHabit(id: string, updates: Partial<Habit>): Promise<Habit> {
    const habits = await this.getHabits()
    const index = habits.findIndex((h) => h.id === id)
    if (index === -1) throw new Error(`Habit ${id} not found`)

    const current = habits[index]
    const updatedLogs = updates.logs ? updates.logs : current.logs
    const { streak, longestStreak } = recalculateStreak(updatedLogs)

    const updatedHabit: Habit = {
      ...current,
      ...updates,
      streak,
      longestStreak: Math.max(longestStreak, current.longestStreak, streak),
    }

    habits[index] = updatedHabit
    await this.saveHabits(habits)
    return updatedHabit
  },

  async toggleDate(id: string, dateString: string): Promise<Habit> {
    const habits = await this.getHabits()
    const habit = habits.find((h) => h.id === id)
    if (!habit) throw new Error(`Habit ${id} not found`)

    const newLogs = { ...habit.logs }
    if (newLogs[dateString]) {
      delete newLogs[dateString]
    } else {
      newLogs[dateString] = true
    }

    return this.updateHabit(id, { logs: newLogs })
  },

  async deleteHabit(id: string): Promise<boolean> {
    const habits = await this.getHabits()
    const filtered = habits.filter((h) => h.id !== id)
    await this.saveHabits(filtered)
    return true
  },
}
