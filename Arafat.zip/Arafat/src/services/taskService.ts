import { Task } from '@/types'
import { storageService } from './storage'
import { sampleTasks } from '@/data/sampleData'
import { getTodayDateString } from '@/utils/date'

const KEY = storageService.getKeys().TASKS

export const taskService = {
  async getTasks(): Promise<Task[]> {
    return storageService.getItem<Task[]>(KEY, sampleTasks)
  },

  async saveTasks(tasks: Task[]): Promise<void> {
    storageService.setItem(KEY, tasks)
  },

  async createTask(
    data: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>
  ): Promise<Task> {
    const tasks = await this.getTasks()
    const now = new Date().toISOString()
    const newTask: Task = {
      ...data,
      id: 'task_' + Math.random().toString(36).substring(2, 9) + Date.now().toString(36),
      createdAt: now,
      updatedAt: now,
    }
    const updated = [newTask, ...tasks]
    await this.saveTasks(updated)
    return newTask
  },

  async updateTask(id: string, updates: Partial<Task>): Promise<Task> {
    const tasks = await this.getTasks()
    const index = tasks.findIndex((t) => t.id === id)
    if (index === -1) throw new Error(`Task with id ${id} not found`)

    const updatedTask: Task = {
      ...tasks[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    }
    tasks[index] = updatedTask
    await this.saveTasks(tasks)
    return updatedTask
  },

  async deleteTask(id: string): Promise<boolean> {
    const tasks = await this.getTasks()
    const filtered = tasks.filter((t) => t.id !== id)
    await this.saveTasks(filtered)
    return true
  },

  async toggleComplete(id: string): Promise<Task> {
    const tasks = await this.getTasks()
    const task = tasks.find((t) => t.id === id)
    if (!task) throw new Error(`Task with id ${id} not found`)

    const willBeCompleted = !task.completed
    return this.updateTask(id, {
      completed: willBeCompleted,
      completedAt: willBeCompleted ? getTodayDateString() : undefined,
    })
  },

  async toggleSubtask(taskId: string, subtaskId: string): Promise<Task> {
    const tasks = await this.getTasks()
    const task = tasks.find((t) => t.id === taskId)
    if (!task) throw new Error(`Task with id ${taskId} not found`)

    const subtasks = task.subtasks.map((st) =>
      st.id === subtaskId ? { ...st, completed: !st.completed } : st
    )
    return this.updateTask(taskId, { subtasks })
  },
}
