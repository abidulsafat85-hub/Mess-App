import { NotificationItem, NotificationType } from '@/types'
import { storageService } from './storage'

const KEY = storageService.getKeys().NOTIFICATIONS

export const notificationService = {
  getNotifications(): NotificationItem[] {
    const defaultNotifications: NotificationItem[] = [
      {
        id: 'notif-1',
        title: 'MAT102 Discrete Math Assignment',
        message: 'Due tonight at 10:00 PM. 2 subtasks remaining.',
        type: 'task',
        read: false,
        timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
      },
      {
        id: 'notif-2',
        title: 'Daily Study Goal in Reach!',
        message: "You've studied 2h 35m today. Just 25 minutes left to hit your 3h target!",
        type: 'study',
        read: false,
        timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
      },
      {
        id: 'notif-3',
        title: '🔥 12-Day Habit Streak',
        message: 'Amazing consistency on your "Study 2+ hours daily" habit!',
        type: 'habit',
        read: true,
        timestamp: new Date(Date.now() - 1000 * 60 * 360).toISOString(),
      },
      {
        id: 'notif-4',
        title: 'End of Day Review Ready',
        message: 'Take 60 seconds to reflect on today’s wins and calibrate tomorrow.',
        type: 'review',
        read: true,
        timestamp: new Date(Date.now() - 1000 * 60 * 720).toISOString(),
      },
    ]
    return storageService.getItem<NotificationItem[]>(KEY, defaultNotifications)
  },

  saveNotifications(items: NotificationItem[]): void {
    storageService.setItem(KEY, items)
  },

  addNotification(title: string, message: string, type: NotificationType): NotificationItem {
    const list = this.getNotifications()
    const item: NotificationItem = {
      id: 'notif_' + Math.random().toString(36).substring(2, 9),
      title,
      message,
      type,
      read: false,
      timestamp: new Date().toISOString(),
    }
    this.saveNotifications([item, ...list])
    return item
  },

  markAsRead(id: string): void {
    const list = this.getNotifications()
    const updated = list.map((n) => (n.id === id ? { ...n, read: true } : n))
    this.saveNotifications(updated)
  },

  markAllAsRead(): void {
    const list = this.getNotifications()
    const updated = list.map((n) => ({ ...n, read: true }))
    this.saveNotifications(updated)
  },

  clearAll(): void {
    this.saveNotifications([])
  },
}
