import { Goal, Milestone } from '@/types'
import { storageService } from './storage'
import { sampleGoals } from '@/data/sampleData'
import { getTodayDateString } from '@/utils/date'

const KEY = storageService.getKeys().GOALS

function calculateProgress(milestones: Milestone[]): number {
  if (!milestones || milestones.length === 0) return 0
  const completed = milestones.filter((m) => m.completed).length
  return Math.round((completed / milestones.length) * 100)
}

export const goalService = {
  async getGoals(): Promise<Goal[]> {
    return storageService.getItem<Goal[]>(KEY, sampleGoals)
  },

  async saveGoals(goals: Goal[]): Promise<void> {
    storageService.setItem(KEY, goals)
  },

  async createGoal(
    data: Omit<Goal, 'id' | 'progress' | 'createdAt'>
  ): Promise<Goal> {
    const goals = await this.getGoals()
    const progress = calculateProgress(data.milestones || [])
    const newGoal: Goal = {
      ...data,
      id: 'goal_' + Math.random().toString(36).substring(2, 9),
      progress,
      createdAt: getTodayDateString(),
    }
    const updated = [newGoal, ...goals]
    await this.saveGoals(updated)
    return newGoal
  },

  async updateGoal(id: string, updates: Partial<Goal>): Promise<Goal> {
    const goals = await this.getGoals()
    const index = goals.findIndex((g) => g.id === id)
    if (index === -1) throw new Error(`Goal ${id} not found`)

    const current = goals[index]
    const milestones = updates.milestones !== undefined ? updates.milestones : current.milestones
    const progress = updates.progress !== undefined ? updates.progress : calculateProgress(milestones)

    const updatedGoal: Goal = {
      ...current,
      ...updates,
      milestones,
      progress,
    }
    goals[index] = updatedGoal
    await this.saveGoals(goals)
    return updatedGoal
  },

  async toggleMilestone(goalId: string, milestoneId: string): Promise<Goal> {
    const goals = await this.getGoals()
    const goal = goals.find((g) => g.id === goalId)
    if (!goal) throw new Error(`Goal ${goalId} not found`)

    const milestones = goal.milestones.map((m) =>
      m.id === milestoneId ? { ...m, completed: !m.completed } : m
    )
    const progress = calculateProgress(milestones)
    return this.updateGoal(goalId, { milestones, progress })
  },

  async addMilestone(goalId: string, title: string): Promise<Goal> {
    const goals = await this.getGoals()
    const goal = goals.find((g) => g.id === goalId)
    if (!goal) throw new Error(`Goal ${goalId} not found`)

    const newMilestone: Milestone = {
      id: 'ms_' + Math.random().toString(36).substring(2, 9),
      title,
      completed: false,
    }
    const milestones = [...goal.milestones, newMilestone]
    const progress = calculateProgress(milestones)
    return this.updateGoal(goalId, { milestones, progress })
  },

  async deleteGoal(id: string): Promise<boolean> {
    const goals = await this.getGoals()
    const filtered = goals.filter((g) => g.id !== id)
    await this.saveGoals(filtered)
    return true
  },
}
