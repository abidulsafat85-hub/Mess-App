import { StudySubject, StudySession } from '@/types'
import { storageService } from './storage'
import { sampleSubjects, sampleStudySessions } from '@/data/sampleData'
import { getTodayDateString } from '@/utils/date'
import { subDays, parseISO, isAfter } from 'date-fns'

const SUBJECTS_KEY = storageService.getKeys().SUBJECTS
const SESSIONS_KEY = storageService.getKeys().SESSIONS

export interface SubjectStats {
  subject: StudySubject
  totalMinutes: number
  weeklyMinutes: number
  monthlyMinutes: number
  recentSessions: StudySession[]
}

export const studyService = {
  async getSubjects(): Promise<StudySubject[]> {
    return storageService.getItem<StudySubject[]>(SUBJECTS_KEY, sampleSubjects)
  },

  async saveSubjects(subjects: StudySubject[]): Promise<void> {
    storageService.setItem(SUBJECTS_KEY, subjects)
  },

  async createSubject(
    data: Omit<StudySubject, 'id' | 'createdAt'>
  ): Promise<StudySubject> {
    const subjects = await this.getSubjects()
    const newSubject: StudySubject = {
      ...data,
      id: 'subj_' + Math.random().toString(36).substring(2, 9),
      createdAt: getTodayDateString(),
    }
    const updated = [...subjects, newSubject]
    await this.saveSubjects(updated)
    return newSubject
  },

  async updateSubject(id: string, updates: Partial<StudySubject>): Promise<StudySubject> {
    const subjects = await this.getSubjects()
    const index = subjects.findIndex((s) => s.id === id)
    if (index === -1) throw new Error(`Subject ${id} not found`)
    subjects[index] = { ...subjects[index], ...updates }
    await this.saveSubjects(subjects)
    return subjects[index]
  },

  async deleteSubject(id: string): Promise<boolean> {
    const subjects = await this.getSubjects()
    const filtered = subjects.filter((s) => s.id !== id)
    await this.saveSubjects(filtered)
    return true
  },

  async getSessions(): Promise<StudySession[]> {
    return storageService.getItem<StudySession[]>(SESSIONS_KEY, sampleStudySessions)
  },

  async saveSessions(sessions: StudySession[]): Promise<void> {
    storageService.setItem(SESSIONS_KEY, sessions)
  },

  async createSession(
    data: Omit<StudySession, 'id' | 'createdAt'>
  ): Promise<StudySession> {
    const sessions = await this.getSessions()
    const newSession: StudySession = {
      ...data,
      id: 'sess_' + Math.random().toString(36).substring(2, 9),
      createdAt: new Date().toISOString(),
    }
    const updated = [newSession, ...sessions]
    await this.saveSessions(updated)
    return newSession
  },

  async deleteSession(id: string): Promise<boolean> {
    const sessions = await this.getSessions()
    const filtered = sessions.filter((s) => s.id !== id)
    await this.saveSessions(filtered)
    return true
  },

  async getTodayStudyMinutes(): Promise<number> {
    const sessions = await this.getSessions()
    const today = getTodayDateString()
    return sessions
      .filter((s) => s.date === today)
      .reduce((acc, curr) => acc + curr.durationMinutes, 0)
  },

  async getSubjectStats(subjectId: string): Promise<SubjectStats> {
    const subjects = await this.getSubjects()
    const subject = subjects.find((s) => s.id === subjectId)
    if (!subject) throw new Error(`Subject ${subjectId} not found`)

    const sessions = await this.getSessions()
    const subjectSessions = sessions.filter((s) => s.subjectId === subjectId)

    const now = new Date()
    const weekAgo = subDays(now, 7)
    const monthAgo = subDays(now, 30)

    let totalMinutes = 0
    let weeklyMinutes = 0
    let monthlyMinutes = 0

    subjectSessions.forEach((s) => {
      totalMinutes += s.durationMinutes
      try {
        const sDate = parseISO(s.date)
        if (isAfter(sDate, weekAgo)) {
          weeklyMinutes += s.durationMinutes
        }
        if (isAfter(sDate, monthAgo)) {
          monthlyMinutes += s.durationMinutes
        }
      } catch {
        // ignore parse error
      }
    })

    return {
      subject,
      totalMinutes,
      weeklyMinutes,
      monthlyMinutes,
      recentSessions: subjectSessions.slice(0, 5),
    }
  },
}
