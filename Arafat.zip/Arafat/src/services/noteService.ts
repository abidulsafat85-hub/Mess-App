import { Note } from '@/types'
import { storageService } from './storage'
import { sampleNotes } from '@/data/sampleData'
import { getTodayDateString } from '@/utils/date'

const KEY = storageService.getKeys().NOTES

export const noteService = {
  async getNotes(): Promise<Note[]> {
    return storageService.getItem<Note[]>(KEY, sampleNotes)
  },

  async saveNotes(notes: Note[]): Promise<void> {
    storageService.setItem(KEY, notes)
  },

  async createNote(
    data: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>
  ): Promise<Note> {
    const notes = await this.getNotes()
    const now = getTodayDateString()
    const newNote: Note = {
      ...data,
      id: 'note_' + Math.random().toString(36).substring(2, 9),
      createdAt: now,
      updatedAt: now,
    }
    const updated = [newNote, ...notes]
    await this.saveNotes(updated)
    return newNote
  },

  async updateNote(id: string, updates: Partial<Note>): Promise<Note> {
    const notes = await this.getNotes()
    const index = notes.findIndex((n) => n.id === id)
    if (index === -1) throw new Error(`Note ${id} not found`)

    const updatedNote: Note = {
      ...notes[index],
      ...updates,
      updatedAt: getTodayDateString(),
    }
    notes[index] = updatedNote
    await this.saveNotes(notes)
    return updatedNote
  },

  async togglePin(id: string): Promise<Note> {
    const notes = await this.getNotes()
    const note = notes.find((n) => n.id === id)
    if (!note) throw new Error(`Note ${id} not found`)
    return this.updateNote(id, { pinned: !note.pinned })
  },

  async deleteNote(id: string): Promise<boolean> {
    const notes = await this.getNotes()
    const filtered = notes.filter((n) => n.id !== id)
    await this.saveNotes(filtered)
    return true
  },
}
