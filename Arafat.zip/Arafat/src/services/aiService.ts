import { Priority, TaskCategory } from '@/types'
import { getTodayDateString } from '@/utils/date'

export interface AIStudyPlanItem {
  id: string
  title: string
  durationMinutes: number
  category: TaskCategory
  priority: Priority
  description: string
  dueDate: string
}

export interface AIQuizQuestion {
  id: string
  question: string
  options: string[]
  correctIndex: number
  explanation: string
}

export interface AIStudyResponse {
  type: 'plan' | 'explanation' | 'breakdown' | 'quiz' | 'summary' | 'revision'
  title: string
  summary: string
  planItems?: AIStudyPlanItem[]
  quizQuestions?: AIQuizQuestion[]
  explanationMarkdown?: string
  actionableTips?: string[]
}

export const aiService = {
  async generateStudyPlan(params: {
    subject: string
    examDate: string
    availableHours: number
    topics: string
  }): Promise<AIStudyResponse> {
    // Simulate network delay for realism
    await new Promise((r) => setTimeout(r, 600))

    const { subject, availableHours, topics } = params
    const totalMinutes = availableHours * 60
    const topicList = topics ? topics.split(',').map((t) => t.trim()) : ['Core Concepts', 'Deep Practice', 'Formula Revision', 'Mock Exam']
    
    // Allocate proportional time blocks
    const planItems: AIStudyPlanItem[] = []
    const baseShare = Math.floor((totalMinutes * 0.75) / Math.max(topicList.length, 1))

    topicList.forEach((topic, i) => {
      planItems.push({
        id: 'ai-task-' + i,
        title: `Study ${subject}: ${topic}`,
        durationMinutes: baseShare,
        category: 'Study',
        priority: i === 0 ? 'urgent' : 'high',
        description: `Deep review session focusing on key definitions, edge cases, and examples for ${topic}.`,
        dueDate: getTodayDateString(),
      })
    })

    // Add practice problem set
    planItems.push({
      id: 'ai-task-practice',
      title: `${subject} Active Recall & Practice Problems`,
      durationMinutes: Math.floor(totalMinutes * 0.15),
      category: 'Study',
      priority: 'high',
      description: 'Solve 3-5 representative exam questions under timed conditions without looking at answers.',
      dueDate: getTodayDateString(),
    })

    // Add final consolidation
    planItems.push({
      id: 'ai-task-review',
      title: `${subject} Final High-Yield Formula & Error Log Review`,
      durationMinutes: Math.floor(totalMinutes * 0.1),
      category: 'Study',
      priority: 'medium',
      description: 'Review common trap questions, flashcards, and summary cheat-sheet.',
      dueDate: getTodayDateString(),
    })

    return {
      type: 'plan',
      title: `${availableHours}-Hour High-Yield Study Plan for ${subject}`,
      summary: `Targeted plan structured with spaced focus sprints, active recall problem sets, and final consolidation.`,
      planItems,
      actionableTips: [
        'Take a 5-minute breather between each module.',
        'Apply the Feynman technique: Explain each concept aloud before moving on.',
        'Hide notes during the practice problem phase to test true retrieval.',
      ],
    }
  },

  async explainConcept(concept: string): Promise<AIStudyResponse> {
    await new Promise((r) => setTimeout(r, 500))

    return {
      type: 'explanation',
      title: `Concept Breakdown: ${concept}`,
      summary: `Plain-English conceptual explanation, intuitive mental models, and real-world application.`,
      explanationMarkdown: `### 💡 What is ${concept}?
At its core, **${concept}** is a foundational mental model designed to handle complexity by isolating responsibilities.

### 🧠 The Intuitive Analogy:
Imagine an orchestra. If every musician played simultaneously without score sheets or conductor cues, you get cacophony. ${concept} acts like the sheet music score—giving each component a clear boundary and deterministic timing.

### 🔑 Key Principles:
1. **Separation of Concerns**: Keep unrelated variables isolated.
2. **Determinism**: The same inputs should always produce the same outputs.
3. **Invariance**: Key constraints must hold true before and after state transitions.

### ⚠️ Common Student Pitfalls:
- Confusing the definition with its specific implementation.
- Over-optimizing before verifying correctness.`,
      actionableTips: [
        'Test yourself: Can you describe this in 3 sentences to someone with no background?',
        'Look up 1 concrete code snippet or real-world example right now.',
      ],
    }
  },

  async breakDownTask(taskTitle: string, goalOutcome?: string): Promise<AIStudyResponse> {
    await new Promise((r) => setTimeout(r, 550))

    const planItems: AIStudyPlanItem[] = [
      {
        id: 'bd-1',
        title: `Phase 1: Clarify Requirements & Scope for "${taskTitle}"`,
        durationMinutes: 20,
        category: 'Study',
        priority: 'high',
        description: 'Read the entire assignment prompt, highlight grading rubrics, and draft an outline.',
        dueDate: getTodayDateString(),
      },
      {
        id: 'bd-2',
        title: `Phase 2: Core Implementation / First Rough Draft`,
        durationMinutes: 45,
        category: 'Study',
        priority: 'high',
        description: 'Complete 70% of the heavy lifting without worrying about perfection.',
        dueDate: getTodayDateString(),
      },
      {
        id: 'bd-3',
        title: `Phase 3: Verification, Edge-Cases & Test Verification`,
        durationMinutes: 30,
        category: 'Study',
        priority: 'medium',
        description: 'Run tests, verify edge conditions, and check against submission requirements.',
        dueDate: getTodayDateString(),
      },
      {
        id: 'bd-4',
        title: `Phase 4: Polish, Formatting & Submission`,
        durationMinutes: 15,
        category: 'Study',
        priority: 'low',
        description: 'Final proofread, generate PDF or commit git repository, and submit early.',
        dueDate: getTodayDateString(),
      },
    ]

    return {
      type: 'breakdown',
      title: `Deconstructed Roadmap: ${taskTitle}`,
      summary: `Broken down from an intimidating single task into 4 low-friction, bite-sized phases totaling ~110 minutes.`,
      planItems,
      actionableTips: [
        'Start with Phase 1 immediately—it only takes 20 minutes to eliminate inertia.',
        'Commit your work after finishing Phase 2.',
      ],
    }
  },

  async generateQuiz(subjectOrTopic: string): Promise<AIStudyResponse> {
    await new Promise((r) => setTimeout(r, 500))

    const questions: AIQuizQuestion[] = [
      {
        id: 'q-1',
        question: `In ${subjectOrTopic}, which of the following best defines active retrieval vs passive re-reading?`,
        options: [
          'Highlighting notes three times in different colors',
          'Testing oneself on questions without looking at the reference material',
          'Reading the summary chapter right before falling asleep',
          'Listening to an audio recording at 2x speed',
        ],
        correctIndex: 1,
        explanation:
          'Active retrieval forces the brain to reconstruct neural pathways, increasing synaptic retention up to 50% more than passive re-reading.',
      },
      {
        id: 'q-2',
        question: `When dealing with complex problem-solving in ${subjectOrTopic}, what is the recommended first step?`,
        options: [
          'Immediately write code or perform algebraic steps',
          'Look up the solution manual right away',
          'Break the problem down into smaller sub-problems and identify base constraints',
          'Skip to the final question to see if it is easier',
        ],
        correctIndex: 2,
        explanation:
          'Decomposition isolates variables and converts unbounded cognitive load into manageable, solvable steps.',
      },
      {
        id: 'q-3',
        question: `How does Spaced Repetition optimize memory consolidation?`,
        options: [
          'By reviewing material right at the point when you are about to forget it',
          'By cramming 10 hours in one night before the exam',
          'By repeating the exact same words 100 times in 1 hour',
          'By avoiding sleep to maximize study hours',
        ],
        correctIndex: 0,
        explanation:
          'The forgetting curve flattens each time retrieval effort is expended at optimal spacing intervals.',
      },
    ]

    return {
      type: 'quiz',
      title: `Active Recall Quiz: ${subjectOrTopic}`,
      summary: `3 diagnostic questions testing core comprehension, trade-offs, and mental models.`,
      quizQuestions: questions,
    }
  },

  async summarizeNotes(content: string): Promise<AIStudyResponse> {
    await new Promise((r) => setTimeout(r, 450))

    const lines = content.split('\n').filter((l) => l.trim().length > 0)
    const preview = lines.slice(0, 3).join(' ')

    return {
      type: 'summary',
      title: 'Executive Note Summary & Action Items',
      summary: `Distilled high-retention summary with core takeaways.`,
      explanationMarkdown: `### 📌 Executive Summary
${preview || 'Analyzed notes for high-yield examination retention.'}

### 🎯 Key Takeaways:
1. **Core Insight**: Consolidate primary definitions into your own vocabulary.
2. **Formula / Rule**: Ensure boundary conditions are always explicitly stated.
3. **Application**: Verify against at least two non-trivial test cases.

### 📝 Next Steps:
- Convert definitions into flashcards.
- Schedule a 15-minute review session in 48 hours.`,
      actionableTips: [
        'Review these bullet points 10 minutes before going to sleep.',
        'Turn each bullet point into a self-test question.',
      ],
    }
  },
}
