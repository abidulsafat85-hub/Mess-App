import {
  format,
  parseISO,
  isToday as isDateToday,
  isBefore,
  isAfter,
  startOfToday,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  startOfMonth,
  endOfMonth,
  subDays,
  addDays,
} from 'date-fns'

export function getTodayDateString(): string {
  return format(new Date(), 'yyyy-MM-dd')
}

export function formatFriendlyDate(dateString: string): string {
  try {
    const date = parseISO(dateString)
    if (isDateToday(date)) return 'Today'
    const tomorrow = addDays(startOfToday(), 1)
    if (format(tomorrow, 'yyyy-MM-dd') === dateString) return 'Tomorrow'
    const yesterday = subDays(startOfToday(), 1)
    if (format(yesterday, 'yyyy-MM-dd') === dateString) return 'Yesterday'
    return format(date, 'MMM d, yyyy')
  } catch {
    return dateString
  }
}

export function formatFullDate(date: Date = new Date()): string {
  return format(date, 'EEEE, MMMM d')
}

export function isTaskOverdue(dueDateString: string, completed: boolean): boolean {
  if (completed) return false
  try {
    const dueDate = parseISO(dueDateString)
    const today = startOfToday()
    return isBefore(dueDate, today)
  } catch {
    return false
  }
}

export function isTaskToday(dueDateString: string): boolean {
  return dueDateString === getTodayDateString()
}

export function isTaskUpcoming(dueDateString: string): boolean {
  try {
    const dueDate = parseISO(dueDateString)
    const today = startOfToday()
    return isAfter(dueDate, today)
  } catch {
    return false
  }
}

export function formatMinutes(minutes: number): string {
  if (!minutes || minutes <= 0) return '0m'
  const hours = Math.floor(minutes / 60)
  const remainingMins = minutes % 60
  if (hours > 0 && remainingMins > 0) {
    return `${hours}h ${remainingMins}m`
  }
  if (hours > 0) {
    return `${hours}h`
  }
  return `${remainingMins}m`
}

export function getGreeting(name?: string): string {
  const hour = new Date().getHours()
  const studentName = name || 'Student'
  if (hour < 12) return `Good morning, ${studentName} 👋`
  if (hour < 17) return `Good afternoon, ${studentName} 👋`
  return `Good evening, ${studentName} 👋`
}

export function getDailyMotivation(): string {
  const quotes = [
    'Small progress every day adds up to big results.',
    'Focus on being productive instead of busy.',
    'You don’t have to be extreme, just consistent.',
    'One focused hour is worth three distracted hours.',
    'The secret of getting ahead is getting started.',
    'Discipline is choosing between what you want now and what you want most.',
    'Your future self will thank you for today’s effort.',
  ]
  const dayIndex = new Date().getDate() % quotes.length
  return quotes[dayIndex]
}

export function getWeekDays(referenceDate: Date = new Date()): Date[] {
  const start = startOfWeek(referenceDate, { weekStartsOn: 1 }) // Monday
  const end = endOfWeek(referenceDate, { weekStartsOn: 1 })
  return eachDayOfInterval({ start, end })
}

export function getMonthDays(referenceDate: Date = new Date()): Date[] {
  const start = startOfMonth(referenceDate)
  const end = endOfMonth(referenceDate)
  return eachDayOfInterval({ start, end })
}
