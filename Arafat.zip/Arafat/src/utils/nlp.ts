import { addDays, format } from 'date-fns'
import { Priority, TaskCategory } from '@/types'
import { getTodayDateString } from './date'

export interface ParsedTaskInput {
  title: string
  dueDate: string
  dueTime?: string
  priority: Priority
  category: TaskCategory
  estimatedMinutes?: number
}

export function parseNaturalLanguageTask(input: string): ParsedTaskInput {
  let text = input.trim()
  let dueDate = getTodayDateString()
  let dueTime: string | undefined = undefined
  let priority: Priority = 'medium'
  let category: TaskCategory = 'Study'
  let estimatedMinutes: number | undefined = undefined

  // 1. Check priority markers
  if (/\b(urgent|p0|!urgent)\b/i.test(text)) {
    priority = 'urgent'
    text = text.replace(/\b(urgent|p0|!urgent)\b/gi, '').trim()
  } else if (/\b(high|p1|!high)\b/i.test(text)) {
    priority = 'high'
    text = text.replace(/\b(high|p1|!high)\b/gi, '').trim()
  } else if (/\b(low|p3|!low)\b/i.test(text)) {
    priority = 'low'
    text = text.replace(/\b(low|p3|!low)\b/gi, '').trim()
  }

  // 2. Check category tags (#coding, #study, #health, etc.)
  const categoryMatch = text.match(/#(study|coding|personal|health|finance|other)\b/i)
  if (categoryMatch) {
    const rawCat = categoryMatch[1].toLowerCase()
    const catMap: Record<string, TaskCategory> = {
      study: 'Study',
      coding: 'Coding',
      personal: 'Personal',
      health: 'Health',
      finance: 'Finance',
      other: 'Other',
    }
    if (catMap[rawCat]) {
      category = catMap[rawCat]
    }
    text = text.replace(categoryMatch[0], '').trim()
  }

  // 3. Duration markers e.g. "for 45m" or "30 min" or "1h"
  const durationMatch = text.match(/\b(?:for\s+)?(\d+)\s*(mins?|minutes?|hours?|hrs?|h|m)\b/i)
  if (durationMatch) {
    const amount = parseInt(durationMatch[1], 10)
    const unit = durationMatch[2].toLowerCase()
    if (unit.startsWith('h')) {
      estimatedMinutes = amount * 60
    } else {
      estimatedMinutes = amount
    }
    text = text.replace(durationMatch[0], '').trim()
  }

  // 4. Date markers e.g. "tomorrow", "today", "in 2 days"
  if (/\btomorrow\b/i.test(text)) {
    dueDate = format(addDays(new Date(), 1), 'yyyy-MM-dd')
    text = text.replace(/\btomorrow\b/gi, '').trim()
  } else if (/\btoday\b/i.test(text)) {
    dueDate = getTodayDateString()
    text = text.replace(/\btoday\b/gi, '').trim()
  } else {
    const inDaysMatch = text.match(/\bin\s+(\d+)\s+days?\b/i)
    if (inDaysMatch) {
      const days = parseInt(inDaysMatch[1], 10)
      dueDate = format(addDays(new Date(), days), 'yyyy-MM-dd')
      text = text.replace(inDaysMatch[0], '').trim()
    }
  }

  // 5. Time markers e.g. "at 7 PM", "at 14:00", "7:30pm", "10am"
  const timeMatch = text.match(/\bat\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\b/i) || text.match(/\b(\d{1,2})(?::(\d{2}))\s*(am|pm)?\b/i)
  if (timeMatch) {
    let hour = parseInt(timeMatch[1], 10)
    const minute = timeMatch[2] ? parseInt(timeMatch[2], 10) : 0
    const ampm = timeMatch[3]?.toLowerCase()

    if (ampm === 'pm' && hour < 12) hour += 12
    if (ampm === 'am' && hour === 12) hour = 0

    if (hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59) {
      dueTime = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`
      text = text.replace(timeMatch[0], '').trim()
    }
  }

  // Clean trailing prepositions like "at", "due", "on"
  text = text.replace(/\s+(at|due|on)$/i, '').replace(/\s{2,}/g, ' ').trim()

  return {
    title: text || input,
    dueDate,
    dueTime,
    priority,
    category,
    estimatedMinutes,
  }
}
