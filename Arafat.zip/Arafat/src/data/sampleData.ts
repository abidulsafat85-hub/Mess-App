import { format, subDays, addDays } from 'date-fns'
import {
  Task,
  Habit,
  Goal,
  StudySubject,
  StudySession,
  Note,
  DailyReview,
  UserSettings,
} from '@/types'

const today = new Date()
const todayStr = format(today, 'yyyy-MM-dd')
const dMinus1 = format(subDays(today, 1), 'yyyy-MM-dd')
const dMinus2 = format(subDays(today, 2), 'yyyy-MM-dd')
const dMinus3 = format(subDays(today, 3), 'yyyy-MM-dd')
const dMinus4 = format(subDays(today, 4), 'yyyy-MM-dd')
const dMinus5 = format(subDays(today, 5), 'yyyy-MM-dd')
const dMinus6 = format(subDays(today, 6), 'yyyy-MM-dd')
const dMinus7 = format(subDays(today, 7), 'yyyy-MM-dd')

const dPlus1 = format(addDays(today, 1), 'yyyy-MM-dd')
const dPlus2 = format(addDays(today, 2), 'yyyy-MM-dd')
const dPlus3 = format(addDays(today, 3), 'yyyy-MM-dd')
const dPlus5 = format(addDays(today, 5), 'yyyy-MM-dd')

export const sampleSettings: UserSettings = {
  name: 'Alex Rivera',
  email: 'alex.rivera@cs.university.edu',
  major: 'Computer Science & Software Engineering',
  onboarded: true,
  primaryGoals: [
    'Improve grades',
    'Learn programming',
    'Prepare for exams',
    'Build better habits',
  ],
  theme: 'system',
  accentColor: 'indigo',
  dailyStudyGoalMinutes: 180, // 3 hours
  focusDurationMinutes: 25,
  breakDurationMinutes: 5,
  longBreakDurationMinutes: 15,
  soundEnabled: true,
  notificationsEnabled: true,
  reminderTime: '20:00',
}

export const sampleSubjects: StudySubject[] = [
  {
    id: 'subj-1',
    name: 'Programming & Algorithms',
    color: '#3b82f6', // Blue
    description: 'Data structures, algorithm complexity, LeetCode practice',
    goalMinutesWeekly: 480, // 8h
    createdAt: dMinus7,
  },
  {
    id: 'subj-2',
    name: 'Discrete Mathematics',
    color: '#8b5cf6', // Violet
    description: 'Graph theory, combinatorics, predicate logic, proofs',
    goalMinutesWeekly: 360, // 6h
    createdAt: dMinus7,
  },
  {
    id: 'subj-3',
    name: 'Database Systems',
    color: '#10b981', // Emerald
    description: 'Relational algebra, SQL indexing, normalization (3NF/BCNF)',
    goalMinutesWeekly: 300, // 5h
    createdAt: dMinus7,
  },
  {
    id: 'subj-4',
    name: 'Software Engineering',
    color: '#f59e0b', // Amber
    description: 'System design, design patterns, Agile sprint architectures',
    goalMinutesWeekly: 240, // 4h
    createdAt: dMinus7,
  },
]

export const sampleTasks: Task[] = [
  {
    id: 'task-1',
    title: 'Complete MAT102 Discrete Math Problem Set 4',
    description: 'Solve questions 1-8 on Graph Theory and Euler paths. Review Theorem 4.2 proofs.',
    completed: false,
    priority: 'urgent',
    category: 'Study',
    tags: ['Math', 'Homework', 'Due-Tonight'],
    dueDate: todayStr,
    dueTime: '22:00',
    reminder: true,
    repeat: 'none',
    estimatedMinutes: 60,
    subtasks: [
      { id: 'sub-1-1', title: 'Questions 1-4 (Bipartite graphs)', completed: true },
      { id: 'sub-1-2', title: 'Questions 5-6 (Hamiltonian cycles)', completed: true },
      { id: 'sub-1-3', title: 'Questions 7-8 (Tree isomorphism)', completed: false },
      { id: 'sub-1-4', title: 'Export clean PDF writeup', completed: false },
    ],
    notes: 'Office hours recording is timestamped at 42:15 for hints on Question 7.',
    createdAt: dMinus1,
    updatedAt: todayStr,
  },
  {
    id: 'task-2',
    title: 'Practice JavaScript & React State Reducers',
    description: 'Implement complex state management patterns and custom hooks with TypeScript.',
    completed: false,
    priority: 'high',
    category: 'Coding',
    tags: ['React', 'TypeScript', 'Frontend'],
    dueDate: todayStr,
    dueTime: '16:00',
    reminder: true,
    repeat: 'daily',
    estimatedMinutes: 45,
    subtasks: [
      { id: 'sub-2-1', title: 'Implement useUndoRedo hook', completed: false },
      { id: 'sub-2-2', title: 'Add unit tests for edge cases', completed: false },
    ],
    notes: 'Focus on clean immutable state updates.',
    createdAt: dMinus1,
    updatedAt: todayStr,
  },
  {
    id: 'task-3',
    title: 'Read Database Systems Chapter 7: Normalization',
    description: 'Study 1NF, 2NF, 3NF and Boyce-Codd Normal Form with functional dependencies.',
    completed: true,
    priority: 'medium',
    category: 'Study',
    tags: ['Database', 'Reading'],
    dueDate: todayStr,
    dueTime: '11:00',
    reminder: false,
    repeat: 'none',
    estimatedMinutes: 40,
    subtasks: [
      { id: 'sub-3-1', title: 'Read pages 210-245', completed: true },
      { id: 'sub-3-2', title: 'Summarize key decomposition rules in notes', completed: true },
    ],
    notes: 'Captured key formulas in the Database Notes section.',
    createdAt: dMinus2,
    updatedAt: todayStr,
    completedAt: todayStr,
  },
  {
    id: 'task-4',
    title: 'Review Software Architecture & Clean Architecture Notes',
    description: 'Prepare flashcards for tomorrow quiz on Dependency Inversion and Layered Design.',
    completed: false,
    priority: 'medium',
    category: 'Study',
    tags: ['SE', 'Quiz-Prep'],
    dueDate: todayStr,
    dueTime: '19:30',
    reminder: false,
    repeat: 'none',
    estimatedMinutes: 30,
    subtasks: [],
    createdAt: dMinus1,
    updatedAt: todayStr,
  },
  {
    id: 'task-5',
    title: 'Gym Workout & 20 min cardio',
    description: 'Upper body strength session + 20 min cooldown run.',
    completed: true,
    priority: 'low',
    category: 'Health',
    tags: ['Fitness', 'Routine'],
    dueDate: todayStr,
    dueTime: '08:00',
    reminder: false,
    repeat: 'daily',
    estimatedMinutes: 50,
    subtasks: [],
    createdAt: dMinus1,
    updatedAt: todayStr,
    completedAt: todayStr,
  },
  {
    id: 'task-6',
    title: 'Submit Operating Systems Lab 3 Pre-Report',
    description: 'Multi-threaded Producer-Consumer problem semaphore synchronization verification.',
    completed: false,
    priority: 'high',
    category: 'Study',
    tags: ['OS', 'Lab'],
    dueDate: dPlus1,
    dueTime: '23:59',
    reminder: true,
    repeat: 'none',
    estimatedMinutes: 90,
    subtasks: [
      { id: 'sub-6-1', title: 'Write deadlock avoidance proof', completed: false },
      { id: 'sub-6-2', title: 'Benchmark throughput with 10 threads', completed: false },
    ],
    createdAt: dMinus1,
    updatedAt: dMinus1,
  },
  {
    id: 'task-7',
    title: 'Solve 2 LeetCode Medium Problems (Trees & DFS)',
    description: 'Course Schedule and Binary Tree Maximum Path Sum.',
    completed: false,
    priority: 'medium',
    category: 'Coding',
    tags: ['Algorithms', 'Interview'],
    dueDate: dPlus2,
    dueTime: '15:00',
    reminder: false,
    repeat: 'none',
    estimatedMinutes: 60,
    subtasks: [],
    createdAt: dMinus1,
    updatedAt: dMinus1,
  },
  {
    id: 'task-8',
    title: 'Review Cloud Computing Distributed Consensus (Raft / Paxos)',
    description: 'Prepare discussion notes for Thursday seminar.',
    completed: false,
    priority: 'low',
    category: 'Study',
    tags: ['Systems', 'Reading'],
    dueDate: dPlus3,
    dueTime: '14:00',
    reminder: false,
    repeat: 'none',
    estimatedMinutes: 45,
    subtasks: [],
    createdAt: dMinus2,
    updatedAt: dMinus2,
  },
]

export const sampleHabits: Habit[] = [
  {
    id: 'habit-1',
    name: 'Study 2+ hours daily',
    category: 'Study',
    frequency: 'daily',
    target: 1,
    streak: 12,
    longestStreak: 18,
    logs: {
      [dMinus7]: true,
      [dMinus6]: true,
      [dMinus5]: true,
      [dMinus4]: true,
      [dMinus3]: true,
      [dMinus2]: true,
      [dMinus1]: true,
      [todayStr]: true,
    },
    reminder: '14:00',
    createdAt: dMinus7,
  },
  {
    id: 'habit-2',
    name: 'Coding practice (LeetCode / Project)',
    category: 'Coding',
    frequency: 'daily',
    target: 1,
    streak: 7,
    longestStreak: 14,
    logs: {
      [dMinus6]: true,
      [dMinus5]: true,
      [dMinus4]: true,
      [dMinus3]: true,
      [dMinus2]: true,
      [dMinus1]: true,
      [todayStr]: true,
    },
    reminder: '16:30',
    createdAt: dMinus7,
  },
  {
    id: 'habit-3',
    name: 'Read 20 pages of non-fiction book',
    category: 'Personal',
    frequency: 'daily',
    target: 1,
    streak: 5,
    longestStreak: 9,
    logs: {
      [dMinus5]: true,
      [dMinus4]: true,
      [dMinus3]: true,
      [dMinus2]: true,
      [dMinus1]: true,
      // not yet today
    },
    reminder: '21:00',
    createdAt: dMinus7,
  },
  {
    id: 'habit-4',
    name: 'Morning workout or 30m walk',
    category: 'Health',
    frequency: 'daily',
    target: 1,
    streak: 4,
    longestStreak: 10,
    logs: {
      [dMinus4]: true,
      [dMinus3]: true,
      [dMinus2]: true,
      [dMinus1]: true,
      [todayStr]: true,
    },
    reminder: '07:30',
    createdAt: dMinus7,
  },
]

export const sampleGoals: Goal[] = [
  {
    id: 'goal-1',
    title: 'Master Modern React & Full-Stack Architecture',
    description: 'Build 3 full-stack portfolio applications with TypeScript, Next.js/Vite, Zustand, and Tailwind.',
    deadline: dPlus5,
    progress: 75,
    category: 'Coding',
    milestones: [
      { id: 'm-1-1', title: 'Complete Advanced TypeScript Generics course', completed: true },
      { id: 'm-1-2', title: 'Build Full-stack Student Productivity App', completed: true },
      { id: 'm-1-3', title: 'Master Server State & React Query caching', completed: true },
      { id: 'm-1-4', title: 'Deploy production app on Vercel with automated CI/CD', completed: false },
    ],
    createdAt: dMinus7,
  },
  {
    id: 'goal-2',
    title: 'Ace Midterm Exams (Target GPA: 3.9+)',
    description: 'Prepare thoroughly for Discrete Mathematics, Database Systems, and Software Engineering midterms.',
    deadline: format(addDays(today, 18), 'yyyy-MM-dd'),
    progress: 50,
    category: 'Study',
    milestones: [
      { id: 'm-2-1', title: 'Finish all Discrete Math past exam papers', completed: true },
      { id: 'm-2-2', title: 'Create comprehensive Database SQL & 3NF cheat sheet', completed: true },
      { id: 'm-2-3', title: 'Complete Software Architecture group review session', completed: false },
      { id: 'm-2-4', title: 'Conduct timed mock exam under test conditions', completed: false },
    ],
    createdAt: dMinus7,
  },
  {
    id: 'goal-3',
    title: 'Read 5 Tech & Productivity Books',
    description: 'Deepen understanding of software craft and high-performance habits.',
    deadline: format(addDays(today, 45), 'yyyy-MM-dd'),
    progress: 40,
    category: 'Personal',
    milestones: [
      { id: 'm-3-1', title: 'Atomic Habits by James Clear', completed: true },
      { id: 'm-3-2', title: 'Designing Data-Intensive Applications (Part 1)', completed: true },
      { id: 'm-3-3', title: 'Clean Architecture by Robert C. Martin', completed: false },
      { id: 'm-3-4', title: 'Deep Work by Cal Newport', completed: false },
      { id: 'm-3-5', title: 'A Philosophy of Software Design', completed: false },
    ],
    createdAt: dMinus7,
  },
]

export const sampleStudySessions: StudySession[] = [
  // Today's sessions
  {
    id: 'sess-today-1',
    subjectId: 'subj-1',
    topic: 'React Custom Hooks & Reducer Architecture',
    durationMinutes: 75, // 1h 15m
    date: todayStr,
    notes: 'Built resilient undo/redo state stack. Understood action dispatchers.',
    createdAt: todayStr,
  },
  {
    id: 'sess-today-2',
    subjectId: 'subj-3',
    topic: 'Database BCNF & 3NF Normalization Rules',
    durationMinutes: 45,
    date: todayStr,
    notes: 'Covered lossy vs lossless join decomposition and dependency preservation.',
    createdAt: todayStr,
  },
  {
    id: 'sess-today-3',
    subjectId: 'subj-2',
    topic: 'Graph Theory Euler Paths Proofs',
    durationMinutes: 35,
    date: todayStr,
    notes: 'Handshaking lemma and degrees of vertices theorem.',
    createdAt: todayStr,
  },
  // Yesterday's sessions
  {
    id: 'sess-yest-1',
    subjectId: 'subj-1',
    topic: 'Binary Search Trees & Traversal Algorithms',
    durationMinutes: 90,
    date: dMinus1,
    notes: 'In-order, pre-order, and post-order recursive and iterative variants.',
    createdAt: dMinus1,
  },
  {
    id: 'sess-yest-2',
    subjectId: 'subj-4',
    topic: 'SOLID Principles in TypeScript',
    durationMinutes: 60,
    date: dMinus1,
    notes: 'Single responsibility and Liskov substitution real-world scenarios.',
    createdAt: dMinus1,
  },
  // Previous days
  {
    id: 'sess-prev-1',
    subjectId: 'subj-2',
    topic: 'Recurrence Relations & Master Theorem',
    durationMinutes: 80,
    date: dMinus2,
    notes: 'Solved 5 divide-and-conquer runtime proofs.',
    createdAt: dMinus2,
  },
  {
    id: 'sess-prev-2',
    subjectId: 'subj-3',
    topic: 'SQL Query Optimization & B-Tree Indexes',
    durationMinutes: 70,
    date: dMinus3,
    notes: 'Analyzed EXPLAIN output and composite index column order.',
    createdAt: dMinus3,
  },
  {
    id: 'sess-prev-3',
    subjectId: 'subj-1',
    topic: 'Dynamic Programming (Knapsack & Coin Change)',
    durationMinutes: 110,
    date: dMinus4,
    notes: 'Memoization table vs bottom-up tabulation.',
    createdAt: dMinus4,
  },
  {
    id: 'sess-prev-4',
    subjectId: 'subj-4',
    topic: 'Microservices vs Modular Monolith Patterns',
    durationMinutes: 60,
    date: dMinus5,
    notes: 'Bounded contexts and event-driven communication.',
    createdAt: dMinus5,
  },
  {
    id: 'sess-prev-5',
    subjectId: 'subj-2',
    topic: 'Combinatorics & Pigeonhole Principle',
    durationMinutes: 90,
    date: dMinus6,
    notes: 'Permutations with repetition and inclusion-exclusion principle.',
    createdAt: dMinus6,
  },
]

export const sampleNotes: Note[] = [
  {
    id: 'note-1',
    title: 'Database Normalization Quick Cheat Sheet',
    content: `# Normalization Rules Summary
- **1NF**: Every column contains atomic (indivisible) values. No repeating groups or arrays.
- **2NF**: In 1NF + No partial dependencies (all non-key attributes fully depend on the entire candidate key).
- **3NF**: In 2NF + No transitive dependencies (no non-key attribute depends on another non-key attribute).
- **BCNF**: For every functional dependency X -> Y, X must be a superkey.

### Verification Checklist:
Always check if candidate keys can be decomposed without losing functional dependencies!`,
    category: 'Study',
    tags: ['Database', 'Exam', 'SQL'],
    pinned: true,
    checklist: [
      { id: 'chk-1', text: 'Identify all functional dependencies', done: true },
      { id: 'chk-2', text: 'Find minimal candidate keys', done: true },
      { id: 'chk-3', text: 'Verify 3NF conditions', done: true },
      { id: 'chk-4', text: 'Check for BCNF violations', done: false },
    ],
    createdAt: dMinus3,
    updatedAt: todayStr,
  },
  {
    id: 'note-2',
    title: 'Active Study & Spaced Repetition Protocol',
    content: `### High-Retention Framework:
1. **Feynman Technique**: Explain the concept out loud in plain English as if teaching a 12-year old.
2. **Blurting Method**: Read a sub-chapter, close book, write everything remembered from scratch on a blank page.
3. **Spaced Intervals**: Review on Day 1, Day 3, Day 7, Day 14, and Day 30.
4. **Active Recall**: Test knowledge with questions before reading answers.`,
    category: 'Important',
    tags: ['Study-Method', 'Productivity'],
    pinned: true,
    createdAt: dMinus5,
    updatedAt: dMinus2,
  },
  {
    id: 'note-3',
    title: 'Cap Theorem & Distributed Tradeoffs',
    content: `In any asynchronous distributed network:
- **Consistency**: Every read receives the most recent write or an error.
- **Availability**: Every request receives a non-error response, without guarantee that it contains the most recent write.
- **Partition Tolerance**: The system continues to operate despite an arbitrary number of messages being dropped or delayed.

Tradeoff: In the presence of a network partition (P), you must choose either C or A.`,
    category: 'Study',
    tags: ['Systems', 'Architecture'],
    pinned: false,
    createdAt: dMinus4,
    updatedAt: dMinus4,
  },
  {
    id: 'note-4',
    title: 'Startup Idea: AI Peer Code Reviewer for CS Students',
    content: `Problem: TAs take 2 weeks to grade homework code and give minimal stylistic feedback.
Solution: An automated AI linter tailored to university grading rubrics that flags memory leaks, Big-O antipatterns, and provides guided hints instead of giving away answers.`,
    category: 'Ideas',
    tags: ['Startup', 'AI', 'Coding'],
    pinned: false,
    createdAt: dMinus6,
    updatedAt: dMinus6,
  },
]

export const sampleReviews: DailyReview[] = [
  {
    id: 'rev-1',
    date: dMinus1,
    productivityRating: 5,
    tasksCompleted: 6,
    studyMinutes: 150,
    habitsCompleted: 4,
    note: 'Crushed the Trees algorithm session and stayed focused throughout without phone distractions.',
    wins: 'Finished all problem sets before 8 PM!',
    createdAt: dMinus1,
  },
  {
    id: 'rev-2',
    date: dMinus2,
    productivityRating: 4,
    tasksCompleted: 5,
    studyMinutes: 80,
    habitsCompleted: 3,
    note: 'Good energy in the morning, slight dip in the afternoon. Pomodoro helped recover momentum.',
    wins: 'Solved 2 tough recurrence proofs.',
    createdAt: dMinus2,
  },
]
