import { useState } from 'react'
import { Plus, Target, CheckCircle2 } from 'lucide-react'
import { useGoalStore } from '@/store/useGoalStore'
import { GoalCard } from '@/components/goals/GoalCard'
import { GoalModal } from '@/components/goals/GoalModal'
import { Button } from '@/components/ui/Button'
import { EmptyState } from '@/components/ui/EmptyState'
import { Goal } from '@/types'

export function GoalsPage() {
  const { goals } = useGoalStore()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null)

  const handleEdit = (goal: Goal) => {
    setEditingGoal(goal)
    setIsModalOpen(true)
  }

  const completedGoals = goals.filter((g) => g.progress === 100).length

  return (
    <div className="mx-auto max-w-4xl space-y-6 pb-24">
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
            Semester & Long-Term Goals
          </h1>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Deconstruct ambitious aspirations into concrete milestones.
          </p>
        </div>

        <Button
          size="md"
          onClick={() => {
            setEditingGoal(null)
            setIsModalOpen(true)
          }}
        >
          <Plus className="h-4 w-4 mr-1" />
          Set Goal
        </Button>
      </div>

      {/* Goal Summary Pills */}
      <div className="flex gap-4">
        <div className="rounded-xl border border-slate-200 bg-white px-4 py-2.5 dark:border-slate-800 dark:bg-slate-900">
          <span className="text-[11px] text-slate-400 font-medium">ACTIVE GOALS</span>
          <p className="text-lg font-bold text-slate-900 dark:text-white">{goals.length}</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white px-4 py-2.5 dark:border-slate-800 dark:bg-slate-900">
          <span className="text-[11px] text-slate-400 font-medium">ACHIEVED (100%)</span>
          <p className="text-lg font-bold text-emerald-600 dark:text-emerald-400">{completedGoals}</p>
        </div>
      </div>

      {/* Goals List */}
      <div className="space-y-4">
        {goals.length === 0 ? (
          <EmptyState
            icon={<Target className="h-6 w-6 text-indigo-500" />}
            title="Set a goal and start making progress"
            description="What do you want to achieve this semester? Add your target and break it into checkpoints."
            actionLabel="+ Set Goal"
            onAction={() => {
              setEditingGoal(null)
              setIsModalOpen(true)
            }}
          />
        ) : (
          goals.map((goal) => (
            <GoalCard key={goal.id} goal={goal} onEdit={handleEdit} />
          ))
        )}
      </div>

      <GoalModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false)
          setEditingGoal(null)
        }}
        editingGoal={editingGoal}
      />
    </div>
  )
}
