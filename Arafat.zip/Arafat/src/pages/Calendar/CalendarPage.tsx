import { useState } from 'react'
import {
  format,
  addMonths,
  subMonths,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  isSameMonth,
  isToday as isDateToday,
  addWeeks,
  subWeeks,
} from 'date-fns'
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  CheckSquare,
  BookOpen,
  Flame,
  Target,
} from 'lucide-react'
import { useTaskStore } from '@/store/useTaskStore'
import { useStudyStore } from '@/store/useStudyStore'
import { useHabitStore } from '@/store/useHabitStore'
import { useGoalStore } from '@/store/useGoalStore'
import { useUIStore } from '@/store/useUIStore'
import { Button } from '@/components/ui/Button'
import { TaskCard } from '@/components/tasks/TaskCard'
import { getMonthDays, formatMinutes } from '@/utils/date'

type CalendarViewMode = 'month' | 'week' | 'day'

export function CalendarPage() {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState(new Date())
  const [viewMode, setViewMode] = useState<CalendarViewMode>('month')

  const { tasks } = useTaskStore()
  const { sessions } = useStudyStore()
  const { habits } = useHabitStore()
  const { goals } = useGoalStore()
  const { openTaskModal } = useUIStore()

  const selectedDateStr = format(selectedDate, 'yyyy-MM-dd')

  // Navigation handlers
  const handlePrev = () => {
    if (viewMode === 'month') setCurrentDate(subMonths(currentDate, 1))
    else if (viewMode === 'week') setCurrentDate(subWeeks(currentDate, 1))
    else setCurrentDate(subMonths(currentDate, 1))
  }

  const handleNext = () => {
    if (viewMode === 'month') setCurrentDate(addMonths(currentDate, 1))
    else if (viewMode === 'week') setCurrentDate(addWeeks(currentDate, 1))
    else setCurrentDate(addMonths(currentDate, 1))
  }

  // Items for selected date
  const dateTasks = tasks.filter((t) => t.dueDate === selectedDateStr)
  const dateSessions = sessions.filter((s) => s.date === selectedDateStr)
  const dateHabitsDone = habits.filter((h) => !!h.logs[selectedDateStr])
  const dateGoals = goals.filter((g) => g.deadline === selectedDateStr)

  // Calendar matrix days
  const monthDays = getMonthDays(currentDate)
  const startDay = startOfWeek(monthDays[0], { weekStartsOn: 1 })
  const endDay = endOfWeek(monthDays[monthDays.length - 1], { weekStartsOn: 1 })
  const calendarGrid = eachDayOfInterval({ start: startDay, end: endDay })

  // Week view days
  const weekGrid = eachDayOfInterval({
    start: startOfWeek(currentDate, { weekStartsOn: 1 }),
    end: endOfWeek(currentDate, { weekStartsOn: 1 }),
  })

  return (
    <div className="mx-auto max-w-5xl space-y-6 pb-24">
      {/* Calendar Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
            Study Schedule & Calendar
          </h1>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            View assignment deadlines, sessions, and habit consistency.
          </p>
        </div>

        {/* View switcher & New task */}
        <div className="flex items-center gap-2">
          <div className="flex rounded-xl border border-slate-200 bg-white p-0.5 dark:border-slate-800 dark:bg-slate-900">
            <button
              onClick={() => setViewMode('month')}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
                viewMode === 'month'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
              }`}
            >
              Month
            </button>
            <button
              onClick={() => setViewMode('week')}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
                viewMode === 'week'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
              }`}
            >
              Week
            </button>
          </div>

          <Button
            size="sm"
            onClick={() => {
              openTaskModal(null)
            }}
          >
            <Plus className="h-4 w-4 mr-1" />
            Add on Date
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Main Calendar Grid (2 cols on desktop) */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs dark:border-slate-800 dark:bg-slate-900 lg:col-span-2">
          {/* Month / Period title & Next/Prev */}
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {format(currentDate, 'MMMM yyyy')}
            </h2>
            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  setCurrentDate(new Date())
                  setSelectedDate(new Date())
                }}
                className="rounded-lg px-2.5 py-1 text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                Today
              </button>
              <button
                onClick={handlePrev}
                className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <button
                onClick={handleNext}
                className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Day of Week Headers */}
          <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-semibold text-slate-400 pb-2">
            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span>Fri</span>
            <span>Sat</span>
            <span>Sun</span>
          </div>

          {/* Calendar Grid Cells */}
          <div className="grid grid-cols-7 gap-1">
            {(viewMode === 'month' ? calendarGrid : weekGrid).map((day) => {
              const dayStr = format(day, 'yyyy-MM-dd')
              const isSelected = dayStr === selectedDateStr
              const isCurrentDay = isDateToday(day)
              const isSameMonthDay = isSameMonth(day, currentDate)

              // Check items on this day
              const dayTasks = tasks.filter((t) => t.dueDate === dayStr)
              const hasTask = dayTasks.length > 0
              const hasStudy = sessions.some((s) => s.date === dayStr)
              const hasHabit = habits.some((h) => !!h.logs[dayStr])
              const hasGoal = goals.some((g) => g.deadline === dayStr)

              return (
                <div
                  key={dayStr}
                  onClick={() => setSelectedDate(day)}
                  className={`flex min-h-[58px] cursor-pointer flex-col items-center justify-between rounded-xl border p-1.5 transition-all ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/50 dark:border-indigo-500 dark:bg-indigo-950/40 ring-1 ring-indigo-500'
                      : isCurrentDay
                      ? 'border-slate-300 bg-slate-50/60 dark:border-slate-700 dark:bg-slate-800/40'
                      : 'border-slate-100 bg-white hover:border-slate-200 dark:border-slate-800/60 dark:bg-slate-900 dark:hover:border-slate-700'
                  }`}
                >
                  <span
                    className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-semibold ${
                      isCurrentDay
                        ? 'bg-indigo-600 text-white'
                        : !isSameMonthDay
                        ? 'text-slate-300 dark:text-slate-600'
                        : 'text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {format(day, 'd')}
                  </span>

                  {/* Indicator Dots */}
                  <div className="flex gap-1 pt-1">
                    {hasTask && (
                      <span className="h-1.5 w-1.5 rounded-full bg-indigo-500" title="Tasks" />
                    )}
                    {hasStudy && (
                      <span className="h-1.5 w-1.5 rounded-full bg-blue-500" title="Study Sessions" />
                    )}
                    {hasHabit && (
                      <span className="h-1.5 w-1.5 rounded-full bg-amber-500" title="Habits Done" />
                    )}
                    {hasGoal && (
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" title="Goal Deadline" />
                    )}
                  </div>
                </div>
              )
            })}
          </div>

          {/* Indicator Legend */}
          <div className="mt-4 flex flex-wrap items-center justify-center gap-4 border-t border-slate-100 pt-3 text-[11px] text-slate-500 dark:border-slate-800">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-indigo-500" /> Tasks
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-blue-500" /> Study
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-amber-500" /> Habits
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-500" /> Goal Deadlines
            </span>
          </div>
        </div>

        {/* Selected Date Details Panel (1 col) */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
          <div className="mb-4 flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {format(selectedDate, 'EEEE, MMM d')}
              </h3>
              <p className="text-[11px] text-slate-400">
                {isDateToday(selectedDate) ? 'Today' : 'Selected Schedule'}
              </p>
            </div>
            <Button
              size="sm"
              variant="subtle"
              onClick={() => openTaskModal(null)}
            >
              + Task
            </Button>
          </div>

          <div className="space-y-4">
            {/* Tasks Section */}
            <div>
              <h4 className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
                <CheckSquare className="h-3.5 w-3.5 text-indigo-500" />
                Tasks ({dateTasks.length})
              </h4>
              <div className="mt-2 space-y-2">
                {dateTasks.length === 0 ? (
                  <p className="text-xs italic text-slate-400">No tasks due</p>
                ) : (
                  dateTasks.map((t) => <TaskCard key={t.id} task={t} />)
                )}
              </div>
            </div>

            {/* Study Sessions Section */}
            <div>
              <h4 className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
                <BookOpen className="h-3.5 w-3.5 text-blue-500" />
                Study Sessions ({dateSessions.length})
              </h4>
              <div className="mt-2 space-y-1.5">
                {dateSessions.length === 0 ? (
                  <p className="text-xs italic text-slate-400">No study sessions logged</p>
                ) : (
                  dateSessions.map((s) => (
                    <div
                      key={s.id}
                      className="rounded-xl border border-slate-100 bg-slate-50 p-2.5 text-xs dark:border-slate-800 dark:bg-slate-800/50"
                    >
                      <div className="font-semibold text-slate-800 dark:text-slate-200">
                        {s.topic}
                      </div>
                      <div className="mt-0.5 text-[11px] text-slate-500">
                        Duration: {formatMinutes(s.durationMinutes)}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Habits Logged Section */}
            <div>
              <h4 className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
                <Flame className="h-3.5 w-3.5 text-amber-500" />
                Habits Completed ({dateHabitsDone.length})
              </h4>
              <div className="mt-2 space-y-1">
                {dateHabitsDone.length === 0 ? (
                  <p className="text-xs italic text-slate-400">No habits logged</p>
                ) : (
                  dateHabitsDone.map((h) => (
                    <div
                      key={h.id}
                      className="flex items-center gap-2 rounded-lg py-1 px-2 text-xs font-medium text-emerald-700 bg-emerald-50 dark:bg-emerald-950/30 dark:text-emerald-300"
                    >
                      ✓ {h.name}
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Goals Deadline Section */}
            {dateGoals.length > 0 && (
              <div>
                <h4 className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
                  <Target className="h-3.5 w-3.5 text-emerald-500" />
                  Goal Deadlines
                </h4>
                <div className="mt-2 space-y-1">
                  {dateGoals.map((g) => (
                    <div
                      key={g.id}
                      className="rounded-lg bg-indigo-50 p-2 text-xs font-semibold text-indigo-800 dark:bg-indigo-950/40 dark:text-indigo-300"
                    >
                      🎯 {g.title}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
