import React, { useState } from 'react'
import {
  User,
  Settings,
  Download,
  Upload,
  Trash2,
  Moon,
  Sun,
  Palette,
  Clock,
  Shield,
  Key,
  Flame,
  CheckCircle2,
  BookOpen,
  RotateCcw,
  Sparkles,
} from 'lucide-react'
import { useSettingsStore } from '@/store/useSettingsStore'
import { useTaskStore } from '@/store/useTaskStore'
import { useStudyStore } from '@/store/useStudyStore'
import { useHabitStore } from '@/store/useHabitStore'
import { useUIStore } from '@/store/useUIStore'
import { storageService } from '@/services/storage'
import { sampleTasks, sampleHabits, sampleGoals, sampleSubjects, sampleStudySessions, sampleNotes, sampleSettings } from '@/data/sampleData'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { ConfirmDialog } from '@/components/ui/ConfirmDialog'
import { formatMinutes } from '@/utils/date'
import { AccentColor, ThemeMode } from '@/types'

const ACCENT_COLORS: { id: AccentColor; name: string; bg: string }[] = [
  { id: 'indigo', name: 'Indigo (Default)', bg: 'bg-indigo-600' },
  { id: 'blue', name: 'Blue', bg: 'bg-blue-600' },
  { id: 'emerald', name: 'Emerald', bg: 'bg-emerald-600' },
  { id: 'violet', name: 'Violet', bg: 'bg-violet-600' },
  { id: 'rose', name: 'Rose', bg: 'bg-rose-600' },
  { id: 'amber', name: 'Amber', bg: 'bg-amber-600' },
]

export function ProfilePage() {
  const { settings, updateSettings, setTheme, setAccentColor } = useSettingsStore()
  const { tasks, loadTasks } = useTaskStore()
  const { sessions, loadStudyData } = useStudyStore()
  const { habits, loadHabits } = useHabitStore()
  const { showToast } = useUIStore()

  const [name, setName] = useState(settings.name)
  const [email, setEmail] = useState(settings.email || '')
  const [major, setMajor] = useState(settings.major || '')
  const [dailyGoalHours, setDailyGoalHours] = useState(settings.dailyStudyGoalMinutes / 60)
  const [focusMins, setFocusMins] = useState(settings.focusDurationMinutes)
  const [aiKey, setAiKey] = useState(settings.aiApiKey || '')

  const [isClearModalOpen, setIsClearModalOpen] = useState(false)
  const [isResetModalOpen, setIsResetModalOpen] = useState(false)

  // Lifetime Stats
  const completedTasks = tasks.filter((t) => t.completed).length
  const totalStudyMinutes = sessions.reduce((acc, s) => acc + s.durationMinutes, 0)
  const highestStreak = habits.reduce((max, h) => Math.max(max, h.streak), 12)
  const longestStreak = habits.reduce((max, h) => Math.max(max, h.longestStreak), 18)

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault()
    updateSettings({
      name: name.trim(),
      email: email.trim() || undefined,
      major: major.trim() || undefined,
      dailyStudyGoalMinutes: Math.round(Number(dailyGoalHours) * 60),
      focusDurationMinutes: Number(focusMins),
      aiApiKey: aiKey.trim() || undefined,
    })
    showToast('Profile and preferences updated ✓', 'success')
  }

  // Export Data JSON
  const handleExportData = () => {
    const json = storageService.exportAllData()
    const blob = new Blob([json], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `aura-backup-${new Date().toISOString().slice(0, 10)}.json`
    a.click()
    URL.revokeObjectURL(url)
    showToast('Exported backup successfully 💾', 'success')
  }

  // Import Data JSON
  const handleImportData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = async (event) => {
      const content = event.target?.result as string
      const success = storageService.importAllData(content)
      if (success) {
        await Promise.all([loadTasks(), loadStudyData(), loadHabits()])
        showToast('Backup restored successfully 🎉', 'success')
      } else {
        showToast('Invalid backup file format.', 'error')
      }
    }
    reader.readAsText(file)
  }

  // Clear data
  const handleConfirmClear = async () => {
    storageService.clearAllData()
    setIsClearModalOpen(false)
    window.location.reload()
  }

  // Reset sample data
  const handleConfirmReset = async () => {
    const keys = storageService.getKeys()
    storageService.setItem(keys.SETTINGS, sampleSettings)
    storageService.setItem(keys.TASKS, sampleTasks)
    storageService.setItem(keys.HABITS, sampleHabits)
    storageService.setItem(keys.GOALS, sampleGoals)
    storageService.setItem(keys.SUBJECTS, sampleSubjects)
    storageService.setItem(keys.SESSIONS, sampleStudySessions)
    storageService.setItem(keys.NOTES, sampleNotes)
    setIsResetModalOpen(false)
    window.location.reload()
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6 pb-24">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
          Student Profile & Settings
        </h1>
        <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
          Personalize your preferences, theme styling, and manage local data.
        </p>
      </div>

      {/* Profile Card & Lifetime Stats */}
      <div className="rounded-3xl border border-slate-200/90 bg-white p-6 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-indigo-600 text-2xl font-bold text-white shadow-lg shadow-indigo-600/25">
              {settings.name.charAt(0)}
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                {settings.name}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {settings.major || 'Undergraduate Student'}
              </p>
              <p className="text-[11px] text-slate-400">
                {settings.email || 'Personal Local Profile'}
              </p>
            </div>
          </div>
        </div>

        {/* Lifetime Stats */}
        <div className="mt-6 grid grid-cols-2 gap-3 border-t border-slate-100 pt-5 dark:border-slate-800 sm:grid-cols-4">
          <div className="rounded-xl bg-slate-50 p-3 text-center dark:bg-slate-800/50">
            <CheckCircle2 className="mx-auto h-4 w-4 text-emerald-500 mb-1" />
            <span className="text-base font-bold text-slate-900 dark:text-white">
              {completedTasks}
            </span>
            <p className="text-[10px] text-slate-400">Tasks Completed</p>
          </div>

          <div className="rounded-xl bg-slate-50 p-3 text-center dark:bg-slate-800/50">
            <BookOpen className="mx-auto h-4 w-4 text-blue-500 mb-1" />
            <span className="text-base font-bold text-slate-900 dark:text-white">
              {formatMinutes(totalStudyMinutes)}
            </span>
            <p className="text-[10px] text-slate-400">Total Study Time</p>
          </div>

          <div className="rounded-xl bg-slate-50 p-3 text-center dark:bg-slate-800/50">
            <Flame className="mx-auto h-4 w-4 text-amber-500 mb-1" />
            <span className="text-base font-bold text-slate-900 dark:text-white">
              {highestStreak} days
            </span>
            <p className="text-[10px] text-slate-400">Current Streak</p>
          </div>

          <div className="rounded-xl bg-slate-50 p-3 text-center dark:bg-slate-800/50">
            <Sparkles className="mx-auto h-4 w-4 text-purple-500 mb-1" />
            <span className="text-base font-bold text-slate-900 dark:text-white">
              {longestStreak} days
            </span>
            <p className="text-[10px] text-slate-400">Longest Streak</p>
          </div>
        </div>
      </div>

      {/* Account Details Form */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
        <h3 className="mb-4 text-sm font-bold text-slate-900 dark:text-white">
          Account & Academic Information
        </h3>
        <form onSubmit={handleSaveProfile} className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Input
              label="Student Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
            <Input
              type="email"
              label="Email Address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. alex@university.edu"
            />
          </div>

          <Input
            label="Major / Field of Study"
            value={major}
            onChange={(e) => setMajor(e.target.value)}
            placeholder="e.g. Computer Science, Biomedical Engineering"
          />

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Input
              type="number"
              label="Daily Study Goal (Hours)"
              value={dailyGoalHours}
              onChange={(e) => setDailyGoalHours(Number(e.target.value))}
              min={1}
              max={16}
            />
            <Input
              type="number"
              label="Pomodoro Focus Duration (Minutes)"
              value={focusMins}
              onChange={(e) => setFocusMins(Number(e.target.value))}
              min={10}
              max={120}
            />
          </div>

          <div className="flex justify-end">
            <Button type="submit" size="sm">
              Save Preferences
            </Button>
          </div>
        </form>
      </div>

      {/* Theme & Accent Color Customization */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
        <h3 className="mb-4 text-sm font-bold text-slate-900 dark:text-white">
          Theme & Appearance
        </h3>

        {/* Light / Dark / System */}
        <div className="mb-6">
          <label className="mb-2 block text-xs font-semibold text-slate-700 dark:text-slate-300">
            Color Scheme
          </label>
          <div className="grid grid-cols-3 gap-2 max-w-sm">
            {(['light', 'dark', 'system'] as ThemeMode[]).map((t) => (
              <button
                key={t}
                onClick={() => setTheme(t)}
                className={`flex items-center justify-center gap-1.5 rounded-xl border p-2.5 text-xs font-semibold capitalize transition-all ${
                  settings.theme === t
                    ? 'border-indigo-600 bg-indigo-50/80 text-indigo-700 dark:border-indigo-500 dark:bg-indigo-950/60 dark:text-indigo-300'
                    : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400'
                }`}
              >
                {t === 'light' ? <Sun className="h-3.5 w-3.5" /> : t === 'dark' ? <Moon className="h-3.5 w-3.5" /> : <Settings className="h-3.5 w-3.5" />}
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Accent Colors */}
        <div>
          <label className="mb-2 block text-xs font-semibold text-slate-700 dark:text-slate-300">
            Accent Brand Color
          </label>
          <div className="flex flex-wrap gap-2.5">
            {ACCENT_COLORS.map((accent) => (
              <button
                key={accent.id}
                onClick={() => setAccentColor(accent.id)}
                className={`flex items-center gap-2 rounded-xl border px-3 py-1.5 text-xs font-semibold transition-all ${
                  settings.accentColor === accent.id
                    ? 'border-slate-900 bg-slate-50 dark:border-white dark:bg-slate-800 ring-1 ring-slate-900 dark:ring-white'
                    : 'border-slate-200 bg-white hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900'
                }`}
              >
                <span className={`h-3.5 w-3.5 rounded-full ${accent.bg}`} />
                <span className="text-slate-800 dark:text-slate-200">{accent.name}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* AI Assistant API Key Configuration */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center gap-2 mb-2">
          <Key className="h-4 w-4 text-indigo-500" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            AI Assistant Configuration (Optional)
          </h3>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
          Aura includes a built-in pedagogical generation engine that works offline out of the box. You may also provide a custom OpenAI or Gemini key to route prompts to your private model.
        </p>
        <div className="flex gap-2">
          <Input
            type="password"
            placeholder="sk-..."
            value={aiKey}
            onChange={(e) => setAiKey(e.target.value)}
          />
          <Button
            size="sm"
            onClick={() => {
              updateSettings({ aiApiKey: aiKey.trim() || undefined })
              showToast('API key configuration saved', 'success')
            }}
          >
            Save Key
          </Button>
        </div>
      </div>

      {/* Data Management & Backup */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
        <h3 className="mb-2 text-sm font-bold text-slate-900 dark:text-white">
          Data Management & Local Backups
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
          Your data is stored privately in your browser storage. You can export a full JSON backup or reset anytime.
        </p>

        <div className="flex flex-wrap gap-2.5">
          <Button size="sm" variant="outline" onClick={handleExportData}>
            <Download className="h-3.5 w-3.5 mr-1" />
            Export Data (JSON)
          </Button>

          <label className="inline-flex cursor-pointer items-center justify-center rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800">
            <Upload className="h-3.5 w-3.5 mr-1" />
            Import Backup
            <input type="file" accept=".json" onChange={handleImportData} className="hidden" />
          </label>

          <Button size="sm" variant="subtle" onClick={() => setIsResetModalOpen(true)}>
            <RotateCcw className="h-3.5 w-3.5 mr-1" />
            Reset to Sample Data
          </Button>

          <Button size="sm" variant="danger" onClick={() => setIsClearModalOpen(true)}>
            <Trash2 className="h-3.5 w-3.5 mr-1" />
            Clear All Data
          </Button>
        </div>
      </div>

      {/* Confirm Dialogs */}
      <ConfirmDialog
        isOpen={isClearModalOpen}
        title="Clear All Data?"
        message="This will wipe all your tasks, study sessions, habits, and notes from this browser. This cannot be undone."
        confirmText="Yes, Wipe Everything"
        isDestructive={true}
        onConfirm={handleConfirmClear}
        onCancel={() => setIsClearModalOpen(false)}
      />

      <ConfirmDialog
        isOpen={isResetModalOpen}
        title="Reset to Sample Student Data?"
        message="This will overwrite current data with fresh sample student coursework, habits, and study sessions."
        confirmText="Reset to Sample Data"
        isDestructive={false}
        onConfirm={handleConfirmReset}
        onCancel={() => setIsResetModalOpen(false)}
      />
    </div>
  )
}
