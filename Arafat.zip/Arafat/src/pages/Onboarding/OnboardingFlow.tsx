import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Sparkles, ArrowRight, Check, Compass, Clock, BookOpen } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { useSettingsStore } from '@/store/useSettingsStore'
import { useUIStore } from '@/store/useUIStore'
import { triggerConfetti } from '@/utils/effects'

const GOAL_OPTIONS = [
  'Improve grades & GPA',
  'Learn programming & CS',
  'Prepare for exams & midterms',
  'Build consistent study habits',
  'Boost daily focus & stop procrastination',
  'Balance coursework & life',
]

export function OnboardingFlow() {
  const [step, setStep] = useState(1)
  const { settings, updateSettings, setOnboarded } = useSettingsStore()
  const { setActiveTab } = useUIStore()

  const [name, setName] = useState(settings.name || '')
  const [selectedGoals, setSelectedGoals] = useState<string[]>(settings.primaryGoals || ['Improve grades & GPA'])
  const [focusDuration, setFocusDuration] = useState(settings.focusDurationMinutes || 25)
  const [dailyHours, setDailyHours] = useState(settings.dailyStudyGoalMinutes ? settings.dailyStudyGoalMinutes / 60 : 3)

  const toggleGoal = (goal: string) => {
    if (selectedGoals.includes(goal)) {
      setSelectedGoals(selectedGoals.filter((g) => g !== goal))
    } else {
      setSelectedGoals([...selectedGoals, goal])
    }
  }

  const handleFinish = () => {
    updateSettings({
      name: name.trim() || 'Student',
      primaryGoals: selectedGoals,
      focusDurationMinutes: focusDuration,
      dailyStudyGoalMinutes: Math.round(dailyHours * 60),
      onboarded: true,
    })
    triggerConfetti()
    setOnboarded(true)
    setActiveTab('today')
  }

  const handleSkip = () => {
    setOnboarded(true)
    setActiveTab('today')
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-50/95 p-4 backdrop-blur-md dark:bg-slate-950/95">
      <div className="relative w-full max-w-lg overflow-hidden rounded-3xl border border-slate-200/90 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900 sm:p-10">
        {/* Progress Dots */}
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            {[1, 2, 3, 4, 5, 6].map((s) => (
              <div
                key={s}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  s === step
                    ? 'w-6 bg-indigo-600'
                    : s < step
                    ? 'w-2 bg-indigo-300 dark:bg-indigo-900'
                    : 'w-2 bg-slate-200 dark:bg-slate-800'
                }`}
              />
            ))}
          </div>
          {step < 6 && (
            <button
              onClick={handleSkip}
              className="text-xs font-semibold text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              Skip
            </button>
          )}
        </div>

        <AnimatePresence mode="wait">
          {/* Screen 1: Welcome */}
          {step === 1 && (
            <motion.div
              key="step-1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="text-center"
            >
              <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-xl shadow-indigo-600/30">
                <Compass className="h-8 w-8 stroke-[2.2]" />
              </div>
              <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
                Your study life, organized.
              </h1>
              <p className="mt-3 text-sm text-slate-500 dark:text-slate-400">
                A calm, focused system designed to keep your assignments, habits, and daily study momentum effortlessly on track.
              </p>
              <div className="mt-8">
                <Button size="lg" className="w-full" onClick={() => setStep(2)}>
                  Get Started <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Screen 2: Ask Name */}
          {step === 2 && (
            <motion.div
              key="step-2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                Step 2 of 6
              </span>
              <h2 className="mt-1 text-xl font-bold text-slate-900 dark:text-white sm:text-2xl">
                What should we call you?
              </h2>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Personalizes your dashboard greeting and study stats.
              </p>
              <div className="mt-6">
                <Input
                  label="Your First or Full Name"
                  placeholder="e.g. Alex, Sarah, David"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoFocus
                />
              </div>
              <div className="mt-8 flex justify-between">
                <Button variant="ghost" onClick={() => setStep(1)}>
                  Back
                </Button>
                <Button onClick={() => setStep(3)}>
                  Continue <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Screen 3: Primary Goals */}
          {step === 3 && (
            <motion.div
              key="step-3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                Step 3 of 6
              </span>
              <h2 className="mt-1 text-xl font-bold text-slate-900 dark:text-white sm:text-2xl">
                What are your main goals this semester?
              </h2>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Select all that apply to tailor your recommendations.
              </p>
              <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2">
                {GOAL_OPTIONS.map((goal) => {
                  const isSelected = selectedGoals.includes(goal)
                  return (
                    <button
                      key={goal}
                      type="button"
                      onClick={() => toggleGoal(goal)}
                      className={`flex items-center justify-between rounded-xl border p-3 text-left text-xs font-semibold transition-all ${
                        isSelected
                          ? 'border-indigo-600 bg-indigo-50/80 text-indigo-900 dark:border-indigo-500 dark:bg-indigo-950/60 dark:text-indigo-200'
                          : 'border-slate-200 text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800'
                      }`}
                    >
                      <span>{goal}</span>
                      {isSelected && <Check className="h-4 w-4 text-indigo-600 dark:text-indigo-400 shrink-0" />}
                    </button>
                  )
                })}
              </div>
              <div className="mt-8 flex justify-between">
                <Button variant="ghost" onClick={() => setStep(2)}>
                  Back
                </Button>
                <Button onClick={() => setStep(4)}>
                  Continue <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Screen 4: Focus Duration */}
          {step === 4 && (
            <motion.div
              key="step-4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                Step 4 of 6
              </span>
              <h2 className="mt-1 text-xl font-bold text-slate-900 dark:text-white sm:text-2xl">
                Preferred Focus Session Duration
              </h2>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                How long do you like to work before taking a break?
              </p>
              <div className="mt-6 space-y-3">
                {[
                  { mins: 25, title: '25 Minutes (Classic Pomodoro)', desc: 'Best for assignments and problem sets' },
                  { mins: 50, title: '50 Minutes (Deep Work)', desc: 'Ideal for reading, essays, and coding projects' },
                  { mins: 90, title: '90 Minutes (Ultradian Cycle)', desc: 'For intensive unbroken study marathons' },
                ].map((opt) => (
                  <button
                    key={opt.mins}
                    type="button"
                    onClick={() => setFocusDuration(opt.mins)}
                    className={`flex w-full items-center justify-between rounded-2xl border p-4 text-left transition-all ${
                      focusDuration === opt.mins
                        ? 'border-indigo-600 bg-indigo-50/80 dark:border-indigo-500 dark:bg-indigo-950/60'
                        : 'border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">{opt.title}</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{opt.desc}</p>
                    </div>
                    {focusDuration === opt.mins && (
                      <Check className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                    )}
                  </button>
                ))}
              </div>
              <div className="mt-8 flex justify-between">
                <Button variant="ghost" onClick={() => setStep(3)}>
                  Back
                </Button>
                <Button onClick={() => setStep(5)}>
                  Continue <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Screen 5: Daily Study Goal */}
          {step === 5 && (
            <motion.div
              key="step-5"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                Step 5 of 6
              </span>
              <h2 className="mt-1 text-xl font-bold text-slate-900 dark:text-white sm:text-2xl">
                Daily Study Target
              </h2>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                How many hours would you like to dedicate to focused study every day?
              </p>
              <div className="my-8 text-center">
                <div className="font-mono text-5xl font-extrabold text-indigo-600 dark:text-indigo-400">
                  {dailyHours} {dailyHours === 1 ? 'hour' : 'hours'}
                </div>
                <p className="mt-1 text-xs text-slate-400">Target: {dailyHours * 60} minutes/day</p>
                <div className="mt-6 flex justify-center gap-2">
                  {[1, 2, 3, 4, 5].map((h) => (
                    <button
                      key={h}
                      type="button"
                      onClick={() => setDailyHours(h)}
                      className={`h-10 w-10 rounded-xl font-bold text-xs transition-all ${
                        dailyHours === h
                          ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300'
                      }`}
                    >
                      {h}h
                    </button>
                  ))}
                </div>
              </div>
              <div className="mt-8 flex justify-between">
                <Button variant="ghost" onClick={() => setStep(4)}>
                  Back
                </Button>
                <Button onClick={() => setStep(6)}>
                  Continue <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Screen 6: Finish */}
          {step === 6 && (
            <motion.div
              key="step-6"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="text-center"
            >
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-500 text-white shadow-xl shadow-emerald-500/30">
                <Sparkles className="h-8 w-8" />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white sm:text-3xl">
                You're ready to build a better routine!
              </h2>
              <p className="mt-3 text-sm text-slate-500 dark:text-slate-400">
                Your workspace has been tailored with subjects, daily goals, and productivity tracking.
              </p>
              <div className="mt-8">
                <Button size="lg" className="w-full" onClick={handleFinish}>
                  Open My Dashboard 🚀
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
