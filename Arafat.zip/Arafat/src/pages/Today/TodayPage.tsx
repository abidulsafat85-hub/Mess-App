import React from 'react'
import { motion } from 'framer-motion'
import {
  Flame,
  Play,
  CheckCircle2,
  BookOpen,
  CheckSquare,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Clock,
} from 'lucide-react'
import { useSettingsStore } from '@/store/useSettingsStore'
import { useTaskStore } from '@/store/useTaskStore'
import { useHabitStore } from '@/store/useHabitStore'
import { useStudyStore } from '@/store/useStudyStore'
import { useFocusStore } from '@/store/useFocusStore'
import { useUIStore } from '@/store/useUIStore'
import { TaskCard } from '@/components/tasks/TaskCard'
import { QuickTaskInput } from '@/components/tasks/QuickTaskInput'
import { ProgressBar } from '@/components/ui/ProgressBar'
import { Button } from '@/components/ui/Button'
import {
  getTodayDateString,
  formatFullDate,
  getGreeting,
  getDailyMotivation,
  formatMinutes,
} from '@/utils/date'
import { isTaskToday, isTaskUpcoming } from '@/utils/date'

export function TodayPage() {
  const { settings } = useSettingsStore()
  const { tasks, toggleTask, getFocusNextTask } = useTaskStore()
  const { habits, toggleHabitDate } = useHabitStore()
  const { getTodayMinutes } = useStudyStore()
  const { setSelectedTask } = useFocusStore()
  const { openTaskModal, setActiveTab, setFocusModalOpen } = useUIStore()

  const todayStr = getTodayDateString()
  const todayTasks = tasks.filter((t) => isTaskToday(t.dueDate))
  const completedTodayTasks = todayTasks.filter((t) => t.completed)
  const taskProgressPercent =
    todayTasks.length > 0
      ? Math.round((completedTodayTasks.length / todayTasks.length) * 100)
      : 100

  // Focus Next task
  const focusNextTask = getFocusNextTask()

  // Upcoming tasks (next 3 days)
  const upcomingTasks = tasks.filter((t) => isTaskUpcoming(t.dueDate) && !t.completed).slice(0, 3)

  // Study stats
  const studyTodayMins = getTodayMinutes()
  const dailyStudyGoalMins = settings.dailyStudyGoalMinutes || 180
  const studyProgressPercent = Math.min(
    100,
    Math.round((studyTodayMins / dailyStudyGoalMins) * 100)
  )

  // Highest streak
  const highestStreak = habits.reduce((max, h) => Math.max(max, h.streak), 12)

  const handleStartFocusNext = () => {
    if (focusNextTask) {
      setSelectedTask(focusNextTask.id)
    }
    setFocusModalOpen(true)
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6 pb-24 sm:space-y-8">
      {/* Header Greeting & Date */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
          {getGreeting(settings.name)}
        </h1>
        <p className="mt-1 text-sm font-medium text-slate-500 dark:text-slate-400">
          {formatFullDate(new Date())}
        </p>
        <p className="mt-2 text-xs italic text-indigo-600 dark:text-indigo-400">
          "{getDailyMotivation()}"
        </p>
      </div>

      {/* Hero Overview Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        {/* Today's Tasks Progress */}
        <div className="rounded-2xl border border-slate-200/90 bg-white p-4.5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
            <span>TODAY'S PROGRESS</span>
            <CheckCircle2 className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2.5 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
              {taskProgressPercent}%
            </span>
            <span className="text-xs text-slate-500">
              {completedTodayTasks.length} / {todayTasks.length} completed
            </span>
          </div>
          <ProgressBar value={taskProgressPercent} color="emerald" size="sm" className="mt-3" />
        </div>

        {/* Study Time Today */}
        <div className="rounded-2xl border border-slate-200/90 bg-white p-4.5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
            <span>STUDY TODAY</span>
            <BookOpen className="h-4 w-4 text-indigo-500" />
          </div>
          <div className="mt-2.5 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
              {formatMinutes(studyTodayMins)}
            </span>
            <span className="text-xs text-slate-500">
              / {formatMinutes(dailyStudyGoalMins)} goal
            </span>
          </div>
          <ProgressBar value={studyProgressPercent} color="indigo" size="sm" className="mt-3" />
        </div>

        {/* Current Streak */}
        <div className="rounded-2xl border border-slate-200/90 bg-white p-4.5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
            <span>CURRENT STREAK</span>
            <Flame className="h-4 w-4 text-amber-500 fill-amber-500" />
          </div>
          <div className="mt-2.5 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold tracking-tight text-amber-600 dark:text-amber-400">
              🔥 {highestStreak}
            </span>
            <span className="text-xs text-slate-500">consecutive days</span>
          </div>
          <p className="mt-3 text-[11px] text-slate-400 truncate">
            Top habit: Study 2+ hours daily
          </p>
        </div>
      </div>

      {/* Focus Next Highlight Card */}
      {focusNextTask && (
        <div className="relative overflow-hidden rounded-2xl border border-indigo-100 bg-gradient-to-r from-indigo-50/90 via-indigo-50/50 to-white p-5 shadow-xs dark:border-indigo-950 dark:from-indigo-950/40 dark:via-slate-900 dark:to-slate-900">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1 rounded-md bg-indigo-600 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white">
                  <Sparkles className="h-3 w-3" />
                  Focus Next
                </span>
                <span className="text-xs font-semibold text-indigo-700 dark:text-indigo-300">
                  {focusNextTask.category}
                </span>
              </div>
              <h3 className="mt-2 text-base font-bold text-slate-900 dark:text-white">
                {focusNextTask.title}
              </h3>
              {focusNextTask.description && (
                <p className="mt-1 text-xs text-slate-600 dark:text-slate-300 line-clamp-1">
                  {focusNextTask.description}
                </p>
              )}
            </div>

            <Button
              size="md"
              onClick={handleStartFocusNext}
              className="shrink-0 bg-indigo-600 hover:bg-indigo-700 shadow-md shadow-indigo-600/25"
            >
              <Play className="h-3.5 w-3.5 fill-current mr-1" />
              Start Focus ({settings.focusDurationMinutes || 25}m)
            </Button>
          </div>
        </div>
      )}

      {/* Today's Habits Checklist */}
      <div className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Flame className="h-4 w-4 text-amber-500 fill-amber-500" />
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-slate-100">
              Today's Habits
            </h2>
          </div>
          <button
            onClick={() => setActiveTab('habits')}
            className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:underline dark:text-indigo-400"
          >
            View all <ArrowRight className="h-3 w-3" />
          </button>
        </div>

        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {habits.map((habit) => {
            const isDone = !!habit.logs[todayStr]
            return (
              <div
                key={habit.id}
                onClick={() => toggleHabitDate(habit.id, todayStr)}
                className={`flex cursor-pointer items-center justify-between rounded-xl border p-3 transition-all ${
                  isDone
                    ? 'border-emerald-200 bg-emerald-50/40 text-emerald-900 dark:border-emerald-900/40 dark:bg-emerald-950/20 dark:text-emerald-200'
                    : 'border-slate-200 bg-white hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <div
                    className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border text-xs font-bold transition-all ${
                      isDone
                        ? 'border-emerald-500 bg-emerald-500 text-white shadow-2xs'
                        : 'border-slate-300 bg-white text-transparent dark:border-slate-700 dark:bg-slate-800'
                    }`}
                  >
                    {isDone ? '✓' : ''}
                  </div>
                  <span className="text-xs font-semibold truncate text-slate-800 dark:text-slate-200">
                    {habit.name}
                  </span>
                </div>
                <span className="text-[11px] font-bold text-amber-500 shrink-0 ml-1">
                  🔥 {habit.streak}
                </span>
              </div>
            )
          })}
        </div>
      </div>

      {/* Main Task List Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckSquare className="h-4 w-4 text-indigo-600" />
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-slate-100">
              Today's Tasks ({todayTasks.length})
            </h2>
          </div>
          <button
            onClick={() => openTaskModal(null)}
            className="text-xs font-semibold text-indigo-600 hover:underline dark:text-indigo-400"
          >
            + New Task
          </button>
        </div>

        {/* Quick inline task input with NLP */}
        <QuickTaskInput />

        {/* Task Cards */}
        <div className="space-y-2.5 pt-1">
          {todayTasks.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-200 p-8 text-center text-xs text-slate-400 dark:border-slate-800">
              You're all caught up for today! 🎉
            </div>
          ) : (
            todayTasks.map((task) => <TaskCard key={task.id} task={task} />)
          )}
        </div>
      </div>

      {/* Up Next Preview */}
      {upcomingTasks.length > 0 && (
        <div className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Up Next
            </h3>
            <button
              onClick={() => setActiveTab('tasks')}
              className="text-xs font-semibold text-indigo-600 hover:underline dark:text-indigo-400"
            >
              All tasks
            </button>
          </div>
          <div className="space-y-2">
            {upcomingTasks.map((task) => (
              <div
                key={task.id}
                onClick={() => openTaskModal(task.id)}
                className="flex cursor-pointer items-center justify-between rounded-xl p-2.5 transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/50"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className="h-2 w-2 rounded-full bg-slate-300 dark:bg-slate-600" />
                  <span className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate">
                    {task.title}
                  </span>
                </div>
                <span className="text-xs text-slate-400 shrink-0">
                  {task.dueDate}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
