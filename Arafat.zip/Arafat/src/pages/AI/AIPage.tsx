import React, { useState } from 'react'
import {
  Sparkles,
  BookOpen,
  Calendar,
  Clock,
  ListTodo,
  CheckCircle2,
  HelpCircle,
  FileText,
  Plus,
  ArrowRight,
  Check,
  Send,
} from 'lucide-react'
import { aiService, AIStudyResponse, AIStudyPlanItem, AIQuizQuestion } from '@/services/aiService'
import { useTaskStore } from '@/store/useTaskStore'
import { useUIStore } from '@/store/useUIStore'
import { Button } from '@/components/ui/Button'
import { Input, Textarea } from '@/components/ui/Input'
import { getTodayDateString } from '@/utils/date'

type AITool = 'plan' | 'explain' | 'breakdown' | 'quiz' | 'summarize'

export function AIPage() {
  const [activeTool, setActiveTool] = useState<AITool>('plan')
  const [isLoading, setIsLoading] = useState(false)
  const [response, setResponse] = useState<AIStudyResponse | null>(null)

  // Plan Inputs
  const [subject, setSubject] = useState('Discrete Mathematics')
  const [availableHours, setAvailableHours] = useState(4)
  const [topics, setTopics] = useState('Graph Theory, Hamiltonian Paths, Tree Isomorphism')

  // Concept Input
  const [concept, setConcept] = useState('Dynamic Programming Tabulation vs Memoization')

  // Task Breakdown Input
  const [taskTitle, setTaskTitle] = useState('Operating Systems Multi-threading Semaphore Lab')

  // Quiz Input
  const [quizTopic, setQuizTopic] = useState('Database Normalization & BCNF')

  // Notes Input
  const [noteContent, setNoteContent] = useState(
    '1NF requires atomic values. 2NF removes partial key dependencies. 3NF removes transitive dependencies. BCNF ensures every determinant is a candidate key.'
  )

  // Quiz active state
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({})

  const { addBatchTasks } = useTaskStore()
  const { showToast, setActiveTab } = useUIStore()

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setResponse(null)
    setSelectedAnswers({})

    try {
      if (activeTool === 'plan') {
        const res = await aiService.generateStudyPlan({
          subject,
          examDate: getTodayDateString(),
          availableHours: Number(availableHours),
          topics,
        })
        setResponse(res)
      } else if (activeTool === 'explain') {
        const res = await aiService.explainConcept(concept)
        setResponse(res)
      } else if (activeTool === 'breakdown') {
        const res = await aiService.breakDownTask(taskTitle)
        setResponse(res)
      } else if (activeTool === 'quiz') {
        const res = await aiService.generateQuiz(quizTopic)
        setResponse(res)
      } else if (activeTool === 'summarize') {
        const res = await aiService.summarizeNotes(noteContent)
        setResponse(res)
      }
    } catch {
      showToast('Could not generate response. Please try again.', 'error')
    } finally {
      setIsLoading(false)
    }
  }

  // Handle "Add all to Tasks"
  const handleAddAllToTasks = async () => {
    if (!response?.planItems || response.planItems.length === 0) return

    const tasksToCreate = response.planItems.map((item) => ({
      title: item.title,
      description: item.description,
      completed: false,
      priority: item.priority,
      category: item.category,
      tags: ['AI-Plan', subject],
      dueDate: item.dueDate || getTodayDateString(),
      repeat: 'none' as const,
      estimatedMinutes: item.durationMinutes,
      subtasks: [],
    }))

    await addBatchTasks(tasksToCreate)
    showToast(`${tasksToCreate.length} tasks added to your schedule! 🚀`, 'success')
  }

  const handleSelectQuizAnswer = (qId: string, optIndex: number) => {
    setSelectedAnswers((prev) => ({ ...prev, [qId]: optIndex }))
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6 pb-24">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-md shadow-indigo-600/30">
            <Sparkles className="h-4 w-4" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
            AI Study Assistant
          </h1>
        </div>
        <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
          Pedagogical tools for rapid study plans, concept clarity, task breakdown, and active recall quizzes.
        </p>
      </div>

      {/* Feature Selector Tabs */}
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
        {[
          { id: 'plan', label: 'Study Plan', icon: Calendar },
          { id: 'explain', label: 'Explain Topic', icon: BookOpen },
          { id: 'breakdown', label: 'Break Down Task', icon: ListTodo },
          { id: 'quiz', label: 'Generate Quiz', icon: HelpCircle },
          { id: 'summarize', label: 'Summarize Notes', icon: FileText },
        ].map((tab) => {
          const Icon = tab.icon
          const isActive = activeTool === tab.id
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTool(tab.id as AITool)
                setResponse(null)
              }}
              className={`flex flex-col items-center gap-1.5 rounded-2xl border p-3 text-center transition-all ${
                isActive
                  ? 'border-indigo-600 bg-indigo-50/80 text-indigo-700 dark:border-indigo-500 dark:bg-indigo-950/60 dark:text-indigo-300 shadow-2xs font-bold'
                  : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 font-medium'
              }`}
            >
              <Icon className="h-4 w-4 shrink-0" />
              <span className="text-xs">{tab.label}</span>
            </button>
          )
        })}
      </div>

      {/* Input Form Box */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
        <form onSubmit={handleGenerate} className="space-y-4">
          {activeTool === 'plan' && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <Input
                  label="Subject / Exam Target *"
                  placeholder="e.g. Discrete Math, Biology 101"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  required
                />
                <Input
                  type="number"
                  label="Available Study Hours *"
                  placeholder="4"
                  value={availableHours}
                  onChange={(e) => setAvailableHours(Number(e.target.value))}
                  min={1}
                  max={24}
                  required
                />
              </div>
              <Input
                label="Topics to Cover (comma-separated)"
                placeholder="e.g. Graphs, Euler Circuits, Proofs"
                value={topics}
                onChange={(e) => setTopics(e.target.value)}
              />
            </div>
          )}

          {activeTool === 'explain' && (
            <div>
              <Input
                label="Topic or Difficult Concept *"
                placeholder="e.g. CAP Theorem, Fourier Transform, React Reconciliation"
                value={concept}
                onChange={(e) => setConcept(e.target.value)}
                required
              />
            </div>
          )}

          {activeTool === 'breakdown' && (
            <div>
              <Input
                label="Large or Intimidating Task *"
                placeholder="e.g. Write 10-page Research Term Paper on Operating Systems"
                value={taskTitle}
                onChange={(e) => setTaskTitle(e.target.value)}
                required
              />
            </div>
          )}

          {activeTool === 'quiz' && (
            <div>
              <Input
                label="Topic to Test *"
                placeholder="e.g. Database Normalization, Big-O Notation, Organic Chemistry"
                value={quizTopic}
                onChange={(e) => setQuizTopic(e.target.value)}
                required
              />
            </div>
          )}

          {activeTool === 'summarize' && (
            <div>
              <Textarea
                label="Paste Notes or Lecture Content *"
                placeholder="Paste lecture transcript, reading excerpt, or raw notes..."
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                rows={4}
                required
              />
            </div>
          )}

          <div className="flex justify-end">
            <Button type="submit" isLoading={isLoading} className="px-6">
              <Sparkles className="h-4 w-4 mr-1.5" />
              Generate
            </Button>
          </div>
        </form>
      </div>

      {/* AI Response Output */}
      {response && (
        <div className="space-y-4 rounded-3xl border border-indigo-100 bg-white p-6 shadow-sm dark:border-indigo-950 dark:bg-slate-900">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between border-b border-slate-100 pb-4 dark:border-slate-800">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                AI Generated Output
              </span>
              <h3 className="mt-1 text-lg font-bold text-slate-900 dark:text-white">
                {response.title}
              </h3>
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                {response.summary}
              </p>
            </div>

            {/* If Plan or Breakdown: Add all to Tasks CTA */}
            {response.planItems && response.planItems.length > 0 && (
              <Button onClick={handleAddAllToTasks} size="md" className="shrink-0 bg-emerald-600 hover:bg-emerald-700">
                <Plus className="h-4 w-4 mr-1.5" />
                Add All to Tasks ({response.planItems.length})
              </Button>
            )}
          </div>

          {/* Plan or Task Breakdown Items */}
          {response.planItems && (
            <div className="space-y-2.5">
              {response.planItems.map((item, idx) => (
                <div
                  key={item.id}
                  className="flex items-start justify-between gap-3 rounded-2xl border border-slate-100 bg-slate-50/70 p-3.5 text-xs dark:border-slate-800 dark:bg-slate-800/40"
                >
                  <div className="flex items-start gap-2.5 min-w-0">
                    <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-indigo-100 font-bold text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
                      {idx + 1}
                    </span>
                    <div>
                      <h4 className="font-semibold text-slate-900 dark:text-slate-100">
                        {item.title}
                      </h4>
                      <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                        {item.description}
                      </p>
                    </div>
                  </div>
                  <span className="shrink-0 rounded-md bg-white px-2 py-1 font-semibold text-slate-700 shadow-2xs dark:bg-slate-800 dark:text-slate-300">
                    {item.durationMinutes} min
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Explanation or Markdown Summary */}
          {response.explanationMarkdown && (
            <div className="prose prose-sm dark:prose-invert max-w-none text-xs leading-relaxed text-slate-700 dark:text-slate-300 whitespace-pre-line rounded-2xl bg-slate-50 p-4 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
              {response.explanationMarkdown}
            </div>
          )}

          {/* Quiz Questions */}
          {response.quizQuestions && (
            <div className="space-y-4">
              {response.quizQuestions.map((q, idx) => {
                const userChoice = selectedAnswers[q.id]
                const hasAnswered = userChoice !== undefined
                const isCorrect = userChoice === q.correctIndex

                return (
                  <div
                    key={q.id}
                    className="rounded-2xl border border-slate-100 bg-slate-50/70 p-4 text-xs dark:border-slate-800 dark:bg-slate-800/50"
                  >
                    <p className="font-bold text-slate-900 dark:text-slate-100 mb-3">
                      {idx + 1}. {q.question}
                    </p>

                    <div className="space-y-2">
                      {q.options.map((opt, optIdx) => {
                        let btnStyle =
                          'border-slate-200 bg-white text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200'

                        if (hasAnswered) {
                          if (optIdx === q.correctIndex) {
                            btnStyle = 'border-emerald-500 bg-emerald-50 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-200 font-bold'
                          } else if (userChoice === optIdx) {
                            btnStyle = 'border-rose-500 bg-rose-50 text-rose-800 dark:bg-rose-950/60 dark:text-rose-200'
                          }
                        }

                        return (
                          <button
                            key={optIdx}
                            disabled={hasAnswered}
                            onClick={() => handleSelectQuizAnswer(q.id, optIdx)}
                            className={`flex w-full items-center justify-between rounded-xl border p-2.5 text-left transition-all ${btnStyle}`}
                          >
                            <span>{opt}</span>
                            {hasAnswered && optIdx === q.correctIndex && (
                              <Check className="h-4 w-4 text-emerald-600 dark:text-emerald-400 shrink-0 ml-2" />
                            )}
                          </button>
                        )
                      })}
                    </div>

                    {hasAnswered && (
                      <div className="mt-3 rounded-xl bg-indigo-50/70 p-2.5 text-[11px] text-indigo-900 dark:bg-indigo-950/50 dark:text-indigo-200">
                        <span className="font-bold">
                          {isCorrect ? '✅ Correct! ' : '❌ Incorrect. '}
                        </span>
                        {q.explanation}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          )}

          {/* Actionable Tips */}
          {response.actionableTips && (
            <div className="border-t border-slate-100 pt-3 dark:border-slate-800">
              <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                Pro Study Tips
              </h4>
              <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-400 list-disc list-inside">
                {response.actionableTips.map((tip, i) => (
                  <li key={i}>{tip}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
