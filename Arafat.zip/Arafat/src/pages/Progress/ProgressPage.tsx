import { useState } from 'react'
import {
  TrendingUp,
  Flame,
  CheckCircle2,
  BookOpen,
  Calendar,
  Sparkles,
  PieChart as PieChartIcon,
  Award,
} from 'lucide-react'
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
} from 'recharts'
import { subDays, format, parseISO } from 'date-fns'
import { useTaskStore } from '@/store/useTaskStore'
import { useStudyStore } from '@/store/useStudyStore'
import { useHabitStore } from '@/store/useHabitStore'
import { useGoalStore } from '@/store/useGoalStore'
import { useReviewStore } from '@/store/useReviewStore'
import { useUIStore } from '@/store/useUIStore'
import { Button } from '@/components/ui/Button'
import { formatMinutes } from '@/utils/date'

type DateRange = '7' | '30' | '90'

export function ProgressPage() {
  const [range, setRange] = useState<DateRange>('7')
  const { setDailyReviewOpen } = useUIStore()

  const { tasks } = useTaskStore()
  const { sessions, subjects } = useStudyStore()
  const { habits } = useHabitStore()
  const { goals } = useGoalStore()
  const { reviews } = useReviewStore()

  const daysCount = parseInt(range, 10)
  const today = new Date()

  // Trend data for study hours
  const trendData = Array.from({ length: Math.min(daysCount, 14) }, (_, i) => {
    const d = subDays(today, Math.min(daysCount, 14) - 1 - i)
    const dStr = format(d, 'yyyy-MM-dd')
    const dayLabel = format(d, daysCount <= 7 ? 'EEE' : 'MMM d')
    const dayMinutes = sessions
      .filter((s) => s.date === dStr)
      .reduce((acc, s) => acc + s.durationMinutes, 0)
    const dayTasks = tasks.filter((t) => t.dueDate === dStr && t.completed).length

    return {
      name: dayLabel,
      date: dStr,
      studyHours: Number((dayMinutes / 60).toFixed(1)),
      tasksCompleted: dayTasks,
    }
  })

  // Subject distribution
  const subjectTimeMap: Record<string, { name: string; color: string; minutes: number }> = {}
  subjects.forEach((s) => {
    subjectTimeMap[s.id] = { name: s.name, color: s.color, minutes: 0 }
  })
  sessions.forEach((sess) => {
    if (subjectTimeMap[sess.subjectId]) {
      subjectTimeMap[sess.subjectId].minutes += sess.durationMinutes
    }
  })
  const pieData = Object.values(subjectTimeMap).filter((item) => item.minutes > 0)

  // Overall totals
  const totalTasksCompleted = tasks.filter((t) => t.completed).length
  const totalStudyMinutes = sessions.reduce((acc, s) => acc + s.durationMinutes, 0)
  const highestStreak = habits.reduce((max, h) => Math.max(max, h.streak), 12)
  const completedGoals = goals.filter((g) => g.progress === 100).length

  // Find best study day
  let bestDayName = 'Thursday'
  let maxDayHours = 0
  trendData.forEach((td) => {
    if (td.studyHours > maxDayHours) {
      maxDayHours = td.studyHours
      bestDayName = td.name
    }
  })

  return (
    <div className="mx-auto max-w-5xl space-y-6 pb-24">
      {/* Header & Range Selector */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
            Productivity Analytics & Insights
          </h1>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Real data on your study time, completion rates, and weekly consistency.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Range tabs */}
          <div className="flex rounded-xl border border-slate-200 bg-white p-0.5 dark:border-slate-800 dark:bg-slate-900">
            {(['7', '30', '90'] as DateRange[]).map((r) => (
              <button
                key={r}
                onClick={() => setRange(r)}
                className={`rounded-lg px-3 py-1 text-xs font-semibold transition-colors ${
                  range === r
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
                }`}
              >
                {r} Days
              </button>
            ))}
          </div>

          <Button size="sm" variant="subtle" onClick={() => setDailyReviewOpen(true)}>
            <Sparkles className="h-4 w-4 mr-1 text-indigo-500" />
            Review Today
          </Button>
        </div>
      </div>

      {/* Encouraging Smart Summary Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-indigo-100 bg-gradient-to-br from-indigo-50/70 via-white to-purple-50/40 p-6 dark:border-indigo-950 dark:from-indigo-950/40 dark:via-slate-900 dark:to-slate-900 shadow-2xs">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
          <Award className="h-4 w-4" />
          Personal Performance Insight
        </div>
        <h3 className="mt-2 text-lg font-bold text-slate-900 dark:text-white sm:text-xl">
          "This week you studied {formatMinutes(totalStudyMinutes)}, completed {totalTasksCompleted} tasks, and maintained a {highestStreak}-day streak."
        </h3>
        <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
          Your most productive study day was <span className="font-semibold text-slate-800 dark:text-slate-200">{bestDayName}</span>. You are studying with high retention and steady focus. Keep up the rhythm!
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-4.5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
          <span className="text-[11px] font-semibold text-slate-400 uppercase">Total Study Time</span>
          <div className="mt-1 text-2xl font-extrabold text-indigo-600 dark:text-indigo-400">
            {formatMinutes(totalStudyMinutes)}
          </div>
          <span className="text-[11px] text-slate-400">logged in sessions</span>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4.5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
          <span className="text-[11px] font-semibold text-slate-400 uppercase">Tasks Completed</span>
          <div className="mt-1 text-2xl font-extrabold text-emerald-600 dark:text-emerald-400">
            {totalTasksCompleted}
          </div>
          <span className="text-[11px] text-slate-400">assignments & todos</span>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4.5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
          <span className="text-[11px] font-semibold text-slate-400 uppercase">Current Streak</span>
          <div className="mt-1 text-2xl font-extrabold text-amber-500">
            🔥 {highestStreak}d
          </div>
          <span className="text-[11px] text-slate-400">consistent days</span>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4.5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
          <span className="text-[11px] font-semibold text-slate-400 uppercase">Goals Achieved</span>
          <div className="mt-1 text-2xl font-extrabold text-purple-600 dark:text-purple-400">
            {completedGoals} / {goals.length}
          </div>
          <span className="text-[11px] text-slate-400">major milestones</span>
        </div>
      </div>

      {/* Main Charts Grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Study Hours Trend Area Chart (2 cols) */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs dark:border-slate-800 dark:bg-slate-900 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Study Hours Trend
            </h3>
            <span className="text-xs text-slate-400">Hours / day</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorHours" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} unit="h" />
                <Tooltip
                  formatter={(val) => [`${val} hrs`, 'Study Time']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#1e293b',
                    borderRadius: '12px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Area type="monotone" dataKey="studyHours" stroke="#6366f1" strokeWidth={2.5} fillOpacity={1} fill="url(#colorHours)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Subject Time Allocation Donut Chart (1 col) */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
          <h3 className="mb-4 text-sm font-bold text-slate-900 dark:text-white">
            Subject Time Distribution
          </h3>
          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={70}
                  paddingAngle={4}
                  dataKey="minutes"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val) => [`${formatMinutes(Number(val) || 0)}`, 'Time Spent']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#1e293b',
                    borderRadius: '12px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-3 space-y-1.5 max-h-24 overflow-y-auto pr-1">
            {pieData.map((item) => (
              <div key={item.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                  <span className="truncate text-slate-700 dark:text-slate-300">{item.name}</span>
                </div>
                <span className="text-slate-500 shrink-0 font-medium">{formatMinutes(item.minutes)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Task Completion Activity Bar Chart */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            Tasks Completed Per Day
          </h3>
          <span className="text-xs text-slate-400">Total assignments checked off</span>
        </div>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={trendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip
                formatter={(val) => [`${val} tasks`, 'Completed']}
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#1e293b',
                  borderRadius: '12px',
                  color: '#fff',
                  fontSize: '12px',
                }}
              />
              <Bar dataKey="tasksCompleted" fill="#10b981" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}
