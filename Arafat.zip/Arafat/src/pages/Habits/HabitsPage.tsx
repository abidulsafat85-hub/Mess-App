import { useState } from 'react'
import { Plus, Flame, Trophy, CheckCircle2 } from 'lucide-react'
import { useHabitStore } from '@/store/useHabitStore'
import { HabitCard } from '@/components/habits/HabitCard'
import { HabitModal } from '@/components/habits/HabitModal'
import { Button } from '@/components/ui/Button'
import { EmptyState } from '@/components/ui/EmptyState'
import { Habit } from '@/types'

export function HabitsPage() {
  const { habits, getTodayHabitsProgress } = useHabitStore()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingHabit, setEditingHabit] = useState<Habit | null>(null)

  const progress = getTodayHabitsProgress()
  const totalStreaks = habits.reduce((acc, h) => acc + h.streak, 0)
  const bestStreak = habits.reduce((max, h) => Math.max(max, h.longestStreak), 0)

  const handleEdit = (habit: Habit) => {
    setEditingHabit(habit)
    setIsModalOpen(true)
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6 pb-24">
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
            Habit Consistency
          </h1>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Build discipline with small, non-negotiable daily routines.
          </p>
        </div>

        <Button
          size="md"
          onClick={() => {
            setEditingHabit(null)
            setIsModalOpen(true)
          }}
        >
          <Plus className="h-4 w-4 mr-1" />
          New Habit
        </Button>
      </div>

      {/* Metrics Banner */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
          <span className="text-xs font-semibold text-slate-400">TODAY'S COMPLETION</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 dark:text-white">
              {progress.percentage}%
            </span>
            <span className="text-xs text-slate-500">
              {progress.completed} of {progress.total} done
            </span>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
          <span className="text-xs font-semibold text-slate-400">ACTIVE STREAKS</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-amber-500">
              🔥 {totalStreaks}
            </span>
            <span className="text-xs text-slate-500">cumulative days</span>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
          <span className="text-xs font-semibold text-slate-400">LONGEST RECORD</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-emerald-500">
              🏆 {bestStreak}
            </span>
            <span className="text-xs text-slate-500">best personal streak</span>
          </div>
        </div>
      </div>

      {/* Habit Cards */}
      <div className="space-y-3">
        {habits.length === 0 ? (
          <EmptyState
            icon={<Flame className="h-6 w-6 text-amber-500" />}
            title="Build your first habit"
            description="Start with something simple: Study 25 minutes, Drink water, or Read 10 pages."
            actionLabel="+ New Habit"
            onAction={() => {
              setEditingHabit(null)
              setIsModalOpen(true)
            }}
          />
        ) : (
          habits.map((habit) => (
            <HabitCard key={habit.id} habit={habit} onEdit={handleEdit} />
          ))
        )}
      </div>

      <HabitModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false)
          setEditingHabit(null)
        }}
        editingHabit={editingHabit}
      />
    </div>
  )
}
