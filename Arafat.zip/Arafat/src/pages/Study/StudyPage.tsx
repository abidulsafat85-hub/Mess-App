import { useState } from 'react'
import {
  BookOpen,
  Plus,
  Play,
  Clock,
  Calendar,
  Sparkles,
  BarChart3,
  TrendingUp,
} from 'lucide-react'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from 'recharts'
import { subDays, format, parseISO } from 'date-fns'
import { useStudyStore } from '@/store/useStudyStore'
import { useFocusStore } from '@/store/useFocusStore'
import { useSettingsStore } from '@/store/useSettingsStore'
import { useUIStore } from '@/store/useUIStore'
import { StudyCard } from '@/components/study/StudyCard'
import { StudySessionModal } from '@/components/study/StudySessionModal'
import { SubjectModal } from '@/components/study/SubjectModal'
import { Button } from '@/components/ui/Button'
import { ProgressBar } from '@/components/ui/ProgressBar'
import { formatMinutes } from '@/utils/date'
import { StudySubject } from '@/types'

export function StudyPage() {
  const { subjects, sessions, getTodayMinutes, getWeeklyMinutes } = useStudyStore()
  const { settings } = useSettingsStore()
  const { setFocusModalOpen } = useUIStore()

  const [isSessionModalOpen, setIsSessionModalOpen] = useState(false)
  const [isSubjectModalOpen, setIsSubjectModalOpen] = useState(false)
  const [editingSubject, setEditingSubject] = useState<StudySubject | null>(null)

  const todayMinutes = getTodayMinutes()
  const dailyGoalMinutes = settings.dailyStudyGoalMinutes || 180
  const todayProgressPercent = Math.min(100, Math.round((todayMinutes / dailyGoalMinutes) * 100))

  const weeklyMinutes = getWeeklyMinutes()

  // Prepare weekly chart data (last 7 days)
  const today = new Date()
  const weeklyChartData = Array.from({ length: 7 }, (_, i) => {
    const d = subDays(today, 6 - i)
    const dStr = format(d, 'yyyy-MM-dd')
    const dayName = format(d, 'EEE') // Mon, Tue...
    const minutes = sessions
      .filter((s) => s.date === dStr)
      .reduce((acc, s) => acc + s.durationMinutes, 0)
    return {
      day: dayName,
      date: dStr,
      hours: Number((minutes / 60).toFixed(1)),
      minutes,
    }
  })

  const handleEditSubject = (subject: StudySubject) => {
    setEditingSubject(subject)
    setIsSubjectModalOpen(true)
  }

  return (
    <div className="mx-auto max-w-5xl space-y-6 pb-24">
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
            Study Dashboard & Subjects
          </h1>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Track deep work hours, subject breakdowns, and session logs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setEditingSubject(null)
              setIsSubjectModalOpen(true)
            }}
          >
            + Add Subject
          </Button>
          <Button size="sm" onClick={() => setIsSessionModalOpen(true)}>
            <Plus className="h-4 w-4 mr-1" />
            Log Session
          </Button>
        </div>
      </div>

      {/* Top Banner: Today's Study Time vs Goal */}
      <div className="rounded-3xl border border-slate-200/90 bg-white p-6 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              Today's Study Progress
            </span>
            <div className="mt-1.5 flex items-baseline gap-3">
              <span className="text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-5xl">
                {formatMinutes(todayMinutes)}
              </span>
              <span className="text-sm font-semibold text-slate-500 dark:text-slate-400">
                / {formatMinutes(dailyGoalMinutes)} daily target
              </span>
            </div>
            <p className="mt-1 text-xs text-slate-400">
              {todayProgressPercent >= 100
                ? "🎉 You've reached your daily study goal!"
                : `Only ${formatMinutes(dailyGoalMinutes - todayMinutes)} left to complete today's goal.`}
            </p>
          </div>

          <Button
            size="lg"
            onClick={() => setFocusModalOpen(true)}
            className="shrink-0 bg-indigo-600 hover:bg-indigo-700 shadow-md shadow-indigo-600/25"
          >
            <Play className="h-4 w-4 fill-current mr-1.5" />
            Start Pomodoro
          </Button>
        </div>

        <ProgressBar
          value={todayProgressPercent}
          color={todayProgressPercent >= 100 ? 'emerald' : 'indigo'}
          size="md"
          className="mt-5"
        />
      </div>

      {/* Weekly Study Hours Chart */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Weekly Study Time ({formatMinutes(weeklyMinutes)})
            </h3>
          </div>
          <span className="text-xs text-slate-400">Past 7 days</span>
        </div>

        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={weeklyChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} unit="h" />
              <Tooltip
                formatter={(val) => [`${val} hours`, 'Study Time']}
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#1e293b',
                  borderRadius: '12px',
                  color: '#fff',
                  fontSize: '12px',
                }}
              />
              <Bar dataKey="hours" fill="#6366f1" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Subjects Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-slate-100">
            Enrolled Subjects ({subjects.length})
          </h2>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {subjects.map((subject) => {
            const subjectSessions = sessions.filter((s) => s.subjectId === subject.id)
            const totalMins = subjectSessions.reduce((acc, s) => acc + s.durationMinutes, 0)
            const weeklyMins = subjectSessions
              .filter((s) => {
                try {
                  return parseISO(s.date) >= subDays(new Date(), 7)
                } catch {
                  return false
                }
              })
              .reduce((acc, s) => acc + s.durationMinutes, 0)

            return (
              <StudyCard
                key={subject.id}
                subject={subject}
                weeklyMinutes={weeklyMins}
                totalMinutes={totalMins}
                recentSessions={subjectSessions.slice(0, 3)}
                onEdit={handleEditSubject}
              />
            )
          })}
        </div>
      </div>

      {/* Recent Sessions Log History */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
        <h3 className="mb-3 text-sm font-bold text-slate-900 dark:text-white">
          Recent Study Sessions
        </h3>
        <div className="space-y-2">
          {sessions.slice(0, 5).map((session) => {
            const subj = subjects.find((s) => s.id === session.subjectId)
            return (
              <div
                key={session.id}
                className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/60 p-3 text-xs dark:border-slate-800 dark:bg-slate-800/40"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span
                    className="h-2.5 w-2.5 shrink-0 rounded-full"
                    style={{ backgroundColor: subj?.color || '#6366f1' }}
                  />
                  <div>
                    <h4 className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                      {session.topic}
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      {subj?.name} • {session.date}
                    </p>
                  </div>
                </div>

                <div className="font-semibold text-indigo-600 dark:text-indigo-400 shrink-0">
                  {formatMinutes(session.durationMinutes)}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Modals */}
      <StudySessionModal
        isOpen={isSessionModalOpen}
        onClose={() => setIsSessionModalOpen(false)}
      />

      <SubjectModal
        isOpen={isSubjectModalOpen}
        onClose={() => {
          setIsSubjectModalOpen(false)
          setEditingSubject(null)
        }}
        editingSubject={editingSubject}
      />
    </div>
  )
}
