import { useState } from 'react'
import { Plus, Search, FileText, Pin } from 'lucide-react'
import { useNoteStore } from '@/store/useNoteStore'
import { NoteCard } from '@/components/notes/NoteCard'
import { NoteModal } from '@/components/notes/NoteModal'
import { Button } from '@/components/ui/Button'
import { EmptyState } from '@/components/ui/EmptyState'
import { Note, NoteCategory } from '@/types'

export function NotesPage() {
  const {
    categoryFilter,
    setCategoryFilter,
    searchQuery,
    setSearchQuery,
    getFilteredNotes,
  } = useNoteStore()

  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingNote, setEditingNote] = useState<Note | null>(null)

  const notes = getFilteredNotes()

  const categories: (NoteCategory | 'all')[] = ['all', 'Study', 'Ideas', 'Important', 'Personal']

  const handleEdit = (note: Note) => {
    setEditingNote(note)
    setIsModalOpen(true)
  }

  return (
    <div className="mx-auto max-w-5xl space-y-6 pb-24">
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
            Quick Notes & Study Sheets
          </h1>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Lightweight cheat sheets, summaries, and lecture reflections.
          </p>
        </div>

        <Button
          size="md"
          onClick={() => {
            setEditingNote(null)
            setIsModalOpen(true)
          }}
        >
          <Plus className="h-4 w-4 mr-1" />
          New Note
        </Button>
      </div>

      {/* Filter Tabs & Search */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex overflow-x-auto gap-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`rounded-xl px-3.5 py-1.5 text-xs font-semibold capitalize transition-colors ${
                categoryFilter === cat
                  ? 'bg-indigo-600 text-white'
                  : 'bg-white text-slate-600 hover:bg-slate-100 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
              }`}
            >
              {cat === 'all' ? 'All Notes' : cat}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="pointer-events-none absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search notes or #tags..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-8.5 w-full rounded-xl border border-slate-200 bg-white pl-8 pr-3 text-xs placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100"
          />
        </div>
      </div>

      {/* Notes Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {notes.length === 0 ? (
          <div className="col-span-full">
            <EmptyState
              icon={<FileText className="h-6 w-6 text-purple-500" />}
              title="Capture your first idea"
              description="Keep quick notes, formulas, or checklists without clutter."
              actionLabel="+ New Note"
              onAction={() => {
                setEditingNote(null)
                setIsModalOpen(true)
              }}
            />
          </div>
        ) : (
          notes.map((note) => (
            <NoteCard key={note.id} note={note} onEdit={handleEdit} />
          ))
        )}
      </div>

      <NoteModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false)
          setEditingNote(null)
        }}
        editingNote={editingNote}
      />
    </div>
  )
}
