import { useEffect } from 'react'
import { useSettingsStore } from '@/store/useSettingsStore'
import { useTaskStore } from '@/store/useTaskStore'
import { useHabitStore } from '@/store/useHabitStore'
import { useGoalStore } from '@/store/useGoalStore'
import { useStudyStore } from '@/store/useStudyStore'
import { useNoteStore } from '@/store/useNoteStore'
import { useReviewStore } from '@/store/useReviewStore'
import { useUIStore } from '@/store/useUIStore'
import { useKeyboardShortcuts } from '@/hooks/useKeyboardShortcuts'

import { Sidebar } from '@/components/layout/Sidebar'
import { Header } from '@/components/layout/Header'
import { BottomNavigation } from '@/components/layout/BottomNavigation'
import { FloatingActionButton } from '@/components/layout/FloatingActionButton'
import { ToastContainer } from '@/components/ui/ToastContainer'

import { TaskModal } from '@/components/tasks/TaskModal'
import { FocusModal } from '@/components/focus/FocusModal'
import { SearchCommand } from '@/components/search/SearchCommand'
import { DailyReviewModal } from '@/components/review/DailyReviewModal'
import { QuickAddModal } from '@/components/layout/QuickAddModal'

import { TodayPage } from '@/pages/Today/TodayPage'
import { CalendarPage } from '@/pages/Calendar/CalendarPage'
import { TasksPage } from '@/pages/Tasks/TasksPage'
import { StudyPage } from '@/pages/Study/StudyPage'
import { HabitsPage } from '@/pages/Habits/HabitsPage'
import { GoalsPage } from '@/pages/Goals/GoalsPage'
import { NotesPage } from '@/pages/Notes/NotesPage'
import { ProgressPage } from '@/pages/Progress/ProgressPage'
import { AIPage } from '@/pages/AI/AIPage'
import { ProfilePage } from '@/pages/Profile/ProfilePage'
import { OnboardingFlow } from '@/pages/Onboarding/OnboardingFlow'

export default function App() {
  const { settings } = useSettingsStore()
  const { activeTab } = useUIStore()

  const { loadTasks } = useTaskStore()
  const { loadHabits } = useHabitStore()
  const { loadGoals } = useGoalStore()
  const { loadStudyData } = useStudyStore()
  const { loadNotes } = useNoteStore()
  const { loadReviews } = useReviewStore()

  // Register global shortcuts
  useKeyboardShortcuts()

  // Initialize initial data stores on load
  useEffect(() => {
    loadTasks()
    loadHabits()
    loadGoals()
    loadStudyData()
    loadNotes()
    loadReviews()
  }, [loadTasks, loadHabits, loadGoals, loadStudyData, loadNotes, loadReviews])

  return (
    <div className="flex min-h-screen bg-slate-50/50 text-slate-900 transition-colors dark:bg-[#0b0f19] dark:text-slate-100">
      {/* Onboarding Flow if not completed */}
      {!settings.onboarded && <OnboardingFlow />}

      {/* Desktop Left Sidebar Navigation */}
      <Sidebar />

      {/* Main App Content Area */}
      <div className="flex flex-1 flex-col min-w-0">
        <Header />

        <main className="flex-1 overflow-y-auto px-4 py-6 sm:px-8 sm:py-8">
          {activeTab === 'today' && <TodayPage />}
          {activeTab === 'calendar' && <CalendarPage />}
          {activeTab === 'tasks' && <TasksPage />}
          {activeTab === 'study' && <StudyPage />}
          {activeTab === 'habits' && <HabitsPage />}
          {activeTab === 'goals' && <GoalsPage />}
          {activeTab === 'notes' && <NotesPage />}
          {activeTab === 'progress' && <ProgressPage />}
          {activeTab === 'ai' && <AIPage />}
          {activeTab === 'profile' && <ProfilePage />}
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <BottomNavigation />

      {/* Floating Action Button */}
      <FloatingActionButton />

      {/* Global Modals & Overlays */}
      <TaskModal />
      <FocusModal />
      <SearchCommand />
      <DailyReviewModal />
      <QuickAddModal />
      <ToastContainer />
    </div>
  )
}
