import { useEffect } from 'react'
import { useUIStore } from '@/store/useUIStore'

export function useKeyboardShortcuts() {
  const {
    openTaskModal,
    setFocusModalOpen,
    setActiveTab,
    setSearchOpen,
    isTaskModalOpen,
    isFocusModalOpen,
    isSearchOpen,
    isDailyReviewOpen,
  } = useUIStore()

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger shortcuts if typing inside an input, textarea, or contentEditable
      const target = e.target as HTMLElement
      if (
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.tagName === 'SELECT' ||
        target.isContentEditable
      ) {
        return
      }

      // ⌘K or Ctrl+K for search
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        setSearchOpen(true)
        return
      }

      // Single-letter shortcuts when no modal is open
      const anyModalOpen =
        isTaskModalOpen || isFocusModalOpen || isSearchOpen || isDailyReviewOpen

      if (!anyModalOpen && !e.metaKey && !e.ctrlKey && !e.altKey) {
        switch (e.key.toLowerCase()) {
          case 'n':
            e.preventDefault()
            openTaskModal(null)
            break
          case 'f':
            e.preventDefault()
            setFocusModalOpen(true)
            break
          case 'c':
            e.preventDefault()
            setActiveTab('calendar')
            break
          case 's':
            e.preventDefault()
            setSearchOpen(true)
            break
        }
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [
    openTaskModal,
    setFocusModalOpen,
    setActiveTab,
    setSearchOpen,
    isTaskModalOpen,
    isFocusModalOpen,
    isSearchOpen,
    isDailyReviewOpen,
  ])
}
