export type Priority = 'low' | 'medium' | 'high' | 'urgent'

export type TaskCategory =
  | 'Study'
  | 'Coding'
  | 'Personal'
  | 'Health'
  | 'Finance'
  | 'Other'

export type RepeatInterval = 'none' | 'daily' | 'weekly' | 'monthly'

export interface Subtask {
  id: string
  title: string
  completed: boolean
}

export interface Task {
  id: string
  title: string
  description?: string
  completed: boolean
  priority: Priority
  category: TaskCategory
  tags: string[]
  dueDate: string // YYYY-MM-DD
  dueTime?: string // HH:mm
  reminder?: boolean
  repeat: RepeatInterval
  estimatedMinutes?: number
  subtasks: Subtask[]
  notes?: string
  createdAt: string
  updatedAt: string
  completedAt?: string
}

export type HabitFrequency = 'daily' | 'weekdays' | 'weekends'

export interface Habit {
  id: string
  name: string
  category: string
  frequency: HabitFrequency
  target: number // per day
  streak: number
  longestStreak: number
  logs: Record<string, boolean> // 'YYYY-MM-DD' -> true
  reminder?: string // HH:mm
  createdAt: string
}

export interface Milestone {
  id: string
  title: string
  completed: boolean
  targetDate?: string
}

export interface Goal {
  id: string
  title: string
  description?: string
  deadline: string
  progress: number // 0-100
  milestones: Milestone[]
  category: string
  createdAt: string
}

export interface StudySubject {
  id: string
  name: string
  color: string // Hex or color name
  description?: string
  goalMinutesWeekly: number
  createdAt: string
}

export interface StudySession {
  id: string
  subjectId: string
  topic: string
  durationMinutes: number
  date: string // YYYY-MM-DD
  notes?: string
  taskId?: string
  createdAt: string
}

export type NoteCategory = 'Study' | 'Ideas' | 'Important' | 'Personal'

export interface NoteChecklistItem {
  id: string
  text: string
  done: boolean
}

export interface Note {
  id: string
  title: string
  content: string
  category: NoteCategory
  tags: string[]
  pinned: boolean
  checklist?: NoteChecklistItem[]
  createdAt: string
  updatedAt: string
}

export interface DailyReview {
  id: string
  date: string // YYYY-MM-DD
  productivityRating: number // 1-5
  tasksCompleted: number
  studyMinutes: number
  habitsCompleted: number
  note?: string
  wins?: string
  createdAt: string
}

export type AccentColor =
  | 'indigo'
  | 'blue'
  | 'emerald'
  | 'violet'
  | 'rose'
  | 'amber'

export type ThemeMode = 'light' | 'dark' | 'system'

export interface UserSettings {
  name: string
  email?: string
  major?: string
  onboarded: boolean
  primaryGoals: string[]
  theme: ThemeMode
  accentColor: AccentColor
  dailyStudyGoalMinutes: number
  focusDurationMinutes: number
  breakDurationMinutes: number
  longBreakDurationMinutes: number
  soundEnabled: boolean
  notificationsEnabled: boolean
  reminderTime?: string
  aiApiKey?: string
}

export type NotificationType =
  | 'task'
  | 'study'
  | 'habit'
  | 'goal'
  | 'focus'
  | 'review'

export interface NotificationItem {
  id: string
  title: string
  message: string
  type: NotificationType
  read: boolean
  timestamp: string
  actionUrl?: string
}

export type NavigationTab =
  | 'today'
  | 'calendar'
  | 'tasks'
  | 'study'
  | 'habits'
  | 'goals'
  | 'notes'
  | 'progress'
  | 'ai'
  | 'profile'

export type TaskFilterView = 'today' | 'upcoming' | 'overdue' | 'completed' | 'all'
export type TaskSortOption = 'dueDate' | 'priority' | 'title' | 'createdAt'
