import React, { useState, useEffect } from 'react'
import { Modal } from '@/components/ui/Modal'
import { Input, Textarea } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Goal, Milestone } from '@/types'
import { useGoalStore } from '@/store/useGoalStore'
import { useUIStore } from '@/store/useUIStore'
import { Calendar, Plus, X } from 'lucide-react'
import { addDays, format } from 'date-fns'

export interface GoalModalProps {
  isOpen: boolean
  onClose: () => void
  editingGoal?: Goal | null
}

export function GoalModal({ isOpen, onClose, editingGoal }: GoalModalProps) {
  const { addGoal, updateGoal } = useGoalStore()
  const { showToast } = useUIStore()

  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [deadline, setDeadline] = useState(format(addDays(new Date(), 30), 'yyyy-MM-dd'))
  const [category, setCategory] = useState('Coding')
  const [milestones, setMilestones] = useState<Milestone[]>([])
  const [newMilestoneText, setNewMilestoneText] = useState('')

  useEffect(() => {
    if (editingGoal) {
      setTitle(editingGoal.title)
      setDescription(editingGoal.description || '')
      setDeadline(editingGoal.deadline)
      setCategory(editingGoal.category)
      setMilestones(editingGoal.milestones || [])
    } else {
      setTitle('')
      setDescription('')
      setDeadline(format(addDays(new Date(), 30), 'yyyy-MM-dd'))
      setCategory('Coding')
      setMilestones([
        { id: 'm-1', title: 'Phase 1: Foundations & Planning', completed: false },
        { id: 'm-2', title: 'Phase 2: Core Execution', completed: false },
        { id: 'm-3', title: 'Phase 3: Final Delivery', completed: false },
      ])
    }
  }, [editingGoal, isOpen])

  const handleAddMilestone = () => {
    if (!newMilestoneText.trim()) return
    setMilestones([
      ...milestones,
      {
        id: 'ms_' + Math.random().toString(36).substring(2, 9),
        title: newMilestoneText.trim(),
        completed: false,
      },
    ])
    setNewMilestoneText('')
  }

  const handleRemoveMilestone = (id: string) => {
    setMilestones(milestones.filter((m) => m.id !== id))
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim()) return

    if (editingGoal) {
      await updateGoal(editingGoal.id, {
        title: title.trim(),
        description: description.trim() || undefined,
        deadline,
        category,
        milestones,
      })
      showToast('Goal updated', 'success')
    } else {
      await addGoal({
        title: title.trim(),
        description: description.trim() || undefined,
        deadline,
        category,
        milestones,
      })
      showToast('Goal created 🎯', 'success')
    }
    onClose()
  }

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={editingGoal ? 'Edit Goal' : 'Set a New Goal'}
      maxWidth="md"
    >
      <form onSubmit={handleSave} className="space-y-4">
        <Input
          label="Goal Title *"
          placeholder="e.g. Master Full-Stack Development, Ace Midterms"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          autoFocus
          required
        />

        <div className="grid grid-cols-2 gap-3">
          <Input
            type="date"
            label="Target Deadline"
            icon={<Calendar className="h-4 w-4" />}
            value={deadline}
            onChange={(e) => setDeadline(e.target.value)}
          />

          <div>
            <label className="mb-1.5 block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100"
            >
              <option value="Study">Academic / Study</option>
              <option value="Coding">Coding & Tech</option>
              <option value="Career">Career & Internships</option>
              <option value="Personal">Personal Growth</option>
              <option value="Health">Fitness & Health</option>
            </select>
          </div>
        </div>

        <Textarea
          label="Description / Motivation"
          placeholder="Why is this goal important? What is the expected outcome?"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={2}
        />

        {/* Milestones list */}
        <div>
          <label className="mb-1.5 block text-xs font-semibold text-slate-700 dark:text-slate-300">
            Milestones ({milestones.length})
          </label>
          <div className="space-y-2 mb-2">
            {milestones.map((m) => (
              <div
                key={m.id}
                className="flex items-center justify-between gap-2 rounded-xl bg-slate-50 p-2 text-xs dark:bg-slate-800"
              >
                <span className="text-slate-700 dark:text-slate-300 font-medium">
                  {m.title}
                </span>
                <button
                  type="button"
                  onClick={() => handleRemoveMilestone(m.id)}
                  className="rounded p-1 text-slate-400 hover:text-rose-500"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Add key milestone..."
              value={newMilestoneText}
              onChange={(e) => setNewMilestoneText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault()
                  handleAddMilestone()
                }
              }}
              className="h-9 flex-1 rounded-xl border border-slate-200 bg-white px-3 text-xs placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900"
            />
            <Button type="button" size="sm" variant="secondary" onClick={handleAddMilestone}>
              <Plus className="h-3.5 w-3.5" />
              Add
            </Button>
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <Button type="button" variant="outline" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" size="sm">
            {editingGoal ? 'Save Changes' : 'Create Goal'}
          </Button>
        </div>
      </form>
    </Modal>
  )
}
