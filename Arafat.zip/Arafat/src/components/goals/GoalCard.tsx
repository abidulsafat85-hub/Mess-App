import React, { useState } from 'react'
import { Check, Plus, Calendar, MoreVertical, Edit2, Trash2, ChevronDown, ChevronRight } from 'lucide-react'
import { Goal } from '@/types'
import { useGoalStore } from '@/store/useGoalStore'
import { ProgressBar } from '@/components/ui/ProgressBar'
import { formatFriendlyDate } from '@/utils/date'

export interface GoalCardProps {
  goal: Goal
  onEdit: (goal: Goal) => void
}

export function GoalCard({ goal, onEdit }: GoalCardProps) {
  const [showMilestones, setShowMilestones] = useState(true)
  const [newMilestoneText, setNewMilestoneText] = useState('')
  const [showMenu, setShowMenu] = useState(false)
  const { toggleMilestone, addMilestone, deleteGoal } = useGoalStore()

  const handleAddMilestone = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMilestoneText.trim()) return
    addMilestone(goal.id, newMilestoneText.trim())
    setNewMilestoneText('')
  }

  const completedCount = goal.milestones.filter((m) => m.completed).length

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs transition-all hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-slate-700">
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="rounded-md bg-indigo-50 px-2 py-0.5 text-[10px] font-semibold text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300">
              {goal.category}
            </span>
            <span className="flex items-center gap-1 text-xs text-slate-400">
              <Calendar className="h-3 w-3" />
              Target: {formatFriendlyDate(goal.deadline)}
            </span>
          </div>

          <h3 className="mt-1 text-base font-semibold text-slate-900 dark:text-slate-100">
            {goal.title}
          </h3>

          {goal.description && (
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              {goal.description}
            </p>
          )}
        </div>

        {/* Menu */}
        <div className="relative shrink-0">
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800"
          >
            <MoreVertical className="h-4 w-4" />
          </button>
          {showMenu && (
            <div className="absolute right-0 top-7 z-10 w-28 rounded-xl border border-slate-200 bg-white p-1 shadow-lg dark:border-slate-800 dark:bg-slate-900">
              <button
                onClick={() => {
                  setShowMenu(false)
                  onEdit(goal)
                }}
                className="flex w-full items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                <Edit2 className="h-3.5 w-3.5" />
                Edit
              </button>
              <button
                onClick={() => {
                  setShowMenu(false)
                  deleteGoal(goal.id)
                }}
                className="flex w-full items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs text-rose-600 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950/60"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Delete
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Progress Bar & Percentage */}
      <div className="mt-4">
        <div className="mb-1.5 flex items-center justify-between text-xs">
          <span className="font-semibold text-slate-700 dark:text-slate-300">
            {goal.progress}% Completed
          </span>
          <span className="text-slate-400">
            {completedCount} of {goal.milestones.length} milestones
          </span>
        </div>
        <ProgressBar
          value={goal.progress}
          color={goal.progress === 100 ? 'emerald' : 'indigo'}
          size="sm"
        />
      </div>

      {/* Milestones Accordion */}
      <div className="mt-4 border-t border-slate-100 pt-3 dark:border-slate-800">
        <button
          onClick={() => setShowMilestones(!showMilestones)}
          className="flex items-center gap-1 text-xs font-semibold text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200"
        >
          {showMilestones ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
          Milestones
        </button>

        {showMilestones && (
          <div className="mt-2.5 space-y-2">
            {goal.milestones.map((m) => (
              <div
                key={m.id}
                onClick={() => toggleMilestone(goal.id, m.id)}
                className="flex cursor-pointer items-center gap-2.5 rounded-xl bg-slate-50/70 p-2 text-xs transition-colors hover:bg-slate-100/70 dark:bg-slate-800/40 dark:hover:bg-slate-800/80"
              >
                <div
                  className={`flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors ${
                    m.completed
                      ? 'border-emerald-500 bg-emerald-500 text-white'
                      : 'border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900'
                  }`}
                >
                  {m.completed && <Check className="h-3 w-3 stroke-[3]" />}
                </div>
                <span
                  className={
                    m.completed
                      ? 'line-through text-slate-400 dark:text-slate-500'
                      : 'text-slate-700 dark:text-slate-200 font-medium'
                  }
                >
                  {m.title}
                </span>
              </div>
            ))}

            {/* Quick add milestone form */}
            <form onSubmit={handleAddMilestone} className="flex gap-2 pt-1">
              <input
                type="text"
                placeholder="Add milestone..."
                value={newMilestoneText}
                onChange={(e) => setNewMilestoneText(e.target.value)}
                className="h-8 flex-1 rounded-xl border border-slate-200 bg-white px-3 text-xs placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900"
              />
              <button
                type="submit"
                disabled={!newMilestoneText.trim()}
                className="flex h-8 w-8 items-center justify-center rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 disabled:opacity-40 dark:bg-slate-800 dark:text-slate-300"
              >
                <Plus className="h-4 w-4" />
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  )
}
