import React, { useState } from 'react'
import { Play, MoreVertical, Edit2, Trash2, Clock, BookOpen } from 'lucide-react'
import { StudySubject, StudySession } from '@/types'
import { useStudyStore } from '@/store/useStudyStore'
import { useFocusStore } from '@/store/useFocusStore'
import { useUIStore } from '@/store/useUIStore'
import { ProgressBar } from '@/components/ui/ProgressBar'
import { formatMinutes } from '@/utils/date'

export interface StudyCardProps {
  subject: StudySubject
  weeklyMinutes: number
  totalMinutes: number
  recentSessions: StudySession[]
  onEdit: (subject: StudySubject) => void
}

export function StudyCard({
  subject,
  weeklyMinutes,
  totalMinutes,
  recentSessions,
  onEdit,
}: StudyCardProps) {
  const [showMenu, setShowMenu] = useState(false)
  const { deleteSubject } = useStudyStore()
  const { setSelectedSubject } = useFocusStore()
  const { setFocusModalOpen } = useUIStore()

  const weeklyGoal = subject.goalMinutesWeekly || 300
  const progressPercent = Math.min(100, Math.round((weeklyMinutes / weeklyGoal) * 100))

  const handleLaunchFocus = () => {
    setSelectedSubject(subject.id)
    setFocusModalOpen(true)
  }

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs transition-all hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-slate-700">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-white shadow-2xs"
            style={{ backgroundColor: subject.color }}
          >
            <BookOpen className="h-5 w-5" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              {subject.name}
            </h4>
            {subject.description && (
              <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
                {subject.description}
              </p>
            )}
          </div>
        </div>

        {/* Menu & Focus Button */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleLaunchFocus}
            className="flex items-center gap-1.5 rounded-xl bg-indigo-50 px-2.5 py-1.5 text-xs font-semibold text-indigo-700 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-300"
            title="Start Pomodoro for this subject"
          >
            <Play className="h-3 w-3 fill-current" />
            Focus
          </button>

          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800"
            >
              <MoreVertical className="h-4 w-4" />
            </button>
            {showMenu && (
              <div className="absolute right-0 top-7 z-10 w-28 rounded-xl border border-slate-200 bg-white p-1 shadow-lg dark:border-slate-800 dark:bg-slate-900">
                <button
                  onClick={() => {
                    setShowMenu(false)
                    onEdit(subject)
                  }}
                  className="flex w-full items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  <Edit2 className="h-3.5 w-3.5" />
                  Edit
                </button>
                <button
                  onClick={() => {
                    setShowMenu(false)
                    deleteSubject(subject.id)
                  }}
                  className="flex w-full items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs text-rose-600 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950/60"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Delete
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Weekly Progress Bar */}
      <div className="mt-4">
        <div className="mb-1.5 flex items-center justify-between text-xs">
          <span className="font-semibold text-slate-700 dark:text-slate-300">
            {formatMinutes(weeklyMinutes)} this week
          </span>
          <span className="text-slate-400">
            Goal: {formatMinutes(weeklyGoal)} ({progressPercent}%)
          </span>
        </div>
        <ProgressBar value={progressPercent} color="indigo" size="sm" />
      </div>

      {/* Lifetime / Recent details */}
      <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-3 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
        <span className="flex items-center gap-1">
          <Clock className="h-3.5 w-3.5" />
          Total: {formatMinutes(totalMinutes)}
        </span>
        <span>{recentSessions.length} sessions logged</span>
      </div>
    </div>
  )
}
