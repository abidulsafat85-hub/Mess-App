import React, { useState, useEffect } from 'react'
import { Modal } from '@/components/ui/Modal'
import { Input, Textarea } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { StudySubject } from '@/types'
import { useStudyStore } from '@/store/useStudyStore'
import { useUIStore } from '@/store/useUIStore'

export interface SubjectModalProps {
  isOpen: boolean
  onClose: () => void
  editingSubject?: StudySubject | null
}

const PRESET_COLORS = [
  '#3b82f6', // Blue
  '#8b5cf6', // Violet
  '#10b981', // Emerald
  '#f59e0b', // Amber
  '#ec4899', // Pink
  '#06b6d4', // Cyan
  '#f97316', // Orange
  '#6366f1', // Indigo
]

export function SubjectModal({ isOpen, onClose, editingSubject }: SubjectModalProps) {
  const { addSubject, updateSubject } = useStudyStore()
  const { showToast } = useUIStore()

  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [color, setColor] = useState(PRESET_COLORS[0])
  const [goalMinutesWeekly, setGoalMinutesWeekly] = useState(300)

  useEffect(() => {
    if (editingSubject) {
      setName(editingSubject.name)
      setDescription(editingSubject.description || '')
      setColor(editingSubject.color)
      setGoalMinutesWeekly(editingSubject.goalMinutesWeekly)
    } else {
      setName('')
      setDescription('')
      setColor(PRESET_COLORS[0])
      setGoalMinutesWeekly(300)
    }
  }, [editingSubject, isOpen])

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim()) return

    if (editingSubject) {
      await updateSubject(editingSubject.id, {
        name: name.trim(),
        description: description.trim() || undefined,
        color,
        goalMinutesWeekly: Number(goalMinutesWeekly),
      })
      showToast('Subject updated', 'success')
    } else {
      await addSubject({
        name: name.trim(),
        description: description.trim() || undefined,
        color,
        goalMinutesWeekly: Number(goalMinutesWeekly),
      })
      showToast('Subject created', 'success')
    }
    onClose()
  }

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={editingSubject ? 'Edit Subject' : 'Add Study Subject'}
      maxWidth="sm"
    >
      <form onSubmit={handleSave} className="space-y-4">
        <Input
          label="Subject Name *"
          placeholder="e.g. Distributed Systems, Calculus II"
          value={name}
          onChange={(e) => setName(e.target.value)}
          autoFocus
          required
        />

        <Textarea
          label="Description (Optional)"
          placeholder="Course code, professor, syllabus focus..."
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={2}
        />

        <div>
          <label className="mb-1.5 block text-xs font-semibold text-slate-700 dark:text-slate-300">
            Color Theme
          </label>
          <div className="flex flex-wrap gap-2">
            {PRESET_COLORS.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setColor(c)}
                className={`h-7 w-7 rounded-full transition-transform active:scale-95 ${
                  color === c ? 'ring-2 ring-offset-2 ring-indigo-500 scale-110' : ''
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
        </div>

        <Input
          type="number"
          label="Weekly Study Goal (minutes)"
          placeholder="300 (5 hours)"
          value={goalMinutesWeekly}
          onChange={(e) => setGoalMinutesWeekly(Number(e.target.value))}
          min={30}
          max={2400}
        />

        <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <Button type="button" variant="outline" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" size="sm">
            {editingSubject ? 'Save Changes' : 'Create Subject'}
          </Button>
        </div>
      </form>
    </Modal>
  )
}
