import React, { useState, useEffect } from 'react'
import { Modal } from '@/components/ui/Modal'
import { Input, Textarea } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { useStudyStore } from '@/store/useStudyStore'
import { useTaskStore } from '@/store/useTaskStore'
import { useUIStore } from '@/store/useUIStore'
import { getTodayDateString } from '@/utils/date'
import { Calendar, Clock, BookOpen } from 'lucide-react'

export interface StudySessionModalProps {
  isOpen: boolean
  onClose: () => void
  defaultSubjectId?: string
}

export function StudySessionModal({
  isOpen,
  onClose,
  defaultSubjectId,
}: StudySessionModalProps) {
  const { subjects, addSession } = useStudyStore()
  const { tasks } = useTaskStore()
  const { showToast } = useUIStore()

  const [subjectId, setSubjectId] = useState(defaultSubjectId || '')
  const [topic, setTopic] = useState('')
  const [durationMinutes, setDurationMinutes] = useState<number | ''>(45)
  const [date, setDate] = useState(getTodayDateString())
  const [notes, setNotes] = useState('')
  const [taskId, setTaskId] = useState('')

  useEffect(() => {
    if (defaultSubjectId) {
      setSubjectId(defaultSubjectId)
    } else if (subjects.length > 0 && !subjectId) {
      setSubjectId(subjects[0].id)
    }
  }, [defaultSubjectId, subjects, isOpen])

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!topic.trim() || !durationMinutes || !subjectId) return

    await addSession({
      subjectId,
      topic: topic.trim(),
      durationMinutes: Number(durationMinutes),
      date,
      notes: notes.trim() || undefined,
      taskId: taskId || undefined,
    })

    showToast('Study session logged 🎉', 'success')
    onClose()
  }

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Log Study Session"
      description="Record study time and topics to track your progress"
      maxWidth="md"
    >
      <form onSubmit={handleSave} className="space-y-4">
        {/* Subject */}
        <div>
          <label className="mb-1.5 block text-xs font-semibold text-slate-700 dark:text-slate-300">
            Subject *
          </label>
          <select
            value={subjectId}
            onChange={(e) => setSubjectId(e.target.value)}
            className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100"
            required
          >
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>

        {/* Topic */}
        <Input
          label="Study Topic / Chapter *"
          placeholder="e.g. Dynamic Programming, Graph Theory, Chapter 4"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          autoFocus
          required
        />

        {/* Duration & Date */}
        <div className="grid grid-cols-2 gap-3">
          <Input
            type="number"
            label="Duration (minutes) *"
            icon={<Clock className="h-4 w-4" />}
            value={durationMinutes}
            onChange={(e) => setDurationMinutes(e.target.value ? Number(e.target.value) : '')}
            min={5}
            max={600}
            required
          />
          <Input
            type="date"
            label="Date"
            icon={<Calendar className="h-4 w-4" />}
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
          />
        </div>

        {/* Link to Task (optional) */}
        <div>
          <label className="mb-1.5 block text-xs font-semibold text-slate-700 dark:text-slate-300">
            Linked Task (Optional)
          </label>
          <select
            value={taskId}
            onChange={(e) => setTaskId(e.target.value)}
            className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100"
          >
            <option value="">(None)</option>
            {tasks.map((t) => (
              <option key={t.id} value={t.id}>
                {t.title}
              </option>
            ))}
          </select>
        </div>

        {/* Notes */}
        <Textarea
          label="Session Notes / Key Takeaways"
          placeholder="What did you learn? What formulas or problems were solved?"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={2}
        />

        <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <Button type="button" variant="outline" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" size="sm">
            Save Session
          </Button>
        </div>
      </form>
    </Modal>
  )
}
