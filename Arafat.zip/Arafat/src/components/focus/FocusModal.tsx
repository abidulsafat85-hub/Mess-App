import React, { useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  X,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  SkipForward,
  BookOpen,
  CheckSquare,
  Sparkles,
  Volume2,
  VolumeX,
} from 'lucide-react'
import { useFocusStore } from '@/store/useFocusStore'
import { useTaskStore } from '@/store/useTaskStore'
import { useStudyStore } from '@/store/useStudyStore'
import { useUIStore } from '@/store/useUIStore'
import { Button } from '@/components/ui/Button'

export function FocusModal() {
  const { isFocusModalOpen, setFocusModalOpen } = useUIStore()
  const {
    mode,
    status,
    workMinutes,
    breakMinutes,
    secondsRemaining,
    selectedTaskId,
    selectedSubjectId,
    completedRounds,
    setPreset,
    setSelectedTask,
    setSelectedSubject,
    startTimer,
    pauseTimer,
    resumeTimer,
    resetTimer,
    finishSession,
    skipBreak,
    tick,
  } = useFocusStore()

  const { tasks } = useTaskStore()
  const { subjects } = useStudyStore()

  // Heartbeat interval for timer ticks
  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | null = null
    if (status === 'running') {
      interval = setInterval(() => {
        tick()
      }, 1000)
    }
    return () => {
      if (interval) clearInterval(interval)
    }
  }, [status, tick])

  // ESC shortcut to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isFocusModalOpen) {
        setFocusModalOpen(false)
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [isFocusModalOpen, setFocusModalOpen])

  if (!isFocusModalOpen) return null

  const minutes = Math.floor(secondsRemaining / 60)
  const seconds = secondsRemaining % 60
  const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`

  const totalSeconds = (mode === 'work' ? workMinutes : breakMinutes) * 60
  const progressPercent = Math.max(0, Math.min(100, ((totalSeconds - secondsRemaining) / totalSeconds) * 100))

  const currentTask = tasks.find((t) => t.id === selectedTaskId)
  const currentSubject = subjects.find((s) => s.id === selectedSubjectId)

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Dark Dim Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-md"
          onClick={() => setFocusModalOpen(false)}
        />

        {/* Focus Mode Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 20 }}
          transition={{ type: 'spring', damping: 24, stiffness: 280 }}
          className="relative z-10 flex w-full max-w-lg flex-col items-center rounded-3xl border border-slate-800 bg-slate-900/95 p-6 sm:p-8 text-center text-white shadow-2xl backdrop-blur-xl"
        >
          {/* Close button */}
          <button
            onClick={() => setFocusModalOpen(false)}
            aria-label="Close focus mode"
            className="absolute right-5 top-5 rounded-full p-2 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>

          {/* Mode Pill */}
          <div className="mb-6 flex items-center gap-2 rounded-full bg-slate-800/80 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-indigo-400 border border-slate-700/60">
            <Sparkles className="h-3.5 w-3.5" />
            <span>
              {mode === 'work' ? 'Deep Focus Session' : mode === 'break' ? 'Short Rest Break' : 'Extended Rest Break'}
            </span>
            <span className="text-slate-500">•</span>
            <span className="text-slate-400">Round {completedRounds + 1}</span>
          </div>

          {/* Circular Timer Visual */}
          <div className="relative mb-6 flex h-60 w-60 items-center justify-center">
            <svg className="h-full w-full -rotate-90 transform" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="44"
                stroke="currentColor"
                strokeWidth="4"
                className="text-slate-800"
                fill="transparent"
              />
              <circle
                cx="50"
                cy="50"
                r="44"
                stroke="currentColor"
                strokeWidth="4"
                className={mode === 'work' ? 'text-indigo-500 transition-all duration-1000' : 'text-emerald-500 transition-all duration-1000'}
                fill="transparent"
                strokeDasharray="276.46"
                strokeDashoffset={276.46 - (276.46 * progressPercent) / 100}
                strokeLinecap="round"
              />
            </svg>

            {/* Central Time Display */}
            <div className="absolute flex flex-col items-center justify-center">
              <span className="font-mono text-5xl font-bold tracking-tight sm:text-6xl text-white">
                {formattedTime}
              </span>
              <span className="mt-1 text-xs font-medium text-slate-400">
                {status === 'running' ? 'Focusing...' : status === 'paused' ? 'Paused' : 'Ready'}
              </span>
            </div>
          </div>

          {/* Current Task / Subject Selector */}
          <div className="mb-6 w-full max-w-sm rounded-2xl border border-slate-800 bg-slate-800/40 p-3.5 text-left">
            <div className="mb-2 flex items-center justify-between text-xs text-slate-400">
              <span className="flex items-center gap-1.5 font-medium">
                <CheckSquare className="h-3.5 w-3.5 text-indigo-400" />
                Target Task:
              </span>
              <select
                value={selectedTaskId || ''}
                onChange={(e) => setSelectedTask(e.target.value || null)}
                className="rounded bg-slate-800 px-2 py-0.5 text-xs text-slate-200 outline-none max-w-[180px] truncate"
              >
                <option value="">(Select task to focus on)</option>
                {tasks
                  .filter((t) => !t.completed)
                  .map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.title}
                    </option>
                  ))}
              </select>
            </div>

            {currentTask ? (
              <p className="text-xs font-semibold text-white truncate">
                {currentTask.title}
              </p>
            ) : (
              <p className="text-xs italic text-slate-500">
                General deep study & productivity
              </p>
            )}

            {/* Subject Selector */}
            <div className="mt-3 flex items-center justify-between text-xs text-slate-400 border-t border-slate-800/80 pt-2.5">
              <span className="flex items-center gap-1.5 font-medium">
                <BookOpen className="h-3.5 w-3.5 text-indigo-400" />
                Subject:
              </span>
              <select
                value={selectedSubjectId || ''}
                onChange={(e) => setSelectedSubject(e.target.value || null)}
                className="rounded bg-slate-800 px-2 py-0.5 text-xs text-slate-200 outline-none max-w-[180px] truncate"
              >
                <option value="">(Auto-assign subject)</option>
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Controls: Start / Pause / Resume / Finish / Skip */}
          <div className="mb-6 flex flex-wrap items-center justify-center gap-3">
            {status === 'idle' && (
              <Button
                size="lg"
                onClick={startTimer}
                className="px-8 bg-indigo-600 hover:bg-indigo-500 font-semibold"
              >
                <Play className="h-4 w-4 fill-current mr-1" />
                Start Focus
              </Button>
            )}

            {status === 'running' && (
              <>
                <Button size="lg" variant="secondary" onClick={pauseTimer}>
                  <Pause className="h-4 w-4 fill-current mr-1" />
                  Pause
                </Button>
                <Button size="lg" variant="subtle" onClick={() => finishSession(true)}>
                  <CheckCircle2 className="h-4 w-4 mr-1 text-emerald-400" />
                  Finish Session
                </Button>
              </>
            )}

            {status === 'paused' && (
              <>
                <Button size="lg" onClick={resumeTimer}>
                  <Play className="h-4 w-4 fill-current mr-1" />
                  Resume
                </Button>
                <Button size="lg" variant="outline" onClick={resetTimer}>
                  <RotateCcw className="h-4 w-4 mr-1" />
                  Reset
                </Button>
                <Button size="lg" variant="subtle" onClick={() => finishSession(true)}>
                  <CheckCircle2 className="h-4 w-4 mr-1 text-emerald-400" />
                  Finish
                </Button>
              </>
            )}

            {mode !== 'work' && (
              <Button size="lg" variant="ghost" onClick={skipBreak}>
                <SkipForward className="h-4 w-4 mr-1" />
                Skip Break
              </Button>
            )}
          </div>

          {/* Presets (25/5, 50/10, Custom) */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500">Presets:</span>
            <button
              onClick={() => setPreset(25, 5)}
              className={`rounded-lg px-2.5 py-1 font-medium transition-colors ${
                workMinutes === 25
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              25 / 5
            </button>
            <button
              onClick={() => setPreset(50, 10)}
              className={`rounded-lg px-2.5 py-1 font-medium transition-colors ${
                workMinutes === 50
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              50 / 10
            </button>
            <button
              onClick={() => setPreset(90, 15)}
              className={`rounded-lg px-2.5 py-1 font-medium transition-colors ${
                workMinutes === 90
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              90 / 15
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  )
}
