import React, { useState } from 'react'
import { Modal } from '@/components/ui/Modal'
import { Button } from '@/components/ui/Button'
import { Textarea } from '@/components/ui/Input'
import { Star, CheckSquare, BookOpen, Flame, Sparkles } from 'lucide-react'
import { useTaskStore } from '@/store/useTaskStore'
import { useStudyStore } from '@/store/useStudyStore'
import { useHabitStore } from '@/store/useHabitStore'
import { useFocusStore } from '@/store/useFocusStore'
import { useReviewStore } from '@/store/useReviewStore'
import { useUIStore } from '@/store/useUIStore'
import { getTodayDateString, formatMinutes } from '@/utils/date'

export function DailyReviewModal() {
  const { isDailyReviewOpen, setDailyReviewOpen, showToast } = useUIStore()
  const { tasks } = useTaskStore()
  const { getTodayMinutes } = useStudyStore()
  const { getTodayHabitsProgress } = useHabitStore()
  const { completedRounds } = useFocusStore()
  const { submitReview, getTodayReview } = useReviewStore()

  const todayStr = getTodayDateString()
  const existingReview = getTodayReview()

  const todayTasks = tasks.filter((t) => t.dueDate === todayStr)
  const tasksCompleted = todayTasks.filter((t) => t.completed).length
  const totalTasks = todayTasks.length
  const studyMins = getTodayMinutes()
  const habitsProgress = getTodayHabitsProgress()

  const [rating, setRating] = useState<number>(existingReview?.productivityRating || 4)
  const [wins, setWins] = useState<string>(existingReview?.wins || '')
  const [notes, setNotes] = useState<string>(existingReview?.note || '')

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()

    await submitReview({
      date: todayStr,
      productivityRating: rating,
      tasksCompleted,
      studyMinutes: studyMins,
      habitsCompleted: habitsProgress.completed,
      wins: wins.trim() || undefined,
      note: notes.trim() || undefined,
    })

    showToast('Daily review completed ✨ Keep building momentum!', 'success')
    setDailyReviewOpen(false)
  }

  return (
    <Modal
      isOpen={isDailyReviewOpen}
      onClose={() => setDailyReviewOpen(false)}
      title="Daily Review & Reflection"
      description="Calibrate your progress, celebrate wins, and wrap up today"
      maxWidth="md"
    >
      <form onSubmit={handleSave} className="space-y-4">
        {/* Today's Snapshot Metrics */}
        <div className="grid grid-cols-2 gap-3 rounded-2xl bg-slate-50 p-3.5 dark:bg-slate-800/60 sm:grid-cols-4">
          <div className="flex flex-col items-center justify-center p-1 text-center">
            <CheckSquare className="h-4 w-4 text-emerald-500 mb-1" />
            <span className="text-sm font-bold text-slate-800 dark:text-slate-100">
              {tasksCompleted} / {totalTasks}
            </span>
            <span className="text-[10px] text-slate-400">Tasks</span>
          </div>

          <div className="flex flex-col items-center justify-center p-1 text-center">
            <BookOpen className="h-4 w-4 text-blue-500 mb-1" />
            <span className="text-sm font-bold text-slate-800 dark:text-slate-100">
              {formatMinutes(studyMins)}
            </span>
            <span className="text-[10px] text-slate-400">Study Time</span>
          </div>

          <div className="flex flex-col items-center justify-center p-1 text-center">
            <Flame className="h-4 w-4 text-amber-500 mb-1" />
            <span className="text-sm font-bold text-slate-800 dark:text-slate-100">
              {habitsProgress.completed} / {habitsProgress.total}
            </span>
            <span className="text-[10px] text-slate-400">Habits</span>
          </div>

          <div className="flex flex-col items-center justify-center p-1 text-center">
            <Sparkles className="h-4 w-4 text-indigo-500 mb-1" />
            <span className="text-sm font-bold text-slate-800 dark:text-slate-100">
              {completedRounds}
            </span>
            <span className="text-[10px] text-slate-400">Focus Rounds</span>
          </div>
        </div>

        {/* Productivity Rating (1-5) */}
        <div>
          <label className="mb-2 block text-xs font-semibold text-slate-700 dark:text-slate-300">
            How productive did you feel today?
          </label>
          <div className="flex items-center justify-center gap-3 py-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                className="group flex flex-col items-center gap-1 transition-transform active:scale-95"
              >
                <Star
                  className={`h-7 w-7 transition-colors ${
                    star <= rating
                      ? 'fill-amber-400 text-amber-400'
                      : 'text-slate-300 dark:text-slate-600 group-hover:text-amber-300'
                  }`}
                />
                <span className="text-[10px] text-slate-400 font-medium">
                  {star === 1 ? 'Rough' : star === 3 ? 'Good' : star === 5 ? 'Elite' : star}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Wins / Highlights */}
        <Textarea
          label="What went well today? (Wins & Breakthroughs)"
          placeholder="e.g. Mastered recursion proofs, worked uninterrupted for 2 hours..."
          value={wins}
          onChange={(e) => setWins(e.target.value)}
          rows={2}
        />

        {/* Reflection / Calibration */}
        <Textarea
          label="What could be improved tomorrow?"
          placeholder="e.g. Start earlier, avoid checking phone during study sessions..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={2}
        />

        <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setDailyReviewOpen(false)}
          >
            Cancel
          </Button>
          <Button type="submit" size="sm">
            Save Reflection
          </Button>
        </div>
      </form>
    </Modal>
  )
}
