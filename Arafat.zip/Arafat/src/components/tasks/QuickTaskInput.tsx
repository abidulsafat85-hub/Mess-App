import React, { useState } from 'react'
import { Plus, Sparkles, CornerDownLeft, Calendar, Clock, Tag } from 'lucide-react'
import { useTaskStore } from '@/store/useTaskStore'
import { useUIStore } from '@/store/useUIStore'
import { parseNaturalLanguageTask } from '@/utils/nlp'
import { formatFriendlyDate } from '@/utils/date'

export function QuickTaskInput() {
  const [input, setInput] = useState('')
  const [isFocused, setIsFocused] = useState(false)
  const { addTask } = useTaskStore()
  const { showToast } = useUIStore()

  const parsed = input.trim() ? parseNaturalLanguageTask(input) : null

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    const parsedData = parseNaturalLanguageTask(input)
    await addTask({
      title: parsedData.title,
      completed: false,
      priority: parsedData.priority,
      category: parsedData.category,
      tags: [],
      dueDate: parsedData.dueDate,
      dueTime: parsedData.dueTime,
      repeat: 'none',
      estimatedMinutes: parsedData.estimatedMinutes,
      subtasks: [],
    })

    showToast('Task added ✓', 'success')
    setInput('')
  }

  return (
    <form onSubmit={handleSubmit} className="relative w-full">
      <div
        className={`relative flex items-center rounded-2xl border bg-white transition-all shadow-xs dark:bg-slate-900 ${
          isFocused
            ? 'border-indigo-500 ring-2 ring-indigo-500/15 dark:border-indigo-500'
            : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
        }`}
      >
        <div className="pl-4 text-slate-400">
          <Plus className="h-4 w-4" />
        </div>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setTimeout(() => setIsFocused(false), 200)}
          placeholder="Add a task... try 'Review Chemistry tomorrow at 4 PM #Study !high'"
          className="h-12 w-full bg-transparent px-3 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none dark:text-slate-100 dark:placeholder:text-slate-500"
        />
        <button
          type="submit"
          disabled={!input.trim()}
          className="mr-2.5 flex h-7 w-7 items-center justify-center rounded-xl bg-indigo-600 text-white transition-all disabled:opacity-30 disabled:pointer-events-none hover:bg-indigo-700 active:scale-95"
        >
          <CornerDownLeft className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* Real-time NLP intelligent parse preview pill */}
      {isFocused && parsed && (
        <div className="absolute top-14 left-0 right-0 z-10 flex flex-wrap items-center gap-2 rounded-xl border border-indigo-100 bg-indigo-50/90 p-2 text-xs backdrop-blur-md dark:border-indigo-900/50 dark:bg-indigo-950/80">
          <span className="flex items-center gap-1 font-semibold text-indigo-700 dark:text-indigo-300">
            <Sparkles className="h-3.5 w-3.5" />
            AI Parsing:
          </span>
          <span className="rounded bg-white/80 px-1.5 py-0.5 text-slate-700 dark:bg-slate-900/80 dark:text-slate-200 font-medium">
            "{parsed.title}"
          </span>
          <span className="flex items-center gap-1 rounded bg-white/80 px-1.5 py-0.5 text-slate-700 dark:bg-slate-900/80 dark:text-slate-200">
            <Calendar className="h-3 w-3 text-indigo-500" />
            {formatFriendlyDate(parsed.dueDate)}
          </span>
          {parsed.dueTime && (
            <span className="flex items-center gap-1 rounded bg-white/80 px-1.5 py-0.5 text-slate-700 dark:bg-slate-900/80 dark:text-slate-200">
              <Clock className="h-3 w-3 text-indigo-500" />
              {parsed.dueTime}
            </span>
          )}
          <span className="flex items-center gap-1 rounded bg-white/80 px-1.5 py-0.5 text-slate-700 dark:bg-slate-900/80 dark:text-slate-200">
            <Tag className="h-3 w-3 text-indigo-500" />
            {parsed.category} • {parsed.priority}
          </span>
        </div>
      )}
    </form>
  )
}
