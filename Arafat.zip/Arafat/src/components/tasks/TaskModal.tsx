import React, { useState, useEffect } from 'react'
import { Modal } from '@/components/ui/Modal'
import { Input, Textarea } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Priority, TaskCategory, RepeatInterval, Subtask } from '@/types'
import { useTaskStore } from '@/store/useTaskStore'
import { useFocusStore } from '@/store/useFocusStore'
import { useUIStore } from '@/store/useUIStore'
import { getTodayDateString } from '@/utils/date'
import {
  Calendar,
  Clock,
  Tag,
  CheckSquare,
  Play,
  Trash2,
  Plus,
  X,
  Bell,
  Repeat,
} from 'lucide-react'

export function TaskModal() {
  const { isTaskModalOpen, closeTaskModal, editingTaskId, showToast, setFocusModalOpen } = useUIStore()
  const { tasks, addTask, updateTask, deleteTask } = useTaskStore()
  const { setSelectedTask } = useFocusStore()

  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [dueDate, setDueDate] = useState(getTodayDateString())
  const [dueTime, setDueTime] = useState('')
  const [priority, setPriority] = useState<Priority>('medium')
  const [category, setCategory] = useState<TaskCategory>('Study')
  const [estimatedMinutes, setEstimatedMinutes] = useState<number | ''>(30)
  const [repeat, setRepeat] = useState<RepeatInterval>('none')
  const [reminder, setReminder] = useState(false)
  const [notes, setNotes] = useState('')
  const [tagsInput, setTagsInput] = useState('')
  const [subtasks, setSubtasks] = useState<Subtask[]>([])
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('')
  const [isMoreOptionsOpen, setIsMoreOptionsOpen] = useState(false)

  const editingTask = editingTaskId ? tasks.find((t) => t.id === editingTaskId) : null

  useEffect(() => {
    if (editingTask) {
      setTitle(editingTask.title)
      setDescription(editingTask.description || '')
      setDueDate(editingTask.dueDate)
      setDueTime(editingTask.dueTime || '')
      setPriority(editingTask.priority)
      setCategory(editingTask.category)
      setEstimatedMinutes(editingTask.estimatedMinutes || '')
      setRepeat(editingTask.repeat || 'none')
      setReminder(!!editingTask.reminder)
      setNotes(editingTask.notes || '')
      setTagsInput(editingTask.tags.join(', '))
      setSubtasks(editingTask.subtasks || [])
      setIsMoreOptionsOpen(true)
    } else {
      setTitle('')
      setDescription('')
      setDueDate(getTodayDateString())
      setDueTime('')
      setPriority('medium')
      setCategory('Study')
      setEstimatedMinutes(30)
      setRepeat('none')
      setReminder(false)
      setNotes('')
      setTagsInput('')
      setSubtasks([])
      setIsMoreOptionsOpen(false)
    }
  }, [editingTask, isTaskModalOpen])

  const handleAddSubtask = () => {
    if (!newSubtaskTitle.trim()) return
    setSubtasks([
      ...subtasks,
      {
        id: 'st_' + Math.random().toString(36).substring(2, 9),
        title: newSubtaskTitle.trim(),
        completed: false,
      },
    ])
    setNewSubtaskTitle('')
  }

  const handleRemoveSubtask = (id: string) => {
    setSubtasks(subtasks.filter((s) => s.id !== id))
  }

  const handleToggleSubtask = (id: string) => {
    setSubtasks(
      subtasks.map((s) => (s.id === id ? { ...s, completed: !s.completed } : s))
    )
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim()) return

    const tags = tagsInput
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean)

    if (editingTask) {
      await updateTask(editingTask.id, {
        title: title.trim(),
        description: description.trim() || undefined,
        dueDate,
        dueTime: dueTime || undefined,
        priority,
        category,
        estimatedMinutes: estimatedMinutes ? Number(estimatedMinutes) : undefined,
        repeat,
        reminder,
        notes: notes.trim() || undefined,
        tags,
        subtasks,
      })
      showToast('Task updated', 'success')
    } else {
      await addTask({
        title: title.trim(),
        description: description.trim() || undefined,
        completed: false,
        priority,
        category,
        tags,
        dueDate,
        dueTime: dueTime || undefined,
        reminder,
        repeat,
        estimatedMinutes: estimatedMinutes ? Number(estimatedMinutes) : undefined,
        subtasks,
        notes: notes.trim() || undefined,
      })
      showToast('Task created', 'success')
    }
    closeTaskModal()
  }

  const handleDelete = async () => {
    if (editingTask) {
      await deleteTask(editingTask.id)
      showToast('Task deleted', 'info')
      closeTaskModal()
    }
  }

  const handleStartFocus = () => {
    if (editingTask) {
      setSelectedTask(editingTask.id)
      closeTaskModal()
      setFocusModalOpen(true)
    }
  }

  return (
    <Modal
      isOpen={isTaskModalOpen}
      onClose={closeTaskModal}
      title={editingTask ? 'Task Details' : 'Create Task'}
      maxWidth="lg"
    >
      <form onSubmit={handleSave} className="space-y-4">
        {/* Title */}
        <Input
          label="Task Title *"
          placeholder="e.g. Complete MAT102 Assignment"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          autoFocus
          required
        />

        {/* Due Date & Time */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Input
            type="date"
            label="Due Date"
            icon={<Calendar className="h-4 w-4" />}
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
          />
          <Input
            type="time"
            label="Due Time (Optional)"
            icon={<Clock className="h-4 w-4" />}
            value={dueTime}
            onChange={(e) => setDueTime(e.target.value)}
          />
        </div>

        {/* Priority & Category */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Priority
            </label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as Priority)}
              className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100"
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
              <option value="urgent">Urgent</option>
            </select>
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as TaskCategory)}
              className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100"
            >
              <option value="Study">Study</option>
              <option value="Coding">Coding</option>
              <option value="Personal">Personal</option>
              <option value="Health">Health</option>
              <option value="Finance">Finance</option>
              <option value="Other">Other</option>
            </select>
          </div>
        </div>

        {/* Toggle more options if creating */}
        {!isMoreOptionsOpen && (
          <button
            type="button"
            onClick={() => setIsMoreOptionsOpen(true)}
            className="text-xs font-medium text-indigo-600 hover:underline dark:text-indigo-400"
          >
            + More options (subtasks, duration, notes, tags)
          </button>
        )}

        {isMoreOptionsOpen && (
          <div className="space-y-4 pt-2 border-t border-slate-100 dark:border-slate-800">
            {/* Description */}
            <Textarea
              label="Description"
              placeholder="Add key context, requirements, or links..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
            />

            {/* Estimated Duration & Repeat */}
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Input
                type="number"
                label="Estimated Duration (minutes)"
                placeholder="30"
                value={estimatedMinutes}
                onChange={(e) => setEstimatedMinutes(e.target.value ? Number(e.target.value) : '')}
                min={5}
                max={480}
              />
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Repeat
                </label>
                <select
                  value={repeat}
                  onChange={(e) => setRepeat(e.target.value as RepeatInterval)}
                  className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100"
                >
                  <option value="none">Does not repeat</option>
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                </select>
              </div>
            </div>

            {/* Subtasks Builder */}
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Subtasks ({subtasks.filter((s) => s.completed).length}/{subtasks.length})
              </label>
              <div className="space-y-1.5 mb-2">
                {subtasks.map((st) => (
                  <div
                    key={st.id}
                    className="flex items-center justify-between gap-2 rounded-xl border border-slate-100 bg-slate-50/50 p-2 dark:border-slate-800 dark:bg-slate-800/40"
                  >
                    <div
                      onClick={() => handleToggleSubtask(st.id)}
                      className="flex flex-1 cursor-pointer items-center gap-2"
                    >
                      <input
                        type="checkbox"
                        checked={st.completed}
                        onChange={() => {}}
                        className="rounded text-indigo-600 pointer-events-none"
                      />
                      <span
                        className={`text-xs ${
                          st.completed ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-200'
                        }`}
                      >
                        {st.title}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveSubtask(st.id)}
                      className="rounded p-1 text-slate-400 hover:text-rose-500"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Add a subtask step..."
                  value={newSubtaskTitle}
                  onChange={(e) => setNewSubtaskTitle(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault()
                      handleAddSubtask()
                    }
                  }}
                  className="h-9 flex-1 rounded-xl border border-slate-200 bg-white px-3 text-xs placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900"
                />
                <Button type="button" size="sm" variant="secondary" onClick={handleAddSubtask}>
                  <Plus className="h-3.5 w-3.5" />
                  Add
                </Button>
              </div>
            </div>

            {/* Tags */}
            <Input
              label="Tags (comma-separated)"
              icon={<Tag className="h-4 w-4" />}
              placeholder="e.g. Math, Homework, Midterm"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
            />

            {/* Notes */}
            <Textarea
              label="Additional Notes / References"
              placeholder="Formulas, hints, textbook page numbers..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
            />

            {/* Reminder Toggle */}
            <label className="flex cursor-pointer items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={reminder}
                onChange={(e) => setReminder(e.target.checked)}
                className="rounded text-indigo-600"
              />
              <Bell className="h-3.5 w-3.5 text-slate-400" />
              Set reminder notification
            </label>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            {editingTask && (
              <>
                <Button
                  type="button"
                  variant="danger"
                  size="sm"
                  onClick={handleDelete}
                  title="Delete task"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
                <Button
                  type="button"
                  variant="subtle"
                  size="sm"
                  onClick={handleStartFocus}
                  title="Launch Pomodoro Focus"
                >
                  <Play className="h-3.5 w-3.5 fill-current" />
                  Focus
                </Button>
              </>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Button type="button" variant="outline" size="sm" onClick={closeTaskModal}>
              Cancel
            </Button>
            <Button type="submit" size="sm">
              {editingTask ? 'Save Changes' : 'Create Task'}
            </Button>
          </div>
        </div>
      </form>
    </Modal>
  )
}
