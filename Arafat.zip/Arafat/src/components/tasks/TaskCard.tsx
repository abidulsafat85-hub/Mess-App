import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Calendar,
  Clock,
  MoreVertical,
  Play,
  Trash2,
  Edit2,
  ChevronDown,
  ChevronRight,
  Check,
  CheckCircle2,
} from 'lucide-react'
import { Task } from '@/types'
import { useTaskStore } from '@/store/useTaskStore'
import { useFocusStore } from '@/store/useFocusStore'
import { useUIStore } from '@/store/useUIStore'
import { PriorityBadge, CategoryBadge } from '@/components/ui/Badge'
import { formatFriendlyDate, isTaskOverdue, isTaskToday } from '@/utils/date'
import { cn } from '@/utils/cn'

export interface TaskCardProps {
  task: Task
}

export function TaskCard({ task }: TaskCardProps) {
  const [showSubtasks, setShowSubtasks] = useState(false)
  const [showMenu, setShowMenu] = useState(false)
  const { toggleTask, toggleSubtask, deleteTask } = useTaskStore()
  const { setSelectedTask } = useFocusStore()
  const { openTaskModal, setFocusModalOpen } = useUIStore()

  const isOverdue = isTaskOverdue(task.dueDate, task.completed)
  const isDueToday = isTaskToday(task.dueDate)

  const handleStartFocus = (e: React.MouseEvent) => {
    e.stopPropagation()
    setSelectedTask(task.id)
    setFocusModalOpen(true)
  }

  const handleEdit = (e: React.MouseEvent) => {
    e.stopPropagation()
    setShowMenu(false)
    openTaskModal(task.id)
  }

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation()
    setShowMenu(false)
    deleteTask(task.id)
  }

  const totalSubtasks = task.subtasks.length
  const completedSubtasks = task.subtasks.filter((s) => s.completed).length

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.2 }}
      className={cn(
        'group relative rounded-2xl border bg-white p-4 transition-all duration-200 hover:shadow-sm dark:bg-slate-900',
        task.completed
          ? 'border-slate-200/60 bg-slate-50/50 opacity-70 dark:border-slate-800/60 dark:bg-slate-900/30'
          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
      )}
    >
      <div className="flex items-start gap-3.5">
        {/* Animated Checkbox */}
        <button
          onClick={() => toggleTask(task.id)}
          aria-label={task.completed ? 'Mark task incomplete' : 'Complete task'}
          className={cn(
            'mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-lg border transition-all active:scale-90',
            task.completed
              ? 'border-emerald-500 bg-emerald-500 text-white'
              : 'border-slate-300 bg-white hover:border-indigo-500 dark:border-slate-700 dark:bg-slate-800'
          )}
        >
          {task.completed && (
            <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring' }}>
              <Check className="h-3.5 w-3.5 stroke-[3]" />
            </motion.div>
          )}
        </button>

        {/* Task Content */}
        <div className="flex-1 min-w-0" onClick={() => openTaskModal(task.id)}>
          <div className="flex items-start justify-between gap-2">
            <span
              className={cn(
                'text-sm font-semibold transition-all cursor-pointer',
                task.completed
                  ? 'text-slate-400 line-through dark:text-slate-500'
                  : 'text-slate-800 dark:text-slate-100'
              )}
            >
              {task.title}
            </span>

            {/* Menu trigger */}
            <div className="relative shrink-0" onClick={(e) => e.stopPropagation()}>
              <button
                onClick={() => setShowMenu(!showMenu)}
                aria-label="Task options"
                className="opacity-0 group-hover:opacity-100 rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 transition-opacity"
              >
                <MoreVertical className="h-4 w-4" />
              </button>

              {showMenu && (
                <div className="absolute right-0 top-6 z-20 w-32 rounded-xl border border-slate-200 bg-white p-1.5 shadow-lg dark:border-slate-800 dark:bg-slate-900">
                  <button
                    onClick={handleEdit}
                    className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
                  >
                    <Edit2 className="h-3.5 w-3.5" />
                    Edit
                  </button>
                  <button
                    onClick={handleStartFocus}
                    className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-xs text-indigo-600 hover:bg-indigo-50 dark:text-indigo-400 dark:hover:bg-indigo-950/60"
                  >
                    <Play className="h-3.5 w-3.5" />
                    Focus
                  </button>
                  <button
                    onClick={handleDelete}
                    className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-xs text-rose-600 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950/60"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Delete
                  </button>
                </div>
              )}
            </div>
          </div>

          {task.description && (
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
              {task.description}
            </p>
          )}

          {/* Badges & Meta info */}
          <div className="mt-2.5 flex flex-wrap items-center gap-2 text-xs">
            <PriorityBadge priority={task.priority} />
            <CategoryBadge category={task.category} />

            {/* Due Date Indicator */}
            <span
              className={cn(
                'inline-flex items-center gap-1 rounded-md px-2 py-0.5 font-medium',
                isOverdue
                  ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-400 font-semibold'
                  : isDueToday
                  ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-400'
                  : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
              )}
            >
              <Calendar className="h-3 w-3" />
              {formatFriendlyDate(task.dueDate)}
              {task.dueTime ? ` • ${task.dueTime}` : ''}
            </span>

            {/* Estimated Duration */}
            {task.estimatedMinutes ? (
              <span className="inline-flex items-center gap-1 text-slate-400 dark:text-slate-500">
                <Clock className="h-3 w-3" />
                {task.estimatedMinutes}m
              </span>
            ) : null}

            {/* Subtask indicator button */}
            {totalSubtasks > 0 && (
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  setShowSubtasks(!showSubtasks)
                }}
                className="inline-flex items-center gap-1 rounded-md bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
              >
                {showSubtasks ? (
                  <ChevronDown className="h-3 w-3" />
                ) : (
                  <ChevronRight className="h-3 w-3" />
                )}
                {completedSubtasks}/{totalSubtasks} subtasks
              </button>
            )}

            {/* Quick focus trigger when hover */}
            {!task.completed && (
              <button
                onClick={handleStartFocus}
                className="ml-auto opacity-0 group-hover:opacity-100 hidden sm:inline-flex items-center gap-1 rounded-lg bg-indigo-50 px-2.5 py-1 text-xs font-semibold text-indigo-600 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-300 transition-opacity"
              >
                <Play className="h-3 w-3 fill-current" />
                Focus
              </button>
            )}
          </div>

          {/* Subtasks checklist accordion */}
          <AnimatePresence>
            {showSubtasks && totalSubtasks > 0 && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-3 space-y-1.5 border-t border-slate-100 pt-2.5 dark:border-slate-800/80"
                onClick={(e) => e.stopPropagation()}
              >
                {task.subtasks.map((st) => (
                  <div
                    key={st.id}
                    onClick={() => toggleSubtask(task.id, st.id)}
                    className="flex cursor-pointer items-center gap-2 rounded-lg py-1 px-1.5 hover:bg-slate-50 dark:hover:bg-slate-800/40"
                  >
                    <div
                      className={cn(
                        'flex h-3.5 w-3.5 items-center justify-center rounded border transition-colors',
                        st.completed
                          ? 'border-emerald-500 bg-emerald-500 text-white'
                          : 'border-slate-300 dark:border-slate-600'
                      )}
                    >
                      {st.completed && <Check className="h-2.5 w-2.5 stroke-[3]" />}
                    </div>
                    <span
                      className={cn(
                        'text-xs',
                        st.completed
                          ? 'text-slate-400 line-through dark:text-slate-500'
                          : 'text-slate-700 dark:text-slate-300'
                      )}
                    >
                      {st.title}
                    </span>
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  )
}
