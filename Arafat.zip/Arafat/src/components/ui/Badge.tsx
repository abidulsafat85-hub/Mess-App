import React from 'react'
import { cn } from '@/utils/cn'
import { Priority, TaskCategory } from '@/types'

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: 'default' | 'outline' | 'subtle'
  color?: 'slate' | 'indigo' | 'emerald' | 'amber' | 'rose' | 'purple' | 'blue'
}

export function Badge({
  className,
  variant = 'subtle',
  color = 'slate',
  children,
  ...props
}: BadgeProps) {
  const colorMap = {
    slate: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
    indigo: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300',
    emerald: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300',
    amber: 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300',
    rose: 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300',
    purple: 'bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300',
    blue: 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300',
  }

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-medium tracking-wide',
        colorMap[color],
        className
      )}
      {...props}
    >
      {children}
    </span>
  )
}

export function PriorityBadge({ priority }: { priority: Priority }) {
  switch (priority) {
    case 'urgent':
      return (
        <span className="inline-flex items-center gap-1 rounded-md bg-rose-50 px-2 py-0.5 text-xs font-semibold text-rose-700 dark:bg-rose-950/60 dark:text-rose-300">
          <span className="h-1.5 w-1.5 rounded-full bg-rose-500 animate-pulse" />
          Urgent
        </span>
      )
    case 'high':
      return (
        <span className="inline-flex items-center gap-1 rounded-md bg-amber-50 px-2 py-0.5 text-xs font-medium text-amber-700 dark:bg-amber-950/60 dark:text-amber-300">
          <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
          High
        </span>
      )
    case 'medium':
      return (
        <span className="inline-flex items-center gap-1 rounded-md bg-blue-50 px-2 py-0.5 text-xs font-medium text-blue-700 dark:bg-blue-950/60 dark:text-blue-300">
          <span className="h-1.5 w-1.5 rounded-full bg-blue-500" />
          Medium
        </span>
      )
    case 'low':
      return (
        <span className="inline-flex items-center gap-1 rounded-md bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-600 dark:bg-slate-800 dark:text-slate-400">
          <span className="h-1.5 w-1.5 rounded-full bg-slate-400" />
          Low
        </span>
      )
  }
}

export function CategoryBadge({ category }: { category: TaskCategory | string }) {
  const cat = category.toLowerCase()
  let colorClass = 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'

  if (cat.includes('study')) {
    colorClass = 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300'
  } else if (cat.includes('code') || cat.includes('coding')) {
    colorClass = 'bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300'
  } else if (cat.includes('health')) {
    colorClass = 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300'
  } else if (cat.includes('finance')) {
    colorClass = 'bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300'
  } else if (cat.includes('personal')) {
    colorClass = 'bg-purple-50 text-purple-700 dark:bg-purple-950/50 dark:text-purple-300'
  }

  return (
    <span className={cn('inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium', colorClass)}>
      {category}
    </span>
  )
}
