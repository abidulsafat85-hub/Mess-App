import { cn } from '@/utils/cn'

export interface ProgressBarProps {
  value: number // 0 - 100
  color?: 'indigo' | 'emerald' | 'amber' | 'rose' | 'blue'
  size?: 'xs' | 'sm' | 'md'
  className?: string
  showLabel?: boolean
}

export function ProgressBar({
  value,
  color = 'indigo',
  size = 'sm',
  className,
  showLabel = false,
}: ProgressBarProps) {
  const clamped = Math.min(100, Math.max(0, value))

  const heightMap = {
    xs: 'h-1.5',
    sm: 'h-2',
    md: 'h-3',
  }

  const colorMap = {
    indigo: 'bg-indigo-600 dark:bg-indigo-500',
    emerald: 'bg-emerald-500 dark:bg-emerald-400',
    amber: 'bg-amber-500 dark:bg-amber-400',
    rose: 'bg-rose-500 dark:bg-rose-400',
    blue: 'bg-blue-600 dark:bg-blue-500',
  }

  return (
    <div className={cn('w-full', className)}>
      <div className={cn('w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800', heightMap[size])}>
        <div
          className={cn('h-full transition-all duration-500 ease-out rounded-full', colorMap[color])}
          style={{ width: `${clamped}%` }}
        />
      </div>
      {showLabel ? (
        <div className="mt-1 flex justify-between text-xs text-slate-500">
          <span>{clamped}%</span>
        </div>
      ) : null}
    </div>
  )
}
