import React, { useState } from 'react'
import { Pin, MoreVertical, Edit2, Trash2, Tag, CheckSquare } from 'lucide-react'
import { Note } from '@/types'
import { useNoteStore } from '@/store/useNoteStore'
import { formatFriendlyDate } from '@/utils/date'

export interface NoteCardProps {
  note: Note
  onEdit: (note: Note) => void
}

export function NoteCard({ note, onEdit }: NoteCardProps) {
  const [showMenu, setShowMenu] = useState(false)
  const { togglePin, deleteNote } = useNoteStore()

  const completedChecklist = note.checklist ? note.checklist.filter((c) => c.done).length : 0
  const totalChecklist = note.checklist ? note.checklist.length : 0

  return (
    <div
      onClick={() => onEdit(note)}
      className="group relative cursor-pointer rounded-2xl border border-slate-200 bg-white p-5 shadow-2xs transition-all hover:border-slate-300 hover:shadow-xs dark:border-slate-800 dark:bg-slate-900 dark:hover:border-slate-700"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-700 dark:bg-slate-800 dark:text-slate-300">
            {note.category}
          </span>
          <span className="text-xs text-slate-400">
            {formatFriendlyDate(note.updatedAt)}
          </span>
        </div>

        {/* Pin & Menu */}
        <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
          <button
            onClick={() => togglePin(note.id)}
            className={`rounded-lg p-1 transition-colors ${
              note.pinned
                ? 'text-indigo-600 dark:text-indigo-400'
                : 'text-slate-300 hover:text-slate-600 dark:text-slate-600 dark:hover:text-slate-400'
            }`}
            title={note.pinned ? 'Unpin note' : 'Pin note'}
          >
            <Pin className={`h-3.5 w-3.5 ${note.pinned ? 'fill-current' : ''}`} />
          </button>

          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800"
            >
              <MoreVertical className="h-4 w-4" />
            </button>

            {showMenu && (
              <div className="absolute right-0 top-7 z-10 w-28 rounded-xl border border-slate-200 bg-white p-1 shadow-lg dark:border-slate-800 dark:bg-slate-900">
                <button
                  onClick={() => {
                    setShowMenu(false)
                    onEdit(note)
                  }}
                  className="flex w-full items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  <Edit2 className="h-3.5 w-3.5" />
                  Edit
                </button>
                <button
                  onClick={() => {
                    setShowMenu(false)
                    deleteNote(note.id)
                  }}
                  className="flex w-full items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs text-rose-600 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950/60"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Delete
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <h3 className="mt-2 text-sm font-semibold text-slate-900 dark:text-slate-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
        {note.title}
      </h3>

      <p className="mt-1.5 text-xs text-slate-500 dark:text-slate-400 line-clamp-3 leading-relaxed whitespace-pre-line">
        {note.content.replace(/^#+\s+/gm, '')}
      </p>

      {/* Checklist summary if present */}
      {totalChecklist > 0 && (
        <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
          <CheckSquare className="h-3.5 w-3.5 text-indigo-500" />
          <span>
            {completedChecklist}/{totalChecklist} checklist completed
          </span>
        </div>
      )}

      {/* Tags */}
      {note.tags && note.tags.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1">
          {note.tags.map((tag) => (
            <span
              key={tag}
              className="inline-flex items-center gap-1 rounded bg-slate-100 px-1.5 py-0.5 text-[10px] text-slate-600 dark:bg-slate-800 dark:text-slate-400"
            >
              #{tag}
            </span>
          ))}
        </div>
      )}
    </div>
  )
}
