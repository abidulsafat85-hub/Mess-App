import React, { useState, useEffect } from 'react'
import { Modal } from '@/components/ui/Modal'
import { Input, Textarea } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Note, NoteCategory, NoteChecklistItem } from '@/types'
import { useNoteStore } from '@/store/useNoteStore'
import { useUIStore } from '@/store/useUIStore'
import { Tag, Plus, X, CheckSquare, Pin } from 'lucide-react'

export interface NoteModalProps {
  isOpen: boolean
  onClose: () => void
  editingNote?: Note | null
}

export function NoteModal({ isOpen, onClose, editingNote }: NoteModalProps) {
  const { addNote, updateNote, deleteNote } = useNoteStore()
  const { showToast } = useUIStore()

  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [category, setCategory] = useState<NoteCategory>('Study')
  const [tagsInput, setTagsInput] = useState('')
  const [pinned, setPinned] = useState(false)
  const [checklist, setChecklist] = useState<NoteChecklistItem[]>([])
  const [newChecklistText, setNewChecklistText] = useState('')

  useEffect(() => {
    if (editingNote) {
      setTitle(editingNote.title)
      setContent(editingNote.content)
      setCategory(editingNote.category)
      setTagsInput(editingNote.tags.join(', '))
      setPinned(editingNote.pinned)
      setChecklist(editingNote.checklist || [])
    } else {
      setTitle('')
      setContent('')
      setCategory('Study')
      setTagsInput('')
      setPinned(false)
      setChecklist([])
    }
  }, [editingNote, isOpen])

  const handleAddChecklistItem = () => {
    if (!newChecklistText.trim()) return
    setChecklist([
      ...checklist,
      {
        id: 'chk_' + Math.random().toString(36).substring(2, 9),
        text: newChecklistText.trim(),
        done: false,
      },
    ])
    setNewChecklistText('')
  }

  const handleToggleChecklist = (id: string) => {
    setChecklist(
      checklist.map((item) =>
        item.id === id ? { ...item, done: !item.done } : item
      )
    )
  }

  const handleRemoveChecklist = (id: string) => {
    setChecklist(checklist.filter((item) => item.id !== id))
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim()) return

    const tags = tagsInput
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean)

    if (editingNote) {
      await updateNote(editingNote.id, {
        title: title.trim(),
        content: content.trim(),
        category,
        tags,
        pinned,
        checklist,
      })
      showToast('Note updated', 'success')
    } else {
      await addNote({
        title: title.trim(),
        content: content.trim(),
        category,
        tags,
        pinned,
        checklist,
      })
      showToast('Note created 📝', 'success')
    }
    onClose()
  }

  const handleDelete = async () => {
    if (editingNote) {
      await deleteNote(editingNote.id)
      showToast('Note deleted', 'info')
      onClose()
    }
  }

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={editingNote ? 'Edit Note' : 'New Note'}
      maxWidth="lg"
    >
      <form onSubmit={handleSave} className="space-y-4">
        <div className="flex items-center gap-3">
          <div className="flex-1">
            <Input
              label="Title *"
              placeholder="e.g. Database Normalization, Seminar Key Takeaways"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              autoFocus
              required
            />
          </div>

          <div className="w-36">
            <label className="mb-1.5 block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as NoteCategory)}
              className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100"
            >
              <option value="Study">Study</option>
              <option value="Ideas">Ideas</option>
              <option value="Important">Important</option>
              <option value="Personal">Personal</option>
            </select>
          </div>
        </div>

        {/* Note Content / Markdown body */}
        <Textarea
          label="Note Content"
          placeholder="Write formulas, concepts, references, or key thoughts..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          rows={6}
        />

        {/* Embedded Checklist */}
        <div>
          <label className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300">
            <CheckSquare className="h-3.5 w-3.5 text-indigo-500" />
            Checklist / Action Items ({checklist.filter((c) => c.done).length}/{checklist.length})
          </label>
          <div className="space-y-1.5 mb-2">
            {checklist.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between gap-2 rounded-xl bg-slate-50 p-2 text-xs dark:bg-slate-800"
              >
                <div
                  onClick={() => handleToggleChecklist(item.id)}
                  className="flex flex-1 cursor-pointer items-center gap-2"
                >
                  <input
                    type="checkbox"
                    checked={item.done}
                    onChange={() => {}}
                    className="rounded text-indigo-600 pointer-events-none"
                  />
                  <span
                    className={
                      item.done
                        ? 'line-through text-slate-400 dark:text-slate-500'
                        : 'text-slate-700 dark:text-slate-200'
                    }
                  >
                    {item.text}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => handleRemoveChecklist(item.id)}
                  className="rounded p-1 text-slate-400 hover:text-rose-500"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Add checklist item..."
              value={newChecklistText}
              onChange={(e) => setNewChecklistText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault()
                  handleAddChecklistItem()
                }
              }}
              className="h-9 flex-1 rounded-xl border border-slate-200 bg-white px-3 text-xs placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900"
            />
            <Button type="button" size="sm" variant="secondary" onClick={handleAddChecklistItem}>
              <Plus className="h-3.5 w-3.5" />
              Add
            </Button>
          </div>
        </div>

        {/* Tags & Pinned */}
        <div className="flex items-center justify-between gap-4 pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="flex-1">
            <Input
              icon={<Tag className="h-4 w-4" />}
              placeholder="Tags (e.g. Exam, Math, Architecture)"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
            />
          </div>

          <button
            type="button"
            onClick={() => setPinned(!pinned)}
            className={`flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-semibold transition-colors ${
              pinned
                ? 'border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300'
                : 'border-slate-200 text-slate-600 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-400'
            }`}
          >
            <Pin className={`h-3.5 w-3.5 ${pinned ? 'fill-current' : ''}`} />
            {pinned ? 'Pinned' : 'Pin to top'}
          </button>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
          {editingNote ? (
            <Button type="button" variant="danger" size="sm" onClick={handleDelete}>
              Delete
            </Button>
          ) : <div />}

          <div className="flex gap-2">
            <Button type="button" variant="outline" size="sm" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" size="sm">
              {editingNote ? 'Save Note' : 'Create Note'}
            </Button>
          </div>
        </div>
      </form>
    </Modal>
  )
}
