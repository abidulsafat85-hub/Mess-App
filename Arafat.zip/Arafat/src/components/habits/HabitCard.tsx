import React, { useState } from 'react'
import { format, subDays, addDays, startOfWeek, eachDayOfInterval } from 'date-fns'
import { Flame, Trophy, Check, MoreVertical, Edit2, Trash2 } from 'lucide-react'
import { Habit } from '@/types'
import { useHabitStore } from '@/store/useHabitStore'
import { cn } from '@/utils/cn'

export interface HabitCardProps {
  habit: Habit
  onEdit: (habit: Habit) => void
}

export function HabitCard({ habit, onEdit }: HabitCardProps) {
  const [showMenu, setShowMenu] = useState(false)
  const { toggleHabitDate, deleteHabit } = useHabitStore()

  // Generate current week days: Mon through Sun
  const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 })
  const weekDays = eachDayOfInterval({
    start: weekStart,
    end: addDays(weekStart, 6),
  })

  const todayStr = format(new Date(), 'yyyy-MM-dd')
  const isCompletedToday = !!habit.logs[todayStr]

  return (
    <div className="relative rounded-2xl border border-slate-200 bg-white p-4 shadow-2xs transition-all hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-slate-700">
      <div className="flex items-start justify-between gap-3">
        {/* Habit info */}
        <div>
          <div className="flex items-center gap-2">
            <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              {habit.name}
            </h4>
            <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-600 dark:bg-slate-800 dark:text-slate-400">
              {habit.category}
            </span>
          </div>

          <div className="mt-2 flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1 font-semibold text-amber-600 dark:text-amber-400">
              <Flame className="h-3.5 w-3.5 fill-current" />
              {habit.streak} day streak
            </span>
            <span className="flex items-center gap-1 text-slate-400">
              <Trophy className="h-3.5 w-3.5" />
              Best: {habit.longestStreak}d
            </span>
          </div>
        </div>

        {/* Today Action & Options */}
        <div className="flex items-center gap-2">
          {/* Quick toggle today button */}
          <button
            onClick={() => toggleHabitDate(habit.id, todayStr)}
            className={cn(
              'flex h-9 w-9 items-center justify-center rounded-xl border transition-all active:scale-95',
              isCompletedToday
                ? 'border-emerald-500 bg-emerald-500 text-white shadow-sm shadow-emerald-500/25'
                : 'border-slate-300 bg-white hover:border-emerald-500 dark:border-slate-700 dark:bg-slate-800'
            )}
            title={isCompletedToday ? 'Completed today' : 'Mark done today'}
          >
            {isCompletedToday ? (
              <Check className="h-5 w-5 stroke-[2.5]" />
            ) : (
              <span className="text-xs font-semibold text-slate-400">○</span>
            )}
          </button>

          {/* Menu */}
          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800"
            >
              <MoreVertical className="h-4 w-4" />
            </button>
            {showMenu && (
              <div className="absolute right-0 top-7 z-10 w-28 rounded-xl border border-slate-200 bg-white p-1 shadow-lg dark:border-slate-800 dark:bg-slate-900">
                <button
                  onClick={() => {
                    setShowMenu(false)
                    onEdit(habit)
                  }}
                  className="flex w-full items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  <Edit2 className="h-3.5 w-3.5" />
                  Edit
                </button>
                <button
                  onClick={() => {
                    setShowMenu(false)
                    deleteHabit(habit.id)
                  }}
                  className="flex w-full items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs text-rose-600 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950/60"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Delete
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 7-day Habit Calendar (M T W T F S S) */}
      <div className="mt-4 border-t border-slate-100 pt-3 dark:border-slate-800">
        <div className="grid grid-cols-7 gap-1 text-center">
          {weekDays.map((day) => {
            const dayStr = format(day, 'yyyy-MM-dd')
            const dayLabel = format(day, 'EEEEEE') // M, T, W, T, F, S, S
            const isDone = !!habit.logs[dayStr]
            const isToday = dayStr === todayStr

            return (
              <div key={dayStr} className="flex flex-col items-center gap-1.5">
                <span
                  className={cn(
                    'text-[10px] font-medium',
                    isToday ? 'text-indigo-600 dark:text-indigo-400 font-bold' : 'text-slate-400'
                  )}
                >
                  {dayLabel}
                </span>
                <button
                  onClick={() => toggleHabitDate(habit.id, dayStr)}
                  className={cn(
                    'flex h-7 w-7 items-center justify-center rounded-lg text-xs font-semibold transition-all active:scale-95',
                    isDone
                      ? 'bg-emerald-500 text-white shadow-2xs'
                      : isToday
                      ? 'border border-dashed border-indigo-400 bg-indigo-50/50 text-indigo-600 dark:bg-indigo-950/30 dark:text-indigo-400'
                      : 'bg-slate-100 text-slate-400 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700'
                  )}
                  title={`${format(day, 'MMM d')}: ${isDone ? 'Completed' : 'Not completed'}`}
                >
                  {isDone ? <Check className="h-3.5 w-3.5 stroke-[2.5]" /> : null}
                </button>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
