import React, { useState, useEffect } from 'react'
import { Modal } from '@/components/ui/Modal'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Habit, HabitFrequency } from '@/types'
import { useHabitStore } from '@/store/useHabitStore'
import { useUIStore } from '@/store/useUIStore'
import { Clock } from 'lucide-react'

export interface HabitModalProps {
  isOpen: boolean
  onClose: () => void
  editingHabit?: Habit | null
}

export function HabitModal({ isOpen, onClose, editingHabit }: HabitModalProps) {
  const { addHabit, updateHabit } = useHabitStore()
  const { showToast } = useUIStore()

  const [name, setName] = useState('')
  const [category, setCategory] = useState('Study')
  const [frequency, setFrequency] = useState<HabitFrequency>('daily')
  const [reminder, setReminder] = useState('')

  useEffect(() => {
    if (editingHabit) {
      setName(editingHabit.name)
      setCategory(editingHabit.category)
      setFrequency(editingHabit.frequency)
      setReminder(editingHabit.reminder || '')
    } else {
      setName('')
      setCategory('Study')
      setFrequency('daily')
      setReminder('')
    }
  }, [editingHabit, isOpen])

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim()) return

    if (editingHabit) {
      await updateHabit(editingHabit.id, {
        name: name.trim(),
        category,
        frequency,
        reminder: reminder || undefined,
      })
      showToast('Habit updated', 'success')
    } else {
      await addHabit({
        name: name.trim(),
        category,
        frequency,
        target: 1,
        reminder: reminder || undefined,
      })
      showToast('Habit created 🔥', 'success')
    }
    onClose()
  }

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={editingHabit ? 'Edit Habit' : 'Build a New Habit'}
      maxWidth="sm"
    >
      <form onSubmit={handleSave} className="space-y-4">
        <Input
          label="Habit Name *"
          placeholder="e.g. Study 2 hours, LeetCode, Read 20 pages"
          value={name}
          onChange={(e) => setName(e.target.value)}
          autoFocus
          required
        />

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100"
            >
              <option value="Study">Study</option>
              <option value="Coding">Coding</option>
              <option value="Reading">Reading</option>
              <option value="Health">Health</option>
              <option value="Personal">Personal</option>
            </select>
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Frequency
            </label>
            <select
              value={frequency}
              onChange={(e) => setFrequency(e.target.value as HabitFrequency)}
              className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100"
            >
              <option value="daily">Every Day</option>
              <option value="weekdays">Weekdays</option>
              <option value="weekends">Weekends</option>
            </select>
          </div>
        </div>

        <Input
          type="time"
          label="Reminder Time (Optional)"
          icon={<Clock className="h-4 w-4" />}
          value={reminder}
          onChange={(e) => setReminder(e.target.value)}
        />

        <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <Button type="button" variant="outline" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" size="sm">
            {editingHabit ? 'Save Changes' : 'Create Habit'}
          </Button>
        </div>
      </form>
    </Modal>
  )
}
