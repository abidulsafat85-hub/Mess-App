import React, { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, CheckSquare, FileText, Target, Flame, BookOpen, ArrowRight, X } from 'lucide-react'
import { useUIStore } from '@/store/useUIStore'
import { useTaskStore } from '@/store/useTaskStore'
import { useNoteStore } from '@/store/useNoteStore'
import { useGoalStore } from '@/store/useGoalStore'
import { useHabitStore } from '@/store/useHabitStore'
import { useStudyStore } from '@/store/useStudyStore'
import { NavigationTab } from '@/types'

export function SearchCommand() {
  const { isSearchOpen, setSearchOpen, setActiveTab, openTaskModal } = useUIStore()
  const [query, setQuery] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)

  const { tasks } = useTaskStore()
  const { notes } = useNoteStore()
  const { goals } = useGoalStore()
  const { habits } = useHabitStore()
  const { subjects } = useStudyStore()

  useEffect(() => {
    if (isSearchOpen) {
      setTimeout(() => inputRef.current?.focus(), 50)
    } else {
      setQuery('')
    }
  }, [isSearchOpen])

  if (!isSearchOpen) return null

  const q = query.trim().toLowerCase()

  // Filter grouped results
  const matchedTasks = q
    ? tasks.filter((t) => t.title.toLowerCase().includes(q) || t.description?.toLowerCase().includes(q)).slice(0, 4)
    : []

  const matchedNotes = q
    ? notes.filter((n) => n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q)).slice(0, 3)
    : []

  const matchedGoals = q
    ? goals.filter((g) => g.title.toLowerCase().includes(q) || g.description?.toLowerCase().includes(q)).slice(0, 3)
    : []

  const matchedHabits = q
    ? habits.filter((h) => h.name.toLowerCase().includes(q)).slice(0, 3)
    : []

  const matchedSubjects = q
    ? subjects.filter((s) => s.name.toLowerCase().includes(q)).slice(0, 3)
    : []

  const hasResults =
    matchedTasks.length > 0 ||
    matchedNotes.length > 0 ||
    matchedGoals.length > 0 ||
    matchedHabits.length > 0 ||
    matchedSubjects.length > 0

  const handleSelectNav = (tab: NavigationTab) => {
    setSearchOpen(false)
    setActiveTab(tab)
  }

  const handleSelectTask = (taskId: string) => {
    setSearchOpen(false)
    openTaskModal(taskId)
  }

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-16 sm:pt-24">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setSearchOpen(false)}
          className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs"
        />

        {/* Search Modal Box */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: -10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -10 }}
          transition={{ duration: 0.15 }}
          className="relative z-10 w-full max-w-xl overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900"
        >
          {/* Search Input Bar */}
          <div className="flex items-center border-b border-slate-200 px-4 dark:border-slate-800">
            <Search className="h-5 w-5 text-slate-400" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search tasks, notes, goals, habits, subjects..."
              className="h-14 w-full bg-transparent px-3 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none dark:text-slate-100 dark:placeholder:text-slate-500"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="rounded-md p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="h-4 w-4" />
              </button>
            )}
            <kbd className="ml-2 rounded border border-slate-200 bg-slate-50 px-1.5 py-0.5 text-[10px] font-semibold text-slate-400 dark:border-slate-800 dark:bg-slate-800">
              ESC
            </kbd>
          </div>

          {/* Search Results List */}
          <div className="max-h-96 overflow-y-auto p-3">
            {!query && (
              <div className="p-4 text-center text-xs text-slate-400">
                Type anything to search across your student productivity workspace.
              </div>
            )}

            {query && !hasResults && (
              <div className="p-8 text-center text-xs text-slate-400">
                No matching results found for "{query}".
              </div>
            )}

            {/* Tasks Group */}
            {matchedTasks.length > 0 && (
              <div className="mb-3">
                <span className="px-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  Tasks
                </span>
                <div className="mt-1 space-y-1">
                  {matchedTasks.map((task) => (
                    <div
                      key={task.id}
                      onClick={() => handleSelectTask(task.id)}
                      className="flex cursor-pointer items-center justify-between rounded-xl px-2.5 py-2 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <CheckSquare className="h-4 w-4 text-indigo-500 shrink-0" />
                        <span className={`text-xs truncate ${task.completed ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-200'}`}>
                          {task.title}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 shrink-0">
                        {task.category}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Notes Group */}
            {matchedNotes.length > 0 && (
              <div className="mb-3">
                <span className="px-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  Notes
                </span>
                <div className="mt-1 space-y-1">
                  {matchedNotes.map((note) => (
                    <div
                      key={note.id}
                      onClick={() => handleSelectNav('notes')}
                      className="flex cursor-pointer items-center justify-between rounded-xl px-2.5 py-2 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <FileText className="h-4 w-4 text-purple-500 shrink-0" />
                        <span className="text-xs text-slate-800 dark:text-slate-200 truncate font-medium">
                          {note.title}
                        </span>
                      </div>
                      <ArrowRight className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Goals Group */}
            {matchedGoals.length > 0 && (
              <div className="mb-3">
                <span className="px-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  Goals
                </span>
                <div className="mt-1 space-y-1">
                  {matchedGoals.map((goal) => (
                    <div
                      key={goal.id}
                      onClick={() => handleSelectNav('goals')}
                      className="flex cursor-pointer items-center justify-between rounded-xl px-2.5 py-2 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Target className="h-4 w-4 text-emerald-500 shrink-0" />
                        <span className="text-xs text-slate-800 dark:text-slate-200 truncate font-medium">
                          {goal.title}
                        </span>
                      </div>
                      <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400">
                        {goal.progress}%
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Habits Group */}
            {matchedHabits.length > 0 && (
              <div className="mb-3">
                <span className="px-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  Habits
                </span>
                <div className="mt-1 space-y-1">
                  {matchedHabits.map((habit) => (
                    <div
                      key={habit.id}
                      onClick={() => handleSelectNav('habits')}
                      className="flex cursor-pointer items-center justify-between rounded-xl px-2.5 py-2 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Flame className="h-4 w-4 text-amber-500 shrink-0" />
                        <span className="text-xs text-slate-800 dark:text-slate-200 truncate font-medium">
                          {habit.name}
                        </span>
                      </div>
                      <span className="text-[10px] text-amber-600 font-semibold">
                        {habit.streak}d streak
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Subjects Group */}
            {matchedSubjects.length > 0 && (
              <div>
                <span className="px-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  Subjects
                </span>
                <div className="mt-1 space-y-1">
                  {matchedSubjects.map((subject) => (
                    <div
                      key={subject.id}
                      onClick={() => handleSelectNav('study')}
                      className="flex cursor-pointer items-center justify-between rounded-xl px-2.5 py-2 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <BookOpen className="h-4 w-4 text-blue-500 shrink-0" />
                        <span className="text-xs text-slate-800 dark:text-slate-200 truncate font-medium">
                          {subject.name}
                        </span>
                      </div>
                      <ArrowRight className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  )
}
