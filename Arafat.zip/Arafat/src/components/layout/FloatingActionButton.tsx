import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus, CheckSquare, BookOpen, Flame, Target, FileText } from 'lucide-react'
import { useUIStore, QuickAddType } from '@/store/useUIStore'

export function FloatingActionButton() {
  const [isOpen, setIsOpen] = useState(false)
  const { openQuickAdd } = useUIStore()
  const menuRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsOpen(false)
      }
    }
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside)
    }
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [isOpen])

  const handleSelect = (type: QuickAddType) => {
    setIsOpen(false)
    openQuickAdd(type)
  }

  const actions = [
    { type: 'task' as QuickAddType, label: 'Add Task', icon: CheckSquare, color: 'text-indigo-600 dark:text-indigo-400' },
    { type: 'session' as QuickAddType, label: 'Study Session', icon: BookOpen, color: 'text-blue-600 dark:text-blue-400' },
    { type: 'habit' as QuickAddType, label: 'New Habit', icon: Flame, color: 'text-amber-600 dark:text-amber-400' },
    { type: 'goal' as QuickAddType, label: 'New Goal', icon: Target, color: 'text-emerald-600 dark:text-emerald-400' },
    { type: 'note' as QuickAddType, label: 'New Note', icon: FileText, color: 'text-purple-600 dark:text-purple-400' },
  ]

  return (
    <div ref={menuRef} className="fixed bottom-20 right-5 z-40 md:bottom-8 md:right-8">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.85, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.85, y: 15 }}
            transition={{ duration: 0.16 }}
            className="mb-3 flex flex-col gap-2 rounded-2xl border border-slate-200/90 bg-white/95 p-2 shadow-xl backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/95"
          >
            {actions.map((act) => {
              const Icon = act.icon
              return (
                <button
                  key={act.type}
                  onClick={() => handleSelect(act.type)}
                  className="flex items-center gap-3 rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-700 transition-colors hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800 text-left whitespace-nowrap"
                >
                  <Icon className={`h-4 w-4 shrink-0 ${act.color}`} />
                  <span>{act.label}</span>
                </button>
              )
            })}
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Create item"
        className="flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 transition-transform active:scale-95 hover:bg-indigo-700"
      >
        <motion.div animate={{ rotate: isOpen ? 45 : 0 }} transition={{ duration: 0.2 }}>
          <Plus className="h-6 w-6 stroke-[2.5]" />
        </motion.div>
      </button>
    </div>
  )
}
