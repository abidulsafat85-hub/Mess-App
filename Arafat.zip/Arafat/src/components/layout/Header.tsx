import { Search, Flame, Play, Moon } from 'lucide-react'
import { useUIStore } from '@/store/useUIStore'
import { useHabitStore } from '@/store/useHabitStore'
import { useFocusStore } from '@/store/useFocusStore'
import { NotificationDropdown } from './NotificationDropdown'

export function Header() {
  const { setSearchOpen, setFocusModalOpen, setDailyReviewOpen, setActiveTab } = useUIStore()
  const { habits } = useHabitStore()
  const { status, secondsRemaining } = useFocusStore()

  // Calculate highest streak across active habits
  const highestStreak = habits.reduce((max, h) => Math.max(max, h.streak), 12)

  const formatTimerMinSec = (secs: number) => {
    const m = Math.floor(secs / 60)
    const s = secs % 60
    return `${m}:${s.toString().padStart(2, '0')}`
  }

  return (
    <header className="sticky top-0 z-20 flex h-16 w-full items-center justify-between border-b border-slate-200/80 bg-white/70 px-4 backdrop-blur-md dark:border-slate-800/80 dark:bg-slate-900/60 sm:px-6">
      {/* Left: Global Search trigger */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setSearchOpen(true)}
          className="flex items-center gap-2 rounded-xl border border-slate-200/90 bg-slate-50/80 px-3 py-1.5 text-xs text-slate-500 transition-colors hover:border-slate-300 hover:bg-slate-100/80 dark:border-slate-800 dark:bg-slate-800/60 dark:text-slate-400 dark:hover:bg-slate-800 sm:w-64"
        >
          <Search className="h-3.5 w-3.5 text-slate-400" />
          <span className="flex-1 text-left truncate">Search tasks, notes, goals...</span>
          <kbd className="hidden rounded bg-white px-1.5 py-0.5 text-[10px] font-semibold text-slate-400 shadow-2xs border border-slate-200 dark:border-slate-700 dark:bg-slate-900 sm:inline-block">
            ⌘K
          </kbd>
        </button>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Streak indicator */}
        <div
          onClick={() => setActiveTab('habits')}
          className="flex cursor-pointer items-center gap-1.5 rounded-xl bg-amber-50 px-2.5 py-1.5 text-xs font-semibold text-amber-700 transition-colors hover:bg-amber-100 dark:bg-amber-950/50 dark:text-amber-400"
          title="Habit Streak"
        >
          <Flame className="h-4 w-4 text-amber-500 fill-amber-500 animate-bounce" />
          <span>{highestStreak} days</span>
        </div>

        {/* Focus Mode button */}
        <button
          onClick={() => setFocusModalOpen(true)}
          className={`flex items-center gap-2 rounded-xl px-3 py-1.5 text-xs font-semibold transition-all ${
            status === 'running'
              ? 'bg-rose-500 text-white shadow-sm shadow-rose-500/25 animate-pulse'
              : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-300'
          }`}
          title="Focus Pomodoro (F)"
        >
          <Play className="h-3.5 w-3.5 fill-current" />
          <span className="hidden sm:inline">
            {status === 'running' ? `Focusing: ${formatTimerMinSec(secondsRemaining)}` : 'Focus Mode'}
          </span>
          <span className="sm:hidden">
            {status === 'running' ? formatTimerMinSec(secondsRemaining) : 'Focus'}
          </span>
        </button>

        {/* Daily Review button */}
        <button
          onClick={() => setDailyReviewOpen(true)}
          className="hidden lg:flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
          title="End of Day Reflection"
        >
          <Moon className="h-3.5 w-3.5 text-indigo-500" />
          <span>Daily Review</span>
        </button>

        {/* Notification Bell */}
        <NotificationDropdown />
      </div>
    </header>
  )
}
