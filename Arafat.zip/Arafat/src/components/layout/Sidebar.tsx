import React from 'react'
import {
  Calendar as CalendarIcon,
  CheckSquare,
  BookOpen,
  Flame,
  Target,
  FileText,
  TrendingUp,
  Sparkles,
  User,
  Sun,
  Moon,
  ChevronLeft,
  ChevronRight,
  Plus,
  Compass,
} from 'lucide-react'
import { useUIStore } from '@/store/useUIStore'
import { useSettingsStore } from '@/store/useSettingsStore'
import { NavigationTab } from '@/types'
import { cn } from '@/utils/cn'

interface NavItem {
  id: NavigationTab
  label: string
  icon: React.ComponentType<{ className?: string }>
  badge?: string | number
}

export function Sidebar() {
  const { activeTab, setActiveTab, isSidebarCollapsed, toggleSidebar, openQuickAdd } = useUIStore()
  const { settings, setTheme } = useSettingsStore()

  const navItems: NavItem[] = [
    { id: 'today', label: 'Today', icon: Compass },
    { id: 'calendar', label: 'Calendar', icon: CalendarIcon },
    { id: 'tasks', label: 'Tasks', icon: CheckSquare },
    { id: 'study', label: 'Study', icon: BookOpen },
    { id: 'habits', label: 'Habits', icon: Flame },
    { id: 'goals', label: 'Goals', icon: Target },
    { id: 'notes', label: 'Notes', icon: FileText },
    { id: 'progress', label: 'Progress', icon: TrendingUp },
    { id: 'ai', label: 'AI Assistant', icon: Sparkles },
    { id: 'profile', label: 'Profile', icon: User },
  ]

  const toggleThemeMode = () => {
    if (settings.theme === 'dark') {
      setTheme('light')
    } else {
      setTheme('dark')
    }
  }

  return (
    <aside
      className={cn(
        'hidden md:flex flex-col border-r border-slate-200/80 bg-white/70 backdrop-blur-md transition-all duration-300 dark:border-slate-800/80 dark:bg-slate-900/60 sticky top-0 h-screen select-none z-30 shrink-0',
        isSidebarCollapsed ? 'w-20' : 'w-64'
      )}
    >
      {/* App Logo & Brand */}
      <div className="flex h-16 items-center justify-between px-5">
        <div
          onClick={() => setActiveTab('today')}
          className="flex cursor-pointer items-center gap-2.5 overflow-hidden font-bold tracking-tight text-slate-900 dark:text-white"
        >
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-md shadow-indigo-500/25">
            <span className="font-extrabold text-base">A</span>
          </div>
          {!isSidebarCollapsed && (
            <div className="flex flex-col">
              <span className="text-base font-bold tracking-tight text-slate-900 dark:text-white">
                Aura
              </span>
              <span className="text-[10px] font-medium tracking-wide text-indigo-600 dark:text-indigo-400 -mt-1 uppercase">
                Productivity
              </span>
            </div>
          )}
        </div>

        <button
          onClick={toggleSidebar}
          aria-label="Toggle sidebar collapse"
          className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-200"
        >
          {isSidebarCollapsed ? (
            <ChevronRight className="h-4 w-4" />
          ) : (
            <ChevronLeft className="h-4 w-4" />
          )}
        </button>
      </div>

      {/* Quick Add CTA */}
      <div className="px-3 py-2">
        <button
          onClick={() => openQuickAdd('task')}
          className={cn(
            'flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 py-2.5 font-medium text-white shadow-sm shadow-indigo-600/25 transition-all hover:bg-indigo-700 active:scale-[0.98] text-sm',
            isSidebarCollapsed && 'px-0 py-2.5'
          )}
          title="New Task (N)"
        >
          <Plus className="h-4 w-4 shrink-0" />
          {!isSidebarCollapsed && <span>Add Task</span>}
        </button>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-2">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = activeTab === item.id
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                'group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all',
                isActive
                  ? 'bg-indigo-50/80 text-indigo-700 font-semibold dark:bg-indigo-950/60 dark:text-indigo-300'
                  : 'text-slate-600 hover:bg-slate-100/70 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800/60 dark:hover:text-slate-100',
                isSidebarCollapsed && 'justify-center px-0'
              )}
              title={isSidebarCollapsed ? item.label : undefined}
            >
              <Icon
                className={cn(
                  'h-5 w-5 shrink-0 transition-transform group-hover:scale-105',
                  isActive
                    ? 'text-indigo-600 dark:text-indigo-400'
                    : 'text-slate-500 group-hover:text-slate-700 dark:text-slate-400 dark:group-hover:text-slate-200'
                )}
              />
              {!isSidebarCollapsed && (
                <span className="flex-1 text-left truncate">{item.label}</span>
              )}
              {!isSidebarCollapsed && item.id === 'ai' && (
                <span className="rounded-full bg-indigo-100 px-1.5 py-0.5 text-[10px] font-semibold text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
                  New
                </span>
              )}
            </button>
          )
        })}
      </nav>

      {/* Footer / Theme toggle & Student Avatar */}
      <div className="border-t border-slate-200/80 p-3 dark:border-slate-800/80">
        <div
          className={cn(
            'flex items-center justify-between rounded-xl p-2 hover:bg-slate-100/70 dark:hover:bg-slate-800/60',
            isSidebarCollapsed && 'flex-col gap-2 p-1'
          )}
        >
          <div
            onClick={() => setActiveTab('profile')}
            className="flex cursor-pointer items-center gap-2.5 overflow-hidden"
          >
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-200 text-xs font-semibold text-slate-700 dark:bg-slate-700 dark:text-slate-200">
              {settings.name.charAt(0)}
            </div>
            {!isSidebarCollapsed && (
              <div className="flex flex-col truncate">
                <span className="text-xs font-medium text-slate-900 dark:text-slate-100 truncate">
                  {settings.name}
                </span>
                <span className="text-[11px] text-slate-400 truncate">
                  Student Plan
                </span>
              </div>
            )}
          </div>

          <button
            onClick={toggleThemeMode}
            aria-label="Toggle dark mode"
            className="rounded-lg p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            title="Toggle Theme"
          >
            {settings.theme === 'dark' ? (
              <Sun className="h-4 w-4" />
            ) : (
              <Moon className="h-4 w-4" />
            )}
          </button>
        </div>
      </div>
    </aside>
  )
}
