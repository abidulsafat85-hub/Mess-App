import React from 'react'
import { Compass, Calendar as CalendarIcon, CheckSquare, TrendingUp, User } from 'lucide-react'
import { useUIStore } from '@/store/useUIStore'
import { NavigationTab } from '@/types'
import { cn } from '@/utils/cn'

interface TabItem {
  id: NavigationTab
  label: string
  icon: React.ComponentType<{ className?: string }>
}

export function BottomNavigation() {
  const { activeTab, setActiveTab } = useUIStore()

  const mobileTabs: TabItem[] = [
    { id: 'today', label: 'Today', icon: Compass },
    { id: 'calendar', label: 'Calendar', icon: CalendarIcon },
    { id: 'tasks', label: 'Tasks', icon: CheckSquare },
    { id: 'progress', label: 'Progress', icon: TrendingUp },
    { id: 'profile', label: 'Profile', icon: User },
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 flex h-16 items-center justify-around border-t border-slate-200/90 bg-white/95 px-2 backdrop-blur-md dark:border-slate-800/90 dark:bg-slate-900/95 md:hidden">
      {mobileTabs.map((tab) => {
        const Icon = tab.icon
        const isActive = activeTab === tab.id
        return (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              'flex flex-1 flex-col items-center justify-center py-1 transition-colors',
              isActive
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
                : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
            )}
          >
            <Icon className={cn('h-5 w-5', isActive && 'scale-110')} />
            <span className="mt-1 text-[11px] leading-none">{tab.label}</span>
          </button>
        )
      })}
    </div>
  )
}
