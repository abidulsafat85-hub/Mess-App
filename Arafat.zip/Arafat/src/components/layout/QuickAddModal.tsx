import React from 'react'
import { useUIStore } from '@/store/useUIStore'
import { TaskModal } from '@/components/tasks/TaskModal'
import { StudySessionModal } from '@/components/study/StudySessionModal'
import { HabitModal } from '@/components/habits/HabitModal'
import { GoalModal } from '@/components/goals/GoalModal'
import { NoteModal } from '@/components/notes/NoteModal'

export function QuickAddModal() {
  const { isQuickAddOpen, closeQuickAdd, quickAddType, openTaskModal } = useUIStore()

  if (!isQuickAddOpen) return null

  if (quickAddType === 'task') {
    closeQuickAdd()
    openTaskModal(null)
    return null
  }

  return (
    <>
      <StudySessionModal
        isOpen={isQuickAddOpen && quickAddType === 'session'}
        onClose={closeQuickAdd}
      />
      <HabitModal
        isOpen={isQuickAddOpen && quickAddType === 'habit'}
        onClose={closeQuickAdd}
      />
      <GoalModal
        isOpen={isQuickAddOpen && quickAddType === 'goal'}
        onClose={closeQuickAdd}
      />
      <NoteModal
        isOpen={isQuickAddOpen && quickAddType === 'note'}
        onClose={closeQuickAdd}
      />
    </>
  )
}
