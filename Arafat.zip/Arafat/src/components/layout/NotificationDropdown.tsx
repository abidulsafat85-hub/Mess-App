import { useState, useRef, useEffect } from 'react'
import { Bell, Check, Clock, BookOpen, Flame, Sparkles } from 'lucide-react'
import { notificationService } from '@/services/notificationService'
import { NotificationItem } from '@/types'

export function NotificationDropdown() {
  const [isOpen, setIsOpen] = useState(false)
  const [items, setItems] = useState<NotificationItem[]>([])
  const menuRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setItems(notificationService.getNotifications())
  }, [isOpen])

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsOpen(false)
      }
    }
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside)
    }
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [isOpen])

  const unreadCount = items.filter((i) => !i.read).length

  const handleMarkAllRead = () => {
    notificationService.markAllAsRead()
    setItems(notificationService.getNotifications())
  }

  const handleItemClick = (id: string) => {
    notificationService.markAsRead(id)
    setItems(notificationService.getNotifications())
  }

  const getIcon = (type: string) => {
    switch (type) {
      case 'task':
        return <Clock className="h-4 w-4 text-indigo-500" />
      case 'study':
        return <BookOpen className="h-4 w-4 text-blue-500" />
      case 'habit':
        return <Flame className="h-4 w-4 text-amber-500" />
      case 'review':
        return <Sparkles className="h-4 w-4 text-emerald-500" />
      default:
        return <Bell className="h-4 w-4 text-slate-500" />
    }
  }

  return (
    <div ref={menuRef} className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Notifications"
        className="relative rounded-xl p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-700 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-200"
      >
        <Bell className="h-5 w-5" />
        {unreadCount > 0 && (
          <span className="absolute right-1.5 top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white ring-2 ring-white dark:ring-slate-900">
            {unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div className="absolute right-0 top-12 z-50 w-80 rounded-2xl border border-slate-200 bg-white p-3 shadow-xl dark:border-slate-800 dark:bg-slate-900 sm:w-96">
          <div className="mb-2 flex items-center justify-between border-b border-slate-100 pb-2.5 dark:border-slate-800">
            <h4 className="text-xs font-semibold text-slate-900 dark:text-slate-100">
              Notifications & Reminders
            </h4>
            {unreadCount > 0 && (
              <button
                onClick={handleMarkAllRead}
                className="flex items-center gap-1 text-[11px] font-medium text-indigo-600 hover:underline dark:text-indigo-400"
              >
                <Check className="h-3 w-3" />
                Mark all read
              </button>
            )}
          </div>

          <div className="max-h-72 space-y-1.5 overflow-y-auto pr-1">
            {items.length === 0 ? (
              <p className="py-6 text-center text-xs text-slate-400">
                No notifications right now
              </p>
            ) : (
              items.map((item) => (
                <div
                  key={item.id}
                  onClick={() => handleItemClick(item.id)}
                  className={`flex cursor-pointer items-start gap-3 rounded-xl p-2.5 transition-colors ${
                    item.read
                      ? 'bg-transparent hover:bg-slate-50 dark:hover:bg-slate-800/50'
                      : 'bg-indigo-50/50 hover:bg-indigo-50 dark:bg-indigo-950/30 dark:hover:bg-indigo-950/50'
                  }`}
                >
                  <div className="mt-0.5 shrink-0">{getIcon(item.type)}</div>
                  <div className="flex-1 overflow-hidden">
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
                      {item.title}
                    </p>
                    <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2">
                      {item.message}
                    </p>
                  </div>
                  {!item.read && (
                    <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-indigo-500" />
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  )
}
