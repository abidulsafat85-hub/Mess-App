import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User,
  Mail,
  Phone,
  MapPin,
  GraduationCap,
  Lock,
  LogOut,
  Save,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import { MemberNav } from './MemberNav';
import { AuthUser } from '../../types';

interface MemberProfilePageProps {
  authUser: AuthUser | null;
  onLogout: () => void;
  isAdmin?: boolean;
}

export const MemberProfilePage: React.FC<MemberProfilePageProps> = ({
  authUser,
  onLogout,
  isAdmin,
}) => {
  const navigate = useNavigate();
  const memberId = authUser?.memberId || authUser?.id || '';

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [loggingOutAll, setLoggingOutAll] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [origPhone, setOrigPhone] = useState('');
  const [address, setAddress] = useState('');
  const [studentId, setStudentId] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');

  useEffect(() => {
    if (!memberId) return;
    setLoading(true);
    fetch(`/api/mess/member/${memberId}/profile`, { credentials: 'include' })
      .then((res) => res.json())
      .then((json) => {
        if (json.success && json.data) {
          const m = json.data;
          setFullName(m.fullName || '');
          setEmail(m.email || authUser?.email || '');
          setPhone(m.phone || '');
          setOrigPhone(m.phone || '');
          setAddress(m.address || m.location || '');
          setStudentId(m.studentId || m.universityId || '');
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [memberId]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    const isPhoneChanged = phone.trim() !== origPhone.trim();
    if (isPhoneChanged && !currentPassword.trim()) {
      setError('মোবাইল নম্বর পরিবর্তন করতে বর্তমান পাসওয়ার্ড দেওয়া আবশ্যক।');
      return;
    }

    setSaving(true);
    try {
      const res = await fetch(`/api/mess/member/${memberId}/profile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          fullName: fullName.trim(),
          phone: phone.trim(),
          address: address.trim(),
          studentId: studentId.trim(),
          currentPassword: currentPassword.trim() || undefined,
        }),
      });

      const json = await res.json();
      if (!res.ok || json.success === false) {
        throw new Error(json.error || 'প্রোফাইল আপডেট করতে ব্যর্থ হয়েছে');
      }

      setSuccess('প্রোফাইল সফলভাবে আপডেট করা হয়েছে!');
      setOrigPhone(phone.trim());
      setCurrentPassword('');
    } catch (err: any) {
      setError(err.message || 'আপডেট করতে সমস্যা হয়েছে');
    } finally {
      setSaving(false);
    }
  };

  const handleLogoutAllDevices = async () => {
    const confirmLogout = window.confirm(
      'আপনি কি নিশ্চিত যে আপনি আপনার অ্যাকাউন্টের সকল সক্রিয় ডিভাইস থেকে লগআউট করতে চান?'
    );
    if (!confirmLogout) return;

    setLoggingOutAll(true);
    try {
      await fetch('/api/mess/auth/logout-all', {
        method: 'POST',
        credentials: 'include',
      });
    } catch {}

    onLogout();
    navigate('/login', {
      replace: true,
      state: { message: 'সকল ডিভাইস থেকে সফলভাবে লগআউট করা হয়েছে।' },
    });
  };

  return (
    <div className="min-h-screen bg-stone-50 text-slate-800 pb-16 font-sans">
      <MemberNav authUser={authUser} onLogout={onLogout} isAdmin={isAdmin} />

      <main className="max-w-3xl mx-auto px-4 sm:px-6 pt-6 space-y-6">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">আমার প্রোফাইল ও নিরাপত্তা</h1>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            ব্যক্তিগত তথ্য আপডেট করুন এবং সেশন নিয়ন্ত্রণ করুন
          </p>
        </div>

        {error && (
          <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold flex items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0 text-rose-600" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />
            <span>{success}</span>
          </div>
        )}

        {/* Profile Edit Form */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-5">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <User className="h-5 w-5 text-emerald-600" />
            <h2 className="text-lg font-bold text-slate-900">ব্যক্তিগত তথ্যাবলী</h2>
          </div>

          <form onSubmit={handleUpdateProfile} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">পূর্ণ নাম (Full Name):</label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-sm focus:border-emerald-600 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ইমেইল অ্যাড্রেস (পরিবর্তনযোগ্য নয়):
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-3 h-4 w-4 text-stone-400" />
                <input
                  type="email"
                  disabled
                  value={email}
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-stone-200 bg-stone-100 text-stone-500 text-sm outline-none cursor-not-allowed"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                মোবাইল নম্বর (Phone):
              </label>
              <div className="relative">
                <Phone className="absolute left-3.5 top-3 h-4 w-4 text-stone-400" />
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-stone-300 text-sm focus:border-emerald-600 outline-none"
                />
              </div>
              {phone.trim() !== origPhone.trim() && (
                <p className="text-[11px] text-amber-700 font-semibold mt-1">
                  ⚠️ মোবাইল নম্বর পরিবর্তন করতে নিচে আপনার বর্তমান পাসওয়ার্ড দিন।
                </p>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ঠিকানা / মেসের রুম নং (Address / Room):
              </label>
              <div className="relative">
                <MapPin className="absolute left-3.5 top-3 h-4 w-4 text-stone-400" />
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-stone-300 text-sm focus:border-emerald-600 outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                স্টুডেন্ট আইডি (Student ID):
              </label>
              <div className="relative">
                <GraduationCap className="absolute left-3.5 top-3 h-4 w-4 text-stone-400" />
                <input
                  type="text"
                  value={studentId}
                  onChange={(e) => setStudentId(e.target.value)}
                  placeholder="যেমন: 2022-1-60-001"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-stone-300 text-sm focus:border-emerald-600 outline-none"
                />
              </div>
            </div>

            {phone.trim() !== origPhone.trim() && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  বর্তমান পাসওয়ার্ড (নিরাপত্তা যাচাই): *
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3 h-4 w-4 text-stone-400" />
                  <input
                    type="password"
                    required
                    placeholder="বর্তমান পাসওয়ার্ড লিখুন"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-amber-300 bg-amber-50/30 text-sm focus:border-amber-600 outline-none"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Save className="h-4 w-4" />
              <span>{saving ? 'সংরক্ষণ হচ্ছে...' : 'পরিবর্তন সংরক্ষণ করুন'}</span>
            </button>
          </form>
        </div>

        {/* Device Sessions and Logout */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <LogOut className="h-5 w-5 text-rose-600" />
            <h2 className="text-lg font-bold text-slate-900">সেশন ও লগআউট ম্যানেজমেন্ট</h2>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            যদি আপনি অন্য কোনো পাবলিক বা বন্ধু বান্ধবের ডিভাইসে লগইন করে থাকেন, তবে যেকোনো সময় সকল সক্রিয় সেশন টার্মিনেট করতে পারেন।
          </p>

          <div className="flex flex-col sm:flex-row sm:items-center gap-3 pt-2">
            <button
              type="button"
              onClick={handleLogoutAllDevices}
              disabled={loggingOutAll}
              className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <LogOut className="h-4 w-4" />
              <span>{loggingOutAll ? 'লগআউট হচ্ছে...' : 'সব ডিভাইস থেকে লগআউট (Logout from all devices)'}</span>
            </button>

            <button
              type="button"
              onClick={onLogout}
              className="px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs border border-slate-200 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <LogOut className="h-4 w-4" />
              <span>এই ডিভাইস থেকে লগআউট</span>
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};
