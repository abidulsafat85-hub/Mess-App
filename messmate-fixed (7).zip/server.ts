import path from 'path';
import { createServer as createViteServer } from 'vite';
import { app } from './server/app';

async function startServer() {
  const PORT = 3000;

  // In development, attach Vite middlewares
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // In production, serve dist folder and redirect non-API to index.html
    const distPath = path.join(process.cwd(), 'dist');
    app.use(expressStaticFallback(distPath));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[MessMate Server] Running on http://0.0.0.0:${PORT}`);
  });
}

function expressStaticFallback(distPath: string) {
  const express = require('express');
  const router = express.Router();
  router.use(express.static(distPath));
  router.get('*', (_req: any, res: any) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
  return router;
}

startServer().catch((err) => {
  console.error('[MessMate Server] Failed to start:', err);
});
